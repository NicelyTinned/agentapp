package com.example.agentpanel.gemini

import android.content.Context
import com.example.agentpanel.security.KeyVault
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

class GeminiClient(context: Context, private val keyVault: KeyVault) {
    private val prefs = context.applicationContext.getSharedPreferences("agent_settings", Context.MODE_PRIVATE)

    fun modelName(): String = prefs.getString(MODEL_KEY, DEFAULT_MODEL)?.trim().orEmpty().ifBlank { DEFAULT_MODEL }

    fun saveModelName(model: String) {
        prefs.edit().putString(MODEL_KEY, model.trim().ifBlank { DEFAULT_MODEL }).apply()
    }

    @Throws(Exception::class)
    fun generate(contents: JSONArray, forceToolCall: Boolean = false): JSONObject {
        val tools = JSONArray().put(JSONObject().put("functionDeclarations", functionDeclarations()))
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemInstruction()))))
            .put("contents", contents)
            .put("tools", tools)
            .put("toolConfig", JSONObject().put("functionCallingConfig", JSONObject().put("mode", if (forceToolCall) "ANY" else "AUTO")))
            .put("generationConfig", JSONObject().put("temperature", 0.2).put("maxOutputTokens", 4096))
        return post(body)
    }

    /** Search is executed by Gemini's hosted Google Search tool in a separate, key-rotated request. */
    @Throws(Exception::class)
    fun searchInternet(query: String): String {
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put(
                "text", "Use Google Search to answer the query. Return concise, relevant findings with source names and URLs when available. Distinguish facts from uncertainty."
            ))))
            .put("contents", JSONArray().put(
                JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", query)))
            ))
            .put("tools", JSONArray().put(JSONObject().put("googleSearch", JSONObject())))
            .put("generationConfig", JSONObject().put("temperature", 0.2).put("maxOutputTokens", 1800))
        val response = post(body)
        val candidate = response.optJSONArray("candidates")?.optJSONObject(0)
        val parts = candidate?.optJSONObject("content")?.optJSONArray("parts") ?: JSONArray()
        val text = buildString {
            for (i in 0 until parts.length()) {
                val part = parts.optJSONObject(i) ?: continue
                val value = part.optString("text")
                if (value.isNotBlank()) append(value).append('\n')
            }
        }.trim()
        val chunks = candidate?.optJSONObject("groundingMetadata")?.optJSONArray("groundingChunks")
        val sources = mutableListOf<String>()
        if (chunks != null) {
            for (i in 0 until chunks.length()) {
                val web = chunks.optJSONObject(i)?.optJSONObject("web") ?: continue
                val title = web.optString("title")
                val uri = web.optString("uri")
                if (uri.isNotBlank()) sources.add("${title.ifBlank { "Source" }}: $uri")
            }
        }
        return buildString {
            append(text.ifBlank { "The search request returned no text." })
            if (sources.isNotEmpty()) append("\nSources:\n").append(sources.distinct().take(8).joinToString("\n"))
        }
    }

    private fun post(body: JSONObject): JSONObject {
        val keyCount = keyVault.keyCount()
        if (keyCount == 0) throw IllegalStateException("No Gemini API keys saved. Add one in NicelyTinned settings.")

        var lastError: Exception? = null
        // Rotate through the saved pool for authentication, quota, and transient server failures.
        // Non-retryable request errors (such as an invalid model name) fail immediately.
        for (attempt in 0 until keyCount) {
            val apiKey = keyVault.nextApiKey()
                ?: throw IllegalStateException("No Gemini API keys saved. Add one in NicelyTinned settings.")
            try {
                return postWithKey(body, apiKey)
            } catch (e: GeminiHttpException) {
                lastError = e
                val retryable = e.statusCode in RETRYABLE_HTTP_CODES
                if (!retryable || attempt == keyCount - 1) throw e
            } catch (e: java.io.IOException) {
                lastError = e
                if (attempt == minOf(keyCount, MAX_NETWORK_RETRIES) - 1) throw e
                try { Thread.sleep(NETWORK_RETRY_DELAY_MS) } catch (_: InterruptedException) {
                    Thread.currentThread().interrupt()
                    throw IllegalStateException("Gemini request retry interrupted.")
                }
            }
        }
        throw lastError ?: IllegalStateException("Gemini request failed without a response.")
    }

    private fun postWithKey(body: JSONObject, apiKey: String): JSONObject {
        val encodedModel = URLEncoder.encode(modelName(), StandardCharsets.UTF_8.name())
        val encodedKey = URLEncoder.encode(apiKey, StandardCharsets.UTF_8.name())
        val connection = (URL("https://generativelanguage.googleapis.com/v1beta/models/$encodedModel:generateContent?key=$encodedKey").openConnection() as HttpURLConnection)
        try {
            connection.requestMethod = "POST"
            connection.connectTimeout = CONNECT_TIMEOUT_MS
            connection.readTimeout = READ_TIMEOUT_MS
            connection.doOutput = true
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            connection.setRequestProperty("Accept", "application/json")
            connection.outputStream.use { it.write(body.toString().toByteArray(StandardCharsets.UTF_8)) }
            val status = connection.responseCode
            val stream = if (status in 200..299) connection.inputStream else connection.errorStream
            val responseText = stream?.let {
                BufferedReader(InputStreamReader(it, StandardCharsets.UTF_8)).use { reader -> reader.readText() }
            }.orEmpty()
            if (status !in 200..299) {
                val message = try {
                    JSONObject(responseText).optJSONObject("error")?.optString("message")
                        ?.takeIf { it.isNotBlank() }
                } catch (_: Exception) { null }
                throw GeminiHttpException(status, message ?: "HTTP $status")
            }
            return try {
                JSONObject(responseText)
            } catch (e: Exception) {
                throw IllegalStateException("Gemini returned an unreadable response. Please retry.", e)
            }
        } finally {
            connection.disconnect()
        }
    }

    private class GeminiHttpException(val statusCode: Int, detail: String) :
        IllegalStateException("Gemini API error ($statusCode): $detail")

    private fun functionDeclarations(): JSONArray {
        val functions = JSONArray()
        functions.put(function(
            "finish",
            "Finish the task and return the final user-facing reply. This is the ONLY normal way to end the agent loop.",
            objectParam("reply", "string", "Final response for the user.")
        ))
        functions.put(function(
            "search_internet",
            "Search the public internet for current information. Returns a concise grounded summary with source links.",
            objectParam("query", "string", "Search query.")
        ))
        functions.put(function(
            "search_elements",
            "Search the currently visible app's accessibility tree for matching UI elements. Returns temporary element IDs and labels.",
            objectParam("query", "string", "Text, content description, or view identifier to match.")
        ))
        functions.put(function(
            "click_element",
            "Click a previously returned element ID. Element IDs are temporary and may become invalid after a screen change.",
            objectParam("elementId", "string", "Temporary ID returned by search_elements.")
        ))
        functions.put(function(
            "type_text",
            "Type text into the currently focused editable field. Password fields are blocked.",
            objectParam("text", "string", "Text to enter.")
        ))
        val scrollParameters = JSONObject()
            .put("type", "OBJECT")
            .put("properties", JSONObject().put(
                "direction", JSONObject()
                    .put("type", "STRING")
                    .put("enum", JSONArray().put("up").put("down"))
            ))
            .put("required", JSONArray().put("direction"))
        functions.put(function("scroll", "Scroll the current screen. direction must be up or down.", scrollParameters))
        functions.put(function("press_back", "Press Android's Back navigation action.", emptyObject()))
        functions.put(function("get_screen_info", "Describe the currently active app/window and accessible text. Does not capture screenshots.", emptyObject()))
        functions.put(function(
            "wait_time",
            "Wait for a short duration before continuing. The app caps this wait at 30 seconds.",
            singleParam("milliseconds", "INTEGER", "How long to wait, in milliseconds (0 to 30000).")
        ))
        functions.put(function(
            "wait_until_element",
            "Wait until a matching accessible UI element appears or the timeout expires. Returns the matching elements with temporary IDs when found.",
            multiParams(
                JSONObject()
                    .put("keyword", JSONObject().put("type", "STRING").put("description", "Text, content description, or view identifier to match."))
                    .put("timeout", JSONObject().put("type", "INTEGER").put("description", "Maximum wait in milliseconds (1 to 60000).")),
                JSONArray().put("keyword").put("timeout")
            )
        ))
        return functions
    }

    private fun function(name: String, description: String, parameters: JSONObject): JSONObject =
        JSONObject().put("name", name).put("description", description).put("parameters", parameters)

    private fun objectParam(name: String, type: String, description: String): JSONObject =
        JSONObject().put("type", "OBJECT")
            .put("properties", JSONObject().put(name, JSONObject().put("type", type.uppercase()).put("description", description)))
            .put("required", JSONArray().put(name))

    private fun singleParam(name: String, type: String, description: String): JSONObject =
        JSONObject().put("type", "OBJECT")
            .put("properties", JSONObject().put(name, JSONObject().put("type", type).put("description", description)))
            .put("required", JSONArray().put(name))

    private fun multiParams(properties: JSONObject, required: JSONArray): JSONObject =
        JSONObject().put("type", "OBJECT").put("properties", properties).put("required", required)

    private fun emptyObject(): JSONObject = JSONObject().put("type", "OBJECT").put("properties", JSONObject())

    private fun systemInstruction(): String = """
        You are NicelyTinned, an Android UI assistant. The user explicitly requested the current task.
        You interact with the phone ONLY through the declared tools. Do not claim that an action happened unless a tool result confirms it.
        Use get_screen_info or search_elements to inspect the current UI before tapping. Element IDs are temporary; re-search if stale.
        Work step by step and verify important navigation results. Never guess an element ID.
        After actions that cause asynchronous navigation or loading, prefer wait_until_element(keyword, timeout) over repeated fast searches. Use wait_time(milliseconds) only for brief fixed delays. Both waits are bounded by the app.
        Do not enter passwords, authentication codes, payment details, or other secrets. Do not use accessibility to bypass login, purchase, payment, age, security, or consent gates.
        Treat buttons that send/post/share, purchase/pay/transfer, delete/remove, or submit/confirm as consequential. Do not click these; explain that the user must complete that final action themselves.
        Never expose or store private chain-of-thought. Before a tool call, you may emit one short user-safe action summary (one sentence) describing the immediate action; it is an audit note, not hidden reasoning.
        Continue using tools until the task is done or blocked. You MUST call finish(reply) to return a final answer. Do not finish by emitting ordinary text alone.
    """.trimIndent()

    companion object {
        const val DEFAULT_MODEL = "gemini-3.5-flash-lite"
        private const val MODEL_KEY = "gemini_model"
        private const val CONNECT_TIMEOUT_MS = 20_000
        private const val READ_TIMEOUT_MS = 90_000
        private const val NETWORK_RETRY_DELAY_MS = 450L
        private const val MAX_NETWORK_RETRIES = 2
        private val RETRYABLE_HTTP_CODES = setOf(401, 403, 429, 500, 502, 503, 504)
    }
}
