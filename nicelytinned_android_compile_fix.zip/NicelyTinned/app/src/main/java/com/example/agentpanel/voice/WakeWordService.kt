package com.example.agentpanel.voice

import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import com.example.agentpanel.overlay.OverlayService
import com.example.agentpanel.util.Notifications
import java.util.Locale

/** Opt-in microphone foreground service. It listens for the single wake phrase "agent". */
class WakeWordService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var triggered = false
    private var listening = false
    private var stopped = false

    override fun onCreate() {
        super.onCreate()
        Notifications.createChannel(this, Notifications.VOICE_CHANNEL, "Agent wake word", "Visible notification while the wake word listener is active.")
        val notification = Notifications.build(
            this,
            Notifications.VOICE_CHANNEL,
            "NicelyTinned is listening",
            "Microphone active · say ‘agent’ to open the panel · tap Stop in the app to disable"
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopListeningAndSelf()
            return START_NOT_STICKY
        }
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (recognizer == null) startRecognizer()
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun startRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            stopSelf()
            return
        }
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { sr ->
            sr.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: android.os.Bundle?) { listening = true }
                override fun onBeginningOfSpeech() = Unit
                override fun onRmsChanged(rmsdB: Float) = Unit
                override fun onBufferReceived(buffer: ByteArray?) = Unit
                override fun onEndOfSpeech() { listening = false }
                override fun onError(error: Int) {
                    listening = false
                    if (!stopped) handler.postDelayed({ beginListening() }, 1200L)
                }
                override fun onResults(results: android.os.Bundle?) {
                    listening = false
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.joinToString(" ").orEmpty()
                    checkWakePhrase(text)
                    if (!stopped) handler.postDelayed({ beginListening() }, 500L)
                }
                override fun onPartialResults(partialResults: android.os.Bundle?) {
                    val text = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.joinToString(" ").orEmpty()
                    checkWakePhrase(text)
                }
                override fun onEvent(eventType: Int, params: android.os.Bundle?) = Unit
            })
        }
        beginListening()
    }

    private fun beginListening() {
        if (stopped || listening) return
        val sr = recognizer ?: return
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            }
            sr.startListening(intent)
        } catch (_: Exception) {
            handler.postDelayed({ beginListening() }, 1500L)
        }
    }

    private fun checkWakePhrase(text: String) {
        if (triggered || text.isBlank()) return
        val hasWakeWord = Regex("\\bagent\\b", RegexOption.IGNORE_CASE).containsMatchIn(text)
        if (hasWakeWord) {
            triggered = true
            try { recognizer?.stopListening() } catch (_: Exception) { }
            listening = false
            OverlayService.openPanel(this)
            // The wake phrase opens the panel only. The user chooses what prompt to submit.
            handler.postDelayed({ triggered = false }, 1200L)
        }
    }

    private fun stopListeningAndSelf() {
        stopped = true
        handler.removeCallbacksAndMessages(null)
        try { recognizer?.cancel() } catch (_: Exception) { }
        try { recognizer?.destroy() } catch (_: Exception) { }
        recognizer = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopped = true
        handler.removeCallbacksAndMessages(null)
        try { recognizer?.cancel() } catch (_: Exception) { }
        try { recognizer?.destroy() } catch (_: Exception) { }
        recognizer = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.example.agentpanel.voice.START"
        const val ACTION_STOP = "com.example.agentpanel.voice.STOP"
        private const val NOTIFICATION_ID = 4202
    }
}
