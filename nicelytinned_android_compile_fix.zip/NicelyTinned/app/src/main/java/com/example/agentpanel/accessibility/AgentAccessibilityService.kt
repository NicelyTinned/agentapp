package com.example.agentpanel.accessibility

import android.accessibilityservice.AccessibilityService
import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONArray
import org.json.JSONObject
import java.util.ArrayDeque
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

class AgentAccessibilityService : AccessibilityService() {
    private data class NodePath(
        val path: List<Int>,
        val label: String,
        val packageName: String,
        val className: String,
        val viewId: String,
        val createdAt: Long
    )

    private val elementIds = ConcurrentHashMap<String, NodePath>()
    private val idCounter = AtomicInteger(1)

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        when (event?.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,
            AccessibilityEvent.TYPE_WINDOWS_CHANGED,
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED,
            AccessibilityEvent.TYPE_VIEW_SCROLLED -> elementIds.clear()
        }
    }

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        if (instance === this) instance = null
        elementIds.clear()
        super.onDestroy()
    }

    fun searchElements(query: String): String {
        val root = rootInActiveWindow ?: return "No active accessibility window. Open the app you want to use and try again."
        elementIds.clear()
        val needle = query.trim().lowercase()
        val results = JSONArray()
        val queue = ArrayDeque<Pair<AccessibilityNodeInfo, List<Int>>>()
        queue.add(root to emptyList())
        var inspected = 0
        while (queue.isNotEmpty() && inspected < MAX_NODES && results.length() < MAX_RESULTS) {
            val (node, path) = queue.removeFirst()
            inspected++
            // Do not expose text or descriptions from editable/password fields to the model.
            val sensitive = node.isPassword || node.isEditable
            val text = if (sensitive) "" else node.text?.toString().orEmpty()
            val description = if (sensitive) "" else node.contentDescription?.toString().orEmpty()
            val viewId = node.viewIdResourceName.orEmpty()
            val label = listOf(text, description, viewId).filter { it.isNotBlank() }.joinToString(" | ")
            val matches = needle.isBlank() || text.contains(needle, true) || description.contains(needle, true) || viewId.contains(needle, true)
            if (matches && label.isNotBlank()) {
                val id = "el_${idCounter.getAndIncrement()}"
                val packageName = node.packageName?.toString().orEmpty()
                elementIds[id] = NodePath(
                    path, label, packageName, node.className?.toString().orEmpty(),
                    viewId, System.currentTimeMillis()
                )
                val bounds = Rect()
                node.getBoundsInScreen(bounds)
                results.put(JSONObject()
                    .put("id", id)
                    .put("text", text)
                    .put("contentDescription", description)
                    .put("viewId", viewId)
                    .put("className", node.className?.toString().orEmpty())
                    .put("clickable", node.isClickable)
                    .put("enabled", node.isEnabled)
                    .put("editable", node.isEditable)
                    .put("password", node.isPassword)
                    .put("scrollable", node.isScrollable)
                    .put("bounds", "${bounds.left},${bounds.top},${bounds.right},${bounds.bottom}"))
            }
            for (i in 0 until node.childCount) {
                val child = node.getChild(i) ?: continue
                queue.add(child to (path + i))
            }
        }
        return JSONObject()
            .put("packageName", root.packageName?.toString().orEmpty())
            .put("query", query)
            .put("elements", results)
            .put("truncated", inspected >= MAX_NODES || results.length() >= MAX_RESULTS)
            .toString()
    }

    fun clickElement(elementId: String): String {
        val saved = elementIds[elementId] ?: return "Element ID not found or expired. Run search_elements again."
        if (System.currentTimeMillis() - saved.createdAt > ELEMENT_ID_TTL_MS) {
            elementIds.remove(elementId)
            return "Element ID expired. Run search_elements again."
        }
        val root = rootInActiveWindow ?: return "No active window."
        if (!root.packageName?.toString().orEmpty().equals(saved.packageName, true)) {
            elementIds.remove(elementId)
            return "The active app changed. Run search_elements again."
        }
        var node: AccessibilityNodeInfo = root
        for (index in saved.path) {
            node = node.getChild(index) ?: run {
                elementIds.remove(elementId)
                return "Element path changed. Run search_elements again."
            }
        }
        if (!node.isVisibleToUser) {
            elementIds.remove(elementId)
            return "Element is no longer visible. Run search_elements again."
        }
        val targetLabel = if (node.isPassword || node.isEditable) node.viewIdResourceName.orEmpty() else node.labelForAgent()
        val currentClass = node.className?.toString().orEmpty()
        val currentViewId = node.viewIdResourceName.orEmpty()
        if (targetLabel != saved.label || currentClass != saved.className || currentViewId != saved.viewId) {
            elementIds.remove(elementId)
            return "Element content changed since it was found. Run search_elements again."
        }
        var clickable: AccessibilityNodeInfo? = node
        while (clickable != null && !clickable.isClickable) clickable = clickable.parent
        val actionNode = clickable ?: node
        val combinedLabel = listOf(targetLabel, actionNode.labelForAgent()).filter { it.isNotBlank() }.distinct().joinToString(" | ")
        if (isConsequential(combinedLabel)) {
            return "BLOCKED: this appears to be a consequential action ($combinedLabel). The user must tap it manually."
        }
        if (!actionNode.isEnabled) return "Element is disabled."
        val clicked = actionNode.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        if (clicked) {
            elementIds.clear()
            return "Clicked: ${targetLabel.ifBlank { saved.label }}"
        }
        return "Android rejected the click. Try inspecting the screen again."
    }

    fun typeText(text: String): String {
        val root = rootInActiveWindow ?: return "No active accessibility window."
        val focused = findFocusedEditable(root) ?: return "No focused editable field. Tap the field first, then retry."
        if (focused.isPassword) return "BLOCKED: typing into password fields is not supported."
        if (!focused.isEditable) return "The focused element is not editable."
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        val success = focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        return if (success) "Text entered into the focused field (${text.length} characters)." else "Android rejected text entry. Check that the field is focused and editable."
    }

    fun scroll(direction: String): String {
        val forward = when (direction.trim().lowercase()) {
            "down" -> true
            "up" -> false
            else -> return "Invalid direction. Use up or down."
        }
        val root = rootInActiveWindow ?: return "No active accessibility window."
        val scrollable = findScrollable(root) ?: return "No scrollable element found on this screen."
        val action = if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        return if (scrollable.performAction(action)) "Scrolled ${direction.lowercase()}." else "The scroll action was not accepted."
    }

    fun pressBack(): String = if (performGlobalAction(GLOBAL_ACTION_BACK)) "Pressed Back." else "Android did not accept Back."

    fun screenInfo(): String {
        val root = rootInActiveWindow ?: return "No active accessibility window."
        val text = StringBuilder()
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var count = 0
        while (queue.isNotEmpty() && count < MAX_NODES && text.length < 5000) {
            val node = queue.removeFirst()
            count++
            // Screen summaries must not leak text from editable or password fields.
            val label = if (node.isPassword || node.isEditable) {
                node.viewIdResourceName.orEmpty()
            } else node.labelForAgent()
            if (label.isNotBlank()) text.append("• ").append(label).append(if (node.isClickable) " [clickable]" else "").append('\n')
            for (i in 0 until node.childCount) node.getChild(i)?.let(queue::add)
        }
        return JSONObject()
            .put("packageName", root.packageName?.toString().orEmpty())
            .put("windowClass", root.className?.toString().orEmpty())
            .put("accessibleText", text.toString())
            .put("truncated", count >= MAX_NODES || text.length >= 5000)
            .toString()
    }

    private fun findFocusedEditable(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var count = 0
        while (queue.isNotEmpty() && count++ < MAX_NODES) {
            val node = queue.removeFirst()
            if (node.isFocused && node.isEditable) return node
            for (i in 0 until node.childCount) node.getChild(i)?.let(queue::add)
        }
        return null
    }

    private fun findScrollable(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var count = 0
        while (queue.isNotEmpty() && count++ < MAX_NODES) {
            val node = queue.removeFirst()
            if (node.isScrollable && node.isEnabled) return node
            for (i in 0 until node.childCount) node.getChild(i)?.let(queue::add)
        }
        return null
    }

    private fun AccessibilityNodeInfo.labelForAgent(): String = listOf(
        text?.toString().orEmpty(),
        contentDescription?.toString().orEmpty(),
        viewIdResourceName.orEmpty()
    ).filter { it.isNotBlank() }.joinToString(" | ")

    private fun isConsequential(label: String): Boolean {
        val normalized = label.lowercase()
        return CONSEQUENTIAL_TERMS.any { term -> normalized.contains(term) }
    }

    companion object {
        @Volatile var instance: AgentAccessibilityService? = null
            private set
        private const val MAX_NODES = 700
        private const val MAX_RESULTS = 35
        private const val ELEMENT_ID_TTL_MS = 45_000L
        private val CONSEQUENTIAL_TERMS = listOf(
            "send", "post", "share", "purchase", "buy", "pay", "payment", "transfer",
            "delete", "remove", "place order", "submit", "confirm", "checkout", "accept", "agree",
            "allow", "subscribe", "unsubscribe", "install", "uninstall", "reset", "sign out", "log out"
        )
    }
}
