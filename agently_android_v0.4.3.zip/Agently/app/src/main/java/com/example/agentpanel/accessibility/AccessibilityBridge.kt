package com.example.agentpanel.accessibility

import android.view.View
import android.view.WindowManager
object AccessibilityBridge {
    fun isConnected(): Boolean = AgentAccessibilityService.instance != null

    fun addAgentAccessibilityOverlay(view: View, params: WindowManager.LayoutParams): Boolean =
        AgentAccessibilityService.instance?.addAgentAccessibilityOverlay(view, params) ?: false

    fun removeAgentAccessibilityOverlay(view: View): Boolean =
        AgentAccessibilityService.instance?.removeAgentAccessibilityOverlay(view) ?: false

    fun searchElements(query: String): String =
        AgentAccessibilityService.instance?.searchElements(query)
            ?: "Accessibility service is not connected. Enable Agently in Android Settings > Accessibility."

    fun previewClickElement(id: String): String =
        AgentAccessibilityService.instance?.previewClickElement(id)
            ?: "{\"valid\":false,\"message\":\"Accessibility service is not connected. Enable it in Android Settings > Accessibility.\"}"

    fun clickElement(id: String, communicationActionApproved: Boolean = false): String =
        AgentAccessibilityService.instance?.clickElement(id, communicationActionApproved)
            ?: "Accessibility service is not connected. Enable it in Android Settings > Accessibility."

    fun typeText(text: String): String =
        AgentAccessibilityService.instance?.typeText(text)
            ?: "Accessibility service is not connected. Enable it in Android Settings > Accessibility."

    fun scroll(direction: String): String =
        AgentAccessibilityService.instance?.scroll(direction)
            ?: "Accessibility service is not connected. Enable it in Android Settings > Accessibility."

    fun pressBack(): String =
        AgentAccessibilityService.instance?.pressBack()
            ?: "Accessibility service is not connected. Enable it in Android Settings > Accessibility."

    fun getScreenInfo(): String =
        AgentAccessibilityService.instance?.screenInfo()
            ?: "Accessibility service is not connected. Enable it in Android Settings > Accessibility."
}
