package com.example.agentpanel.accessibility

import android.graphics.BitmapFactory
import android.graphics.Rect
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.android.gms.tasks.Tasks
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** On-device OCR for text that an app does not expose through its accessibility tree. */
internal object ScreenTextRecognizer {
    private const val MAX_BLOCKS = 60
    private const val MAX_TEXT_CHARS = 5_000
    private const val MAX_OCR_PIXELS = 12_000_000L
    private const val TASK_TIMEOUT_SECONDS = 12L

    fun recognize(jpeg: ByteArray, excludedBounds: List<Rect>): String {
        if (jpeg.isEmpty()) throw IllegalArgumentException("The screenshot was empty; capture the screen again.")
        val boundsOptions = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(jpeg, 0, jpeg.size, boundsOptions)
        val sourceWidth = boundsOptions.outWidth
        val sourceHeight = boundsOptions.outHeight
        if (sourceWidth <= 0 || sourceHeight <= 0) {
            throw IllegalStateException("Could not read screenshot dimensions for on-device text recognition.")
        }
        // OCR on a sampled copy limits peak memory on high-resolution phones/tablets. Returned
        // boxes are scaled back to native screenshot pixels before being sent to the model.
        val decodeOptions = BitmapFactory.Options().apply {
            var sample = 1
            while (sourceWidth.toLong() / (sample * 2L) * (sourceHeight.toLong() / (sample * 2L)) > MAX_OCR_PIXELS) {
                sample *= 2
            }
            inSampleSize = sample
            inPreferredConfig = android.graphics.Bitmap.Config.ARGB_8888
        }
        val bitmap = BitmapFactory.decodeByteArray(jpeg, 0, jpeg.size, decodeOptions)
            ?: throw IllegalStateException("Could not decode the screenshot for on-device text recognition.")
        val scaleX = sourceWidth.toFloat() / bitmap.width.toFloat()
        val scaleY = sourceHeight.toFloat() / bitmap.height.toFloat()
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        try {
            val image = InputImage.fromBitmap(bitmap, 0)
            val result = Tasks.await(recognizer.process(image), TASK_TIMEOUT_SECONDS, TimeUnit.SECONDS)
            val blocks = JSONArray()
            val combinedText = StringBuilder()
            var included = 0
            var excluded = 0

            for (block in result.textBlocks) {
                if (included >= MAX_BLOCKS || combinedText.length >= MAX_TEXT_CHARS) break
                val detectedBox = block.boundingBox ?: continue
                val box = Rect(
                    (detectedBox.left * scaleX).toInt(),
                    (detectedBox.top * scaleY).toInt(),
                    (detectedBox.right * scaleX).toInt(),
                    (detectedBox.bottom * scaleY).toInt()
                )
                // Never return OCR found inside fields that Accessibility identifies as editable/password.
                if (excludedBounds.any { Rect.intersects(it, box) }) {
                    excluded++
                    continue
                }
                val value = block.text.trim()
                if (value.isBlank()) continue
                val remaining = (MAX_TEXT_CHARS - combinedText.length).coerceAtLeast(0)
                val safeValue = value.take(remaining)
                if (safeValue.isBlank()) break
                combinedText.append(safeValue).append('\n')
                blocks.put(JSONObject()
                    .put("text", safeValue)
                    .put("bounds", JSONObject()
                        .put("left", box.left)
                        .put("top", box.top)
                        .put("right", box.right)
                        .put("bottom", box.bottom))
                    .put("center", JSONObject()
                        .put("x", box.centerX())
                        .put("y", box.centerY())))
                included++
            }

            return JSONObject()
                .put("available", true)
                .put("engine", "Google ML Kit on-device text recognition")
                .put("text", combinedText.toString().trim())
                .put("blocks", blocks)
                .put("blockCount", included)
                .put("excludedEditableFieldBlocks", excluded)
                .put("screenshotWidth", sourceWidth)
                .put("screenshotHeight", sourceHeight)
                .put("ocrProcessingWidth", bitmap.width)
                .put("ocrProcessingHeight", bitmap.height)
                .put("note", "Text bounds use native screenshot pixels. Coordinate clicks still require a fresh inspect_screen screenshot and normal Agently target checks.")
                .toString()
        } finally {
            recognizer.close()
            bitmap.recycle()
        }
    }
}
