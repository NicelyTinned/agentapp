package com.example.agentpanel.accessibility

import android.view.View
import android.view.WindowManager
object AccessibilityBridge {
    data class ScreenCapture(val jpeg: ByteArray, val width: Int, val height: Int)
    data class ScreenTextCapture(val screenshot: ScreenCapture, val recognizedTextJson: String)

    fun isConnected(): Boolean = AgentAccessibilityService.instance != null

    fun addAgentAccessibilityOverlay(view: View, params: WindowManager.LayoutParams): Boolean =
        AgentAccessibilityService.instance?.addAgentAccessibilityOverlay(view, params) ?: false

    fun removeAgentAccessibilityOverlay(view: View): Boolean =
        AgentAccessibilityService.instance?.removeAgentAccessibilityOverlay(view) ?: false

    fun searchElements(query: String): String =
        AgentAccessibilityService.instance?.searchElements(query)
            ?: "Accessibility service is not connected. Enable Agently in Android Settings > Accessibility."

    fun inspectUiTree(): String =
        AgentAccessibilityService.instance?.inspectUiTree()
            ?: "{\"message\":\"Accessibility service is not connected.\",\"elements\":[]}"

    fun previewClickElement(id: String): String =
        AgentAccessibilityService.instance?.previewClickElement(id)
            ?: "{\"valid\":false,\"message\":\"Accessibility service is not connected. Enable it in Android Settings > Accessibility.\"}"

    fun captureScreenshot(): ScreenCapture =
        AgentAccessibilityService.instance?.captureScreenshot()
            ?: throw IllegalStateException("Accessibility service is not connected. Enable it in Android Settings > Accessibility.")

    fun readScreenText(): ScreenTextCapture =
        AgentAccessibilityService.instance?.captureAndReadScreenText()
            ?: throw IllegalStateException("Accessibility service is not connected. Enable it in Android Settings > Accessibility.")

    fun previewClickAt(x: Int, y: Int, screenshotWidth: Int, screenshotHeight: Int): String =
        AgentAccessibilityService.instance?.previewClickAt(x, y, screenshotWidth, screenshotHeight)
            ?: "{\"valid\":false,\"message\":\"Accessibility service is not connected.\"}"

    fun clickAt(
        x: Int, y: Int, screenshotWidth: Int, screenshotHeight: Int,
        communicationActionApproved: Boolean = false, unknownTargetApproved: Boolean = false
    ): String = AgentAccessibilityService.instance?.clickAt(
        x, y, screenshotWidth, screenshotHeight, communicationActionApproved, unknownTargetApproved
    ) ?: "Accessibility service is not connected. Enable it in Android Settings > Accessibility."

    fun clickElement(id: String, communicationActionApproved: Boolean = false): String =
        AgentAccessibilityService.instance?.clickElement(id, communicationActionApproved)
            ?: "Accessibility service is not connected. Enable it in Android Settings > Accessibility."

    fun holdAt(x: Int, y: Int, screenshotWidth: Int, screenshotHeight: Int, durationMs: Long,
               communicationActionApproved: Boolean = false, unknownTargetApproved: Boolean = false): String =
        AgentAccessibilityService.instance?.holdAt(x, y, screenshotWidth, screenshotHeight, durationMs,
            communicationActionApproved, unknownTargetApproved)
            ?: "Accessibility service is not connected. Enable it in Android Settings > Accessibility."

    fun dragAt(startX: Int, startY: Int, endX: Int, endY: Int, screenshotWidth: Int, screenshotHeight: Int,
               durationMs: Long, communicationActionApproved: Boolean = false, unknownTargetApproved: Boolean = false): String =
        AgentAccessibilityService.instance?.dragAt(startX, startY, endX, endY, screenshotWidth, screenshotHeight,
            durationMs, communicationActionApproved, unknownTargetApproved)
            ?: "Accessibility service is not connected. Enable it in Android Settings > Accessibility."

    fun holdElement(id: String, durationMs: Long, communicationActionApproved: Boolean = false): String =
        AgentAccessibilityService.instance?.holdElement(id, durationMs, communicationActionApproved)
            ?: "Accessibility service is not connected. Enable it in Android Settings > Accessibility."

    fun dragElements(startId: String, endId: String, durationMs: Long, communicationActionApproved: Boolean = false): String =
        AgentAccessibilityService.instance?.dragElements(startId, endId, durationMs, communicationActionApproved)
            ?: "Accessibility service is not connected. Enable it in Android Settings > Accessibility."

    fun typeText(text: String): String =
        AgentAccessibilityService.instance?.typeText(text)
            ?: "Accessibility service is not connected. Enable it in Android Settings > Accessibility."

    fun scroll(direction: String): String =
        AgentAccessibilityService.instance?.scroll(direction)
            ?: "Accessibility service is not connected. Enable it in Android Settings > Accessibility."

    fun pressBack(): String =
        AgentAccessibilityService.instance?.pressBack()
            ?: "Accessibility service is not connected. Enable it in Android Settings > Accessibility."

    fun getScreenInfo(): String =
        AgentAccessibilityService.instance?.screenInfo()
            ?: "Accessibility service is not connected. Enable it in Android Settings > Accessibility."
}
