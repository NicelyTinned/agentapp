# Agently Android project

- Replaced the touch-blocking task screen with a passive accessibility-overlay HUD that shows only the latest three actions for the current task. The HUD uses `FLAG_NOT_TOUCHABLE`; the separate Cancel button is the only always-visible touch target.
- Kept outbound send/post approval in a small, non-focusable approval surface; taps outside it continue to the target app.
- Added a hidden UI inspector: while the floating panel is open, tap the Agently logo seven times within three seconds. It displays the underlying app package, node labels, resource IDs, classes, bounds, visibility/focus/clickability, advertised accessibility actions, and clickable ancestors. Ordinary controls can be test-clicked; communication and restricted controls are not activated by the inspector.
- The inspector hides password and editable-field contents.

# Agently for Android

Agently is the Android app from NicelyTinned. It provides a floating task panel, Gemini-powered task processing, optional voice activation, and local conversation/action history.

## Earlier retained changes (0.4.1–0.4.3)

- Added a **Clear History** action in the floating panel's history view and the setup screen's full history dialog. Clearing requires confirmation and deletes only Agently's local conversations/action logs; it does not delete messages or posts in other apps.
- Communication actions such as Send, Post, Share, Comment, and Reply can now be completed after a visible approval for the specific outbound control. Each send/post/share/comment/reply action requires its own approval; choosing Not now blocks further communication actions in that task. The agent is instructed not to report completion after only drafting text or choosing an attachment: it must locate the final action, request approval, activate it, and verify a visible success result.
- The outbound approval card is a compact, non-focusable accessibility overlay. The target app remains visible around it, and tapping outside the card continues to the target app.
- Payment, purchase, money transfer, deletion, account/security, permission, subscription, and other restricted actions remain blocked and must be completed manually.
- The agent now records the communication approval request and decision in its local action history and verifies the result through the app's visible interface before claiming success.

- The app display name and in-app title are now **Agently**. **NicelyTinned** is retained as the company/publisher name.
- Marketing slogans have been removed from the app UI.
- The launcher foreground artwork has been scaled to 65% of its previous size.
- Submitting a task closes the floating panel and opens a compact, passive task HUD. The HUD shows only the latest three actions for the current task. It is a trusted accessibility overlay with `FLAG_NOT_TOUCHABLE`, so taps pass through to the target app. A separate, small, non-focusable Cancel button stops the loop. A separate compact approval prompt appears only when an outbound send/post/share action needs explicit approval.
- Cancel interrupts the agent loop, interrupts bounded waits, and disconnects an active Gemini HTTP request. It prevents later steps from starting. Android actions already dispatched before cancellation cannot be rolled back, and a currently executing system action may finish.
- The task HUD and hidden inspector use accessibility-overlay windows, while app-tree targeting continues to select the underlying application window rather than Agently's own windows.
- Accessibility access is described on the setup screen and again in a consent dialog before Android's Accessibility settings are opened. The disclosure explains that visible interface text, the task prompt, and relevant prior conversation context may be sent to Google Gemini. When Visual Fallback is enabled, screenshots may also be sent when a task needs visual understanding or accessibility cannot identify a useful control. Editable/password contents are excluded from accessibility summaries, but screenshots may contain anything visible on screen.
- The app keeps its existing Android application ID so a properly signed update can replace the previous installation. Version code/name are advanced for each update.

## Build

1. Install Android Studio with Android SDK Platform 36 and JDK 17.
2. Open the `Agently` project folder in Android Studio.
3. Use Gradle 8.13 with JDK 17, sync the Android Gradle Plugin, then build the `app` module on an Android device (API 26+).
4. This source archive does not include an APK, Gradle wrapper, or release keystore. A local Android SDK/Gradle installation is required for a full Android build.

## First-run setup

1. Open **Agently**.
2. Create one or more Gemini API keys in Google AI Studio, paste them into **Gemini API Keys** (one per line), and tap **Add Key**. Keys are encrypted with AES-GCM using an Android Keystore key.
3. Approve **Draw over other apps**.
4. Read the accessibility disclosure in Agently. Continue to Android's Accessibility settings and enable **Agently accessibility service** only if you accept the described access.
5. Tap **Finish Setup**. The floating edge tab appears at the right edge; tap it to open Agently.
6. Type a task and tap the send arrow. While the agent runs, the floating panel closes and a passive status HUD shows the latest three actions. The status HUD is click-through; the separate **Cancel** button stops subsequent agent steps. An action already dispatched to Android or another app cannot be undone by cancellation.
7. Use **View History** for saved conversations and action logs. In the history view, choose **Clear History** to permanently erase Agently's local history after confirmation. Voice activation is optional and separately requires microphone permission.

## Accessibility and Play Protect

The service uses Android's `AccessibilityService` API to inspect visible interface labels and controls and to perform user-requested navigation/actions. The project does **not** set `isAccessibilityTool=true`: that designation is reserved for apps whose primary purpose is direct disability support, and it must not be set simply to avoid security checks. Do not modify the declaration to disguise the app's purpose.

Google's current Play policy says the Accessibility API must not power a general-purpose app that autonomously initiates, plans, and executes actions or decisions. A verified accessibility tool is a narrow exception only when the app's primary purpose is to help people with disabilities. This project is a general-purpose assistant, so it must not claim `isAccessibilityTool=true` merely to get around a warning. The in-app disclosure and consent dialog are transparency safeguards; they do not make this agent eligible or guarantee Play Protect approval.

Google also documents that Play Protect may automatically block internet-sideloaded apps in some markets when they request sensitive permissions such as Accessibility. There is no legitimate source-code flag, name change, icon change, or ordinary signing change that makes an ineligible app trusted. The compliant path is to redesign the automation around narrower Android APIs and user-directed flows, or build a genuine disability-support tool whose primary purpose meets Google's accessibility-tool criteria. Only after verifying policy compliance should a developer use Google's official false-positive review/appeal process.

Official references:
- [Google Play policy: Use of the AccessibilityService API](https://support.google.com/googleplay/android-developer/answer/10964491?hl=en)
- [Google Play policy: Permissions and APIs that access sensitive information](https://support.google.com/googleplay/android-developer/answer/16558241)
- [Google for Developers: Play Protect warning guidance](https://developers.google.com/android/play-protect/warning-dev-guidance)

## Hidden UI debug inspector

While the floating panel is open, tap the centered Agently logo seven times within three seconds. The inspector opens as a non-focusable accessibility overlay, so the underlying app stays the target application. Tap **Refresh** after navigating the app. Each row shows accessibility metadata and a **Test click** action for ordinary controls. The inspector will not test-click outbound communication or restricted controls. Close the inspector before using controls located underneath its panel.

## Tools exposed to Gemini

- `finish(reply: String)`
- `search_internet(query: String)`
- `search_elements(query: String)`
- `click_element(elementId: String, purpose: navigation|preparation|communication)`
- `type_text(text: String)`
- `scroll(direction: String)`
- `press_back()`
- `get_screen_info()`
- `wait_time(milliseconds: Int)` — waits up to 30 seconds.
- `wait_until_element(keyword: String, timeout: Int)` — polls the accessibility tree every 250 ms, up to 60 seconds.

The agent loop has a 36-step safety limit. Ordinary controls can be activated directly. Send, post, share, comment, and reply controls pause the agent until the user approves that specific outbound action. Approval does not carry over to later outbound actions or tasks. A refusal blocks further communication actions during that run. Payment, purchase, money transfer, deletion, account/security changes, permission changes, subscriptions, and other restricted actions remain blocked. For image posts, the agent may navigate an app's existing attachment/photo picker when the user clearly identifies the image; the accessibility service does not inspect the image pixels or infer its contents. Password fields are never typed into. Text entered by `type_text` is redacted in the local action audit.

## Saved history and privacy

Prompts, final replies, and tool events are stored in a local SQLite database. When a new task is submitted, relevant prior conversation context may be included in Gemini requests. API keys are encrypted locally and are not written to the tool history. Visual Screenshots are enabled by default and can be disabled in setup. When enabled, Agently can capture the screen whenever a task needs visual understanding (for example, describing an on-screen photo, image, chart, or document), as well as when accessibility search or clicking cannot identify a control. The screenshot is attached to a Gemini request as image input. Screenshots are not stored in the local action history. The screenshot may include sensitive information visible on screen, so users can disable this feature at any time.

## Project layout

- `MainActivity.kt` — setup, permissions, model/key settings, disclosure, wake-word toggle, and history view.
- `overlay/OverlayService.kt` — floating panel, passive click-through task HUD, Cancel control, and hidden debug inspector.
- `voice/WakeWordService.kt` — explicit foreground `agent` wake-word listener.
- `accessibility/` — Android AccessibilityService, temporary element-ID bridge, and a control preview/action classifier.
- `gemini/GeminiClient.kt` — Gemini REST client, tool declarations, Google Search grounding, and cancellable HTTP requests.
- `agent/AgentRunner.kt` — bounded multi-step tool loop and cancellation handling.
- `storage/ConversationStore.kt` — local SQLite conversation and redacted tool audit.
- `security/KeyVault.kt` — AES-GCM encrypted API-key list using Android Keystore.

## Gradle signing/build configuration

- Base64 keystore decoding uses an explicit `java.util.Base64` import, avoiding the Gradle Kotlin DSL `java` extension name collision.
- Kotlin bytecode targeting is configured with `kotlin.compilerOptions` and `JvmTarget.JVM_17`; the deprecated `android.kotlinOptions.jvmTarget` DSL is no longer used.
- Base64 input is whitespace-tolerant, so wrapped environment-secret values are accepted.

## Signed release APK (GitHub Actions)

The project supports release signing through environment variables. Do not commit a keystore, passwords, or a populated `local.properties` file. The decoded keystore is written only under `app/build/signing/`, which is ignored by Git.

### 1. Create or choose a release keystore

If you do not already have one, create it locally with the JDK `keytool` command:

```bash
keytool -genkeypair -v -keystore nicelytinned-release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias nicelytinned
```

Keep this keystore and its passwords backed up securely. Losing the signing key can prevent you from publishing updates over an app signed with that key. Never upload the keystore to the source repository.

### 2. Add GitHub Actions secrets

In the GitHub repository, open **Settings → Secrets and variables → Actions → New repository secret** and create these four secrets:

- `ANDROID_KEYSTORE_BASE64`: Base64-encoded bytes of the `.jks`/`.keystore` file.
- `ANDROID_KEYSTORE_PASSWORD`: keystore password.
- `ANDROID_KEY_ALIAS`: alias used when creating the key (for the example above, `nicelytinned`).
- `ANDROID_KEY_PASSWORD`: password for that key alias.

Encode the keystore without adding line breaks. On Linux/macOS:

```bash
base64 -w 0 nicelytinned-release.jks
```

On macOS, where `-w` is unavailable:

```bash
base64 < nicelytinned-release.jks | tr -d '\n'
```

On Windows PowerShell:

```powershell
[Convert]::ToBase64String([IO.File]::ReadAllBytes("nicelytinned-release.jks"))
```

Copy the encoded output into the `ANDROID_KEYSTORE_BASE64` secret. Do not paste any signing secret into chat, source files, or commit history.

### 3. Build the signed APK

Open the repository's **Actions** tab, select **Android signed release**, and choose **Run workflow**. The workflow builds `:app:assembleRelease` with JDK 17 and Gradle 8.13, then uploads the APK as the `agently-release-apk` workflow artifact.

For a local release build, export the same four environment variables in your shell and run:

```bash
gradle :app:assembleRelease
```

A release task intentionally fails if any signing variable is missing. Debug builds do not require release secrets.


## 0.4.3 accessibility-overlay click fix

- The full-screen task view is now added by the connected `AccessibilityService` as `TYPE_ACCESSIBILITY_OVERLAY`, rather than as a regular `TYPE_APPLICATION_OVERLAY`.
- Android documents accessibility overlays as the window type that keeps covered application windows introspectable to the accessibility service. This fixes the conflict where Agently covered the app it was trying to inspect and then rejected the target as no longer visible.
- The floating chip and normal panel remain regular application overlays; only the full-screen task surface uses the accessibility-overlay window type.
- The service uses `AccessibilityNodeInfo.ACTION_CLICK` for control activation. It no longer sends fallback coordinate gestures into its own full-screen, touch-intercepting overlay.
- The `sequence` tool from 0.4.2 remains available, including conditional branches and a final summary.


## 0.4.6 visual understanding availability

- Removes the old accessibility-failure-only gate from `inspect_screen`. Gemini may now request a screenshot whenever the user asks about visible visual content (such as “what is in this image?”, a photo, chart, diagram, or document), or when accessibility cannot identify or activate a useful control. A preceding element search or click attempt is no longer required.
- Keeps the Visual Fallback setting as the user's opt-out control. When disabled, screenshot capture and upload are both blocked. When enabled, screenshots are captured through `AccessibilityService.takeScreenshot` (Android 11+) and attached as Gemini image input on the next agent request. Screenshots can contain private on-screen information and are not stored in action history.
- Updates the setup text and accessibility-service disclosure so they accurately describe the expanded screenshot behavior.

## 0.4.5 visual interaction and model selection

- Adds `inspect_screen`, which captures a display screenshot through `AccessibilityService.takeScreenshot` (Android 11+) and attaches the JPEG as Gemini image input on the next agent request. The Visual Fallback setting defaults on and can be switched off; when off, the app does not capture or upload screenshots.
- Adds `click_xy(x, y, screenshotWidth, screenshotHeight, purpose)`. Coordinates are expressed in the exact captured image pixels and mapped to device display coordinates. A screenshot must be the latest delivered image and is invalidated after UI-changing actions. The accessibility tree is checked at the tapped location; restricted actions remain blocked, outbound communication needs its per-action approval, and unlabelled targets need a one-time confirmation.
- Keeps `click_element` and expands the bounded `sequence` tool with `click_xy` steps. `inspect_screen` stays a standalone model tool so the screenshot can be returned to Gemini before the coordinates are selected.
- Adds a searchable query field to the hidden debug inspector. Blank search shows the wider tree; a query searches text, content descriptions and resource IDs.
- Replaces the always-visible model ID input with a dropdown of official Gemini display names. “Refresh List” queries every saved API key (including paginated results) and unions general-purpose `generateContent` models enabled for those keys. The advanced section accepts a custom model ID. The static list is a fallback only; the API key's actual access controls availability.

Visual screenshot capture requires Android 11 or newer and the accessibility service's screenshot capability. Gesture tapping requires the service's gesture capability. A full Android build and device test are still required before release.
