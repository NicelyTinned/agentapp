# NicelyTinned AgentPanel (Android)

A native Android assistant prototype with a floating edge launcher, Gemini function calling, accessibility-backed UI actions, an optional `agent` wake phrase, and local conversation/action history. The interface is styled around the supplied dark-violet NicelyTinned reference: a compact setup flow and a floating agent card with a composer, response panel, and recent actions.

## What's updated

- Rebuilt the setup screen with dark violet gradient cards, purple primary actions, API-key setup, voice activation, permission status rows, and a short setup guide.
- Rebuilt the floating AgentPanel with a centered bot mark, task composer, response card, recent actions, and a history view.
- The panel remembers its unsent draft, last response, and status when it is collapsed and opened again. Text is also saved while typing, so a panel close does not discard the draft.
- Added animated panel open/collapse, a subtle response fade, a draggable header, a working opacity state, and a gentle idle fade after 28 seconds. Interacting with the panel restores full opacity.
- Added bounded retry behavior across saved Gemini keys for authentication, quota, and transient server errors, plus clearer handling of malformed API responses.
- Accessibility element references are invalidated when the active window changes or scrolls and are revalidated against package, class, view ID, label, visibility, and age before a click.
- Editable and password-field contents are omitted from accessibility results. Text entered with the `type_text` tool is redacted in the local action audit and when older history is replayed into model context.
- Agent errors are saved as a completed failure note instead of leaving an empty history reply.

## Model

Default model: `gemini-3.5-flash-lite`. The model ID is editable in the app's Advanced section. Use a model ID available to your Gemini API project.

## Build

1. Install Android Studio with Android SDK Platform 36 and JDK 17.
2. Open the `NicelyTinned` folder in Android Studio.
3. Use Gradle 8.13 with JDK 17, sync the Android Gradle Plugin, then build and install the `app` run configuration on an Android device (API 26+).
4. This source archive does not include an APK or Gradle wrapper binary. A local Android SDK/Gradle installation is required for a full Android build.

## First-run setup

1. Open **NicelyTinned AgentPanel**.
2. Create one or more Gemini API keys in Google AI Studio, paste them into **Gemini API Keys** (one per line), and tap **Add Key**. Keys are encrypted with AES-GCM using an Android Keystore key. The entry is masked while editing.
3. Approve **Draw over other apps**.
4. Enable **NicelyTinned accessibility** in Android's Accessibility settings. Android requires the user to enable accessibility services manually.
5. Tap **Finish Setup**. The floating edge tab appears at the right edge; tap it to open the panel.
6. Type a task and tap the purple send arrow. Use **View History** to switch the recent-action area to the saved conversation and tool log.
7. To use voice activation, enable **Voice Activation** and grant microphone permission. Android displays a persistent microphone notification while the wake-word listener runs. Saying “agent” opens the panel; the word itself is not submitted as a prompt.

## Tools exposed to Gemini

- `finish(reply: String)`
- `search_internet(query: String)`
- `search_elements(query: String)`
- `click_element(elementId: String)`
- `type_text(text: String)`
- `scroll(direction: String)`
- `press_back()`
- `get_screen_info()`
- `wait_time(milliseconds: Int)` — waits up to 30 seconds.
- `wait_until_element(keyword: String, timeout: Int)` — polls the accessibility tree every 250 ms, up to 60 seconds.

The agent loop returns a normal final answer only when Gemini calls `finish`. A 36-step guard and bounded network waits prevent an unbounded agent run. API requests rotate through the saved key pool, retrying eligible authentication/quota/server failures with the next key. Key rotation is not a way to bypass provider quotas, rate limits, billing, or project restrictions.

## Saved history and privacy

The local SQLite database stores prompts, final replies, and tool events. `type_text` audit entries store a character count rather than the literal entered text. Editable/password contents are excluded from the accessibility tree summary. API keys are encrypted locally and are not written to the tool history. Private chain-of-thought is not collected or stored.

## Safety and platform notes

- Accessibility is enabled only after the user turns the service on in Android Settings. The service inspects the active accessibility tree; it does not take screenshots.
- `click_element` refuses controls with consequential labels such as send, post, share, buy, purchase, pay, transfer, delete, remove, submit, checkout, or confirm. The user must perform those final actions manually.
- `type_text` refuses password fields and only works with a currently focused editable control.
- Element IDs are temporary and invalidated when window content changes, scrolls, or the active app changes. Search again if the screen changes or a click is rejected.
- The wake-word feature uses Android `SpeechRecognizer`. Offline processing depends on the installed speech-recognition provider and device configuration; this prototype is not a guaranteed always-on hotword implementation across all Android manufacturers.
- Android may restrict background execution, speech recognition, and overlay behavior depending on OS version, device settings, and manufacturer battery management.
- This is a personal prototype, not a Play-Store-ready accessibility product. Review Google's current Accessibility API and foreground-service policies before distributing it.

## Project layout

- `MainActivity.kt` — setup, permissions, model/key settings, wake-word toggle, and history view.
- `overlay/OverlayService.kt` — persistent floating edge tab and interactive prompt panel.
- `voice/WakeWordService.kt` — explicit, foreground `agent` wake-word listener.
- `accessibility/` — Android AccessibilityService and temporary element-ID bridge.
- `gemini/GeminiClient.kt` — Gemini REST client, function declarations, Google Search grounding, and bounded key rotation/retry.
- `agent/AgentRunner.kt` — multi-step tool loop; normal completion only through `finish`.
- `storage/ConversationStore.kt` — local SQLite conversation and redacted tool audit.
- `security/KeyVault.kt` — AES-GCM encrypted API-key list using Android Keystore.


## Signed release APK (GitHub Actions)

The project supports release signing through environment variables. Do not commit a keystore, passwords, or a populated `local.properties` file. The decoded keystore is written only under `app/build/signing/`, which is ignored by Git.

### 1. Create or choose a release keystore

If you do not already have one, create it locally with the JDK `keytool` command:

```bash
keytool -genkeypair -v -keystore nicelytinned-release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias nicelytinned
```

Keep this keystore and its passwords backed up securely. Losing the signing key can prevent you from publishing updates over an app signed with that key. Never upload the keystore to the source repository.

### 2. Add GitHub Actions secrets

In the GitHub repository, open **Settings → Secrets and variables → Actions → New repository secret** and create these four secrets:

- `ANDROID_KEYSTORE_BASE64`: Base64-encoded bytes of the `.jks`/`.keystore` file.
- `ANDROID_KEYSTORE_PASSWORD`: keystore password.
- `ANDROID_KEY_ALIAS`: alias used when creating the key (for the example above, `nicelytinned`).
- `ANDROID_KEY_PASSWORD`: password for that key alias.

Encode the keystore without adding line breaks. On Linux/macOS:

```bash
base64 -w 0 nicelytinned-release.jks
```

On macOS, where `-w` is unavailable:

```bash
base64 < nicelytinned-release.jks | tr -d '\n'
```

On Windows PowerShell:

```powershell
[Convert]::ToBase64String([IO.File]::ReadAllBytes("nicelytinned-release.jks"))
```

Copy the encoded output into the `ANDROID_KEYSTORE_BASE64` secret. Do not paste any signing secret into chat, source files, or commit history.

### 3. Build the signed APK

Open the repository's **Actions** tab, select **Android signed release**, and choose **Run workflow**. The workflow builds `:app:assembleRelease` with JDK 17 and Gradle 8.13, then uploads the APK as the `nicelytinned-release-apk` workflow artifact.

For a local release build, export the same four environment variables in your shell and run:

```bash
gradle :app:assembleRelease
```

A release task intentionally fails if any signing variable is missing. Debug builds do not require release secrets.
