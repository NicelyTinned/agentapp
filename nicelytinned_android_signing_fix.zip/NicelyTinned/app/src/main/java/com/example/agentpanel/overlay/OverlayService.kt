package com.example.agentpanel.overlay

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.example.agentpanel.MainActivity
import com.example.agentpanel.agent.AgentRunner
import com.example.agentpanel.security.KeyVault
import com.example.agentpanel.storage.ConversationStore
import com.example.agentpanel.util.Notifications

/** Persistent floating agent surface. UI state is saved independently from the overlay view. */
class OverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private lateinit var agentRunner: AgentRunner
    private val mainHandler = Handler(Looper.getMainLooper())
    private val panelPrefs by lazy { getSharedPreferences(PANEL_PREFS, Context.MODE_PRIVATE) }

    private var chipView: View? = null
    private var panelView: View? = null
    private var replyText: TextView? = null
    private var statusText: TextView? = null
    private var recentText: TextView? = null
    private var promptInput: EditText? = null
    private var sendButton: TextView? = null
    private var isBusy = false
    private var showingHistory = false

    private val idleFade = Runnable {
        val panel = panelView ?: return@Runnable
        if (!isBusy && promptInput?.hasFocus() != true) {
            panel.animate().alpha(IDLE_ALPHA).setDuration(420).setInterpolator(DecelerateInterpolator()).start()
        }
    }
    private val workingFade = Runnable {
        if (isBusy) panelView?.animate()?.alpha(WORKING_ALPHA)?.setDuration(360)?.start()
    }

    override fun onCreate() {
        super.onCreate()
        Notifications.createChannel(this, Notifications.OVERLAY_CHANNEL, "NicelyTinned", "Notification while the floating agent panel is active.")
        val notification = Notifications.build(this, Notifications.OVERLAY_CHANNEL, "NicelyTinned is active", "Your floating agent panel is ready.")
        if (Build.VERSION.SDK_INT >= 34) startForeground(4201, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(4201, notification)
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        agentRunner = AgentRunner(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!android.provider.Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_OPEN_PANEL) showPanel() else if (panelView == null) showChip()
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun showChip() {
        if (panelView != null) removePanel()
        if (chipView != null) return
        val chip = TextView(this).apply {
            text = "✦"
            textSize = 28f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = gradientBackground(intArrayOf(PURPLE, PURPLE_DARK), 28f, STROKE)
            elevation = dp(12).toFloat()
            contentDescription = "Open NicelyTinned AgentPanel"
            setOnClickListener { showPanel() }
        }
        val params = WindowManager.LayoutParams(
            dp(58), dp(76), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            x = dp(2)
        }
        try {
            windowManager.addView(chip, params)
            chipView = chip
            chip.scaleX = 0.82f
            chip.scaleY = 0.82f
            chip.alpha = 0f
            chip.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(240).setInterpolator(DecelerateInterpolator()).start()
        } catch (_: Exception) {
            stopSelf()
        }
    }

    private fun showPanel() {
        removeChip()
        if (panelView != null) return

        val shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = gradientBackground(intArrayOf(PANEL_TOP, PANEL_BOTTOM), 26f, STROKE)
            elevation = dp(20).toFloat()
            alpha = 0f
            translationY = dp(14).toFloat()
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_YES
            contentDescription = "NicelyTinned floating agent panel"
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brand = TextView(this).apply {
            text = "✦  NICELYTINNED"
            textSize = 11f
            letterSpacing = 0.12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(MUTED_LAVENDER)
        }
        val settings = TextView(this).apply {
            text = "⚙"
            textSize = 22f
            gravity = Gravity.CENTER
            setTextColor(LAVENDER)
            contentDescription = "Open NicelyTinned setup"
            setOnClickListener {
                bumpIdleTimer()
                startActivity(Intent(this@OverlayService, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
        val collapse = TextView(this).apply {
            text = "×"
            textSize = 28f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            contentDescription = "Collapse agent panel"
            setPadding(dp(8), 0, 0, 0)
            setOnClickListener { collapsePanel() }
        }
        header.addView(brand, LinearLayout.LayoutParams(0, dp(34), 1f))
        attachDrag(brand)
        header.addView(settings, LinearLayout.LayoutParams(dp(38), dp(38)))
        header.addView(collapse, LinearLayout.LayoutParams(dp(34), dp(38)))
        shell.addView(header)

        val logo = buildLogo(dp(66))
        val logoHolder = FrameLayout(this).apply { addView(logo, FrameLayout.LayoutParams(dp(66), dp(66), Gravity.CENTER)) }
        shell.addView(logoHolder, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(78)))

        val title = TextView(this).apply {
            text = "NicelyTinned\nAgentPanel"
            textSize = 20f
            gravity = Gravity.CENTER
            setLineSpacing(0f, 0.96f)
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        }
        shell.addView(title, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = dp(14)
        })

        val composer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = gradientBackground(intArrayOf(COMPOSER_TOP, COMPOSER_BOTTOM), 17f, CARD_STROKE)
            setPadding(dp(10), dp(7), dp(8), dp(7))
        }
        val input = EditText(this).apply {
            hint = "What should I do?"
            setHintTextColor(HINT)
            setTextColor(Color.WHITE)
            textSize = 14f
            minLines = 2
            maxLines = 4
            gravity = Gravity.TOP or Gravity.START
            imeOptions = EditorInfo.IME_ACTION_SEND or EditorInfo.IME_FLAG_NO_EXTRACT_UI
            setPadding(dp(6), dp(6), dp(6), dp(6))
            background = null
            setText(panelPrefs.getString(KEY_DRAFT, "").orEmpty())
            setOnFocusChangeListener { _, hasFocus -> if (hasFocus) brightenPanel() }
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    panelPrefs.edit().putString(KEY_DRAFT, s?.toString().orEmpty()).apply()
                }
                override fun afterTextChanged(s: Editable?) = Unit
            })
        }
        promptInput = input
        val send = TextView(this).apply {
            text = "➤"
            textSize = 23f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = gradientBackground(intArrayOf(PURPLE_LIGHT, PURPLE), 13f, Color.TRANSPARENT)
            contentDescription = "Send task to agent"
            isEnabled = !isBusy
            setOnClickListener { bumpIdleTimer(); submitPrompt() }
            elevation = dp(4).toFloat()
        }
        sendButton = send
        composer.addView(input, LinearLayout.LayoutParams(0, dp(76), 1f))
        composer.addView(send, LinearLayout.LayoutParams(dp(46), dp(46)))
        shell.addView(composer, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = dp(12)
        })
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) { submitPrompt(); true } else false
        }

        val savedTranscript = ConversationStore(this@OverlayService).conversationTranscript(6)
        val restoredTranscript = if (isBusy) savedTranscript else savedTranscript.replace(
            "Working on it…", "This task stopped before a final response. You can retry it."
        )
        val savedStatus = panelPrefs.getString(KEY_STATUS, "Ready to help!") ?: "Ready to help!"
        val restoredStatus = if (!isBusy && (savedStatus.startsWith("Thinking") || savedStatus.startsWith("Using ") || savedStatus.startsWith("Working"))) {
            "Previous task interrupted · ready when you are"
        } else savedStatus
        if (restoredStatus != savedStatus) panelPrefs.edit().putString(KEY_STATUS, restoredStatus).apply()

        val statusRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(2), dp(4), dp(12))
        }
        val statusDot = TextView(this).apply {
            text = "●"
            textSize = 13f
            setTextColor(GREEN)
        }
        val status = TextView(this).apply {
            text = restoredStatus
            textSize = 12f
            setTextColor(Color.rgb(221, 221, 236))
            setPadding(dp(7), 0, 0, 0)
        }
        statusText = status
        statusRow.addView(statusDot)
        statusRow.addView(status)
        shell.addView(statusRow)
        shell.addView(divider())

        val responseLabel = TextView(this).apply {
            text = "AGENT RESPONSE"
            textSize = 10f
            letterSpacing = 0.12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(MUTED_LAVENDER)
            setPadding(dp(2), dp(12), dp(2), dp(7))
        }
        shell.addView(responseLabel)

        val response = TextView(this).apply {
            text = restoredTranscript
            textSize = 13f
            setTextColor(Color.rgb(237, 235, 247))
            setPadding(dp(12), dp(11), dp(12), dp(11))
            background = gradientBackground(intArrayOf(RESPONSE_TOP, RESPONSE_BOTTOM), 15f, CARD_STROKE)
            setTextIsSelectable(true)
            setLineSpacing(dp(2).toFloat(), 1f)
        }
        replyText = response
        val responseScroll = ScrollView(this).apply {
            isFillViewport = false
            addView(response, ScrollView.LayoutParams(ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT))
        }
        shell.addView(responseScroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(112)).apply {
            bottomMargin = dp(10)
        })

        val recentHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val recentTitle = TextView(this).apply {
            text = "Recent Actions"
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        }
        val historyButton = TextView(this).apply {
            text = "View History  ↗"
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(LAVENDER)
            setPadding(dp(7), dp(6), 0, dp(6))
            setOnClickListener { bumpIdleTimer(); showHistory() }
        }
        recentHeader.addView(recentTitle, LinearLayout.LayoutParams(0, dp(34), 1f))
        recentHeader.addView(historyButton)
        shell.addView(recentHeader)

        val recent = TextView(this).apply {
            text = ConversationStore(this@OverlayService).recentActions(4)
            textSize = 11f
            setTextColor(Color.rgb(197, 193, 220))
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = roundBackground(RECENT_BG, 13f, CARD_STROKE)
            setTextIsSelectable(true)
            setLineSpacing(dp(3).toFloat(), 1f)
        }
        recentText = recent
        val recentScroll = ScrollView(this).apply {
            isFillViewport = false
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
            addView(recent, ScrollView.LayoutParams(ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT))
        }
        shell.addView(recentScroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f).apply {
            topMargin = dp(3)
            bottomMargin = dp(4)
        })

        val footer = TextView(this).apply {
            text = "◷   History & action log"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(LAVENDER)
            background = roundBackground(FOOTER_BG, 15f, CARD_STROKE)
            setPadding(dp(10), dp(11), dp(10), dp(11))
            setOnClickListener { bumpIdleTimer(); showHistory() }
        }
        shell.addView(footer, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(42)).apply { topMargin = dp(8) })

        val screenWidth = resources.displayMetrics.widthPixels
        val screenHeight = resources.displayMetrics.heightPixels
        val panelWidth = minOf(dp(370), screenWidth - dp(24))
        val panelHeight = minOf(dp(650), screenHeight - dp(54))
        val params = WindowManager.LayoutParams(
            panelWidth, panelHeight,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            x = dp(12)
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN
        }

        try {
            windowManager.addView(shell, params)
            panelView = shell
            attachIdleReset(shell, composer, input, send, historyButton, footer, collapse, settings, responseScroll, recentScroll, statusRow)
            shell.animate().alpha(1f).translationY(0f).setDuration(260).setInterpolator(DecelerateInterpolator()).start()
            bumpIdleTimer()
        } catch (_: Exception) {
            showChip()
        }
    }

    private fun submitPrompt() {
        if (isBusy) return
        val prompt = promptInput?.text?.toString()?.trim().orEmpty()
        if (prompt.isBlank()) return
        if (KeyVault(this).keyCount() == 0) {
            updateReply("Add a Gemini API key in Setup before sending a task.")
            updateStatus("API key needed")
            return
        }
        isBusy = true
        showingHistory = false
        sendButton?.isEnabled = false
        promptInput?.setText("")
        panelPrefs.edit().putString(KEY_DRAFT, "").putString(KEY_LAST_PROMPT, prompt).apply()
        updateReply("You: $prompt\n\nAgent: Working on it…")
        updateStatus("Working on your task…")
        panelView?.animate()?.alpha(1f)?.setDuration(180)?.start()
        mainHandler.removeCallbacks(idleFade)
        mainHandler.postDelayed(workingFade, WORKING_FADE_DELAY_MS)
        (getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager)?.hideSoftInputFromWindow(promptInput?.windowToken, 0)

        agentRunner.run(prompt, object : AgentRunner.Listener {
            override fun onStatus(status: String) {
                updateStatus(status)
            }

            override fun onFinished(reply: String) {
                isBusy = false
                sendButton?.isEnabled = true
                updateStatus("Finished successfully")
                updateReply(ConversationStore(this@OverlayService).conversationTranscript(6))
                refreshRecentActions()
                bumpIdleTimer()
            }

            override fun onError(message: String) {
                isBusy = false
                sendButton?.isEnabled = true
                updateStatus("Needs attention")
                updateReply(ConversationStore(this@OverlayService).conversationTranscript(6))
                refreshRecentActions()
                bumpIdleTimer()
            }
        })
    }

    private fun showHistory() {
        val recent = recentText ?: return
        showingHistory = !showingHistory
        if (showingHistory) {
            recent.text = ConversationStore(this).historyText(12)
            recent.textSize = 10f
            recent.setTextColor(Color.rgb(221, 218, 237))
        } else {
            recent.text = ConversationStore(this).recentActions(4)
            recent.textSize = 11f
            recent.setTextColor(Color.rgb(197, 193, 220))
        }
        statusText?.text = if (showingHistory) "Showing saved history" else "Recent actions"
        panelPrefs.edit().putString(KEY_STATUS, statusText?.text?.toString().orEmpty()).apply()
    }

    private fun updateReply(value: String) {
        panelPrefs.edit().putString(KEY_REPLY, value).apply()
        replyText?.apply {
            text = value
            alpha = 0.72f
            animate().alpha(1f).setDuration(240).start()
        }
    }

    private fun updateStatus(value: String) {
        panelPrefs.edit().putString(KEY_STATUS, value).apply()
        statusText?.text = value
    }

    private fun refreshRecentActions() {
        if (!showingHistory) recentText?.text = ConversationStore(this).recentActions(4)
    }

    private fun collapsePanel() {
        val panel = panelView ?: return
        panelPrefs.edit().putString(KEY_DRAFT, promptInput?.text?.toString().orEmpty()).apply()
        (getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager)?.hideSoftInputFromWindow(promptInput?.windowToken, 0)
        promptInput?.clearFocus()
        mainHandler.removeCallbacks(idleFade)
        mainHandler.removeCallbacks(workingFade)
        panel.animate().alpha(0f).translationY(dp(12).toFloat()).setDuration(180).withEndAction {
            removePanel()
            showChip()
        }.start()
    }

    private fun brightenPanel() {
        panelView?.animate()?.alpha(1f)?.setDuration(180)?.start()
        mainHandler.removeCallbacks(idleFade)
    }

    private fun bumpIdleTimer() {
        brightenPanel()
        mainHandler.removeCallbacks(idleFade)
        mainHandler.removeCallbacks(workingFade)
        if (isBusy) mainHandler.postDelayed(workingFade, WORKING_FADE_DELAY_MS)
        else mainHandler.postDelayed(idleFade, IDLE_TIMEOUT_MS)
    }

    private fun attachDrag(handle: View) {
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        handle.setOnTouchListener { _, event ->
            val panel = panelView ?: return@setOnTouchListener false
            val params = panel.layoutParams as? WindowManager.LayoutParams ?: return@setOnTouchListener false
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    startX = params.x
                    startY = params.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = (startX - (event.rawX - downX).toInt()).coerceAtLeast(0)
                    params.y = startY + (event.rawY - downY).toInt()
                    try { windowManager.updateViewLayout(panel, params) } catch (_: Exception) { }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    bumpIdleTimer()
                    true
                }
                else -> false
            }
        }
    }

    private fun attachIdleReset(vararg views: View) {
        views.forEach { view ->
            view.setOnTouchListener { _, _ -> bumpIdleTimer(); false }
        }
    }

    private fun buildLogo(size: Int): View {
        val outer = FrameLayout(this).apply {
            background = gradientBackground(intArrayOf(PURPLE_LIGHT, PURPLE_DARK), 20f, Color.TRANSPARENT)
            elevation = dp(7).toFloat()
        }
        val face = TextView(this).apply {
            text = "●   ●"
            textSize = 13f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(PURPLE_LIGHT)
            background = roundBackground(Color.rgb(20, 15, 39), 18f, Color.rgb(236, 228, 255))
        }
        val faceParams = FrameLayout.LayoutParams((size * 0.70f).toInt(), (size * 0.48f).toInt(), Gravity.CENTER).apply {
            topMargin = dp(7)
        }
        outer.addView(face, faceParams)
        val sparkle = TextView(this).apply {
            text = "✦"
            textSize = 17f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        outer.addView(sparkle, FrameLayout.LayoutParams(dp(24), dp(24), Gravity.TOP or Gravity.END))
        return outer
    }

    private fun divider(): View = View(this).apply {
        setBackgroundColor(Color.rgb(62, 54, 88))
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1))
    }

    private fun removeChip() {
        chipView?.let { try { windowManager.removeView(it) } catch (_: Exception) { } }
        chipView = null
    }

    private fun removePanel() {
        panelView?.let { try { windowManager.removeView(it) } catch (_: Exception) { } }
        panelView = null
        replyText = null
        promptInput = null
        statusText = null
        recentText = null
        sendButton = null
    }

    private fun gradientBackground(colors: IntArray, radiusDp: Float, stroke: Int): GradientDrawable = GradientDrawable(
        GradientDrawable.Orientation.TL_BR, colors
    ).apply {
        cornerRadius = dp(radiusDp.toInt()).toFloat()
        if (stroke != Color.TRANSPARENT) setStroke(dp(1), stroke)
    }

    private fun roundBackground(color: Int, radiusDp: Float, stroke: Int = Color.TRANSPARENT): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp.toInt()).toFloat()
        if (stroke != Color.TRANSPARENT) setStroke(dp(1), stroke)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        panelPrefs.edit().putString(KEY_DRAFT, promptInput?.text?.toString().orEmpty()).apply()
        mainHandler.removeCallbacksAndMessages(null)
        removeChip()
        removePanel()
        super.onDestroy()
    }

    companion object {
        const val ACTION_OPEN_PANEL = "com.example.agentpanel.OPEN_PANEL"
        const val ACTION_START = "com.example.agentpanel.START_OVERLAY"
        private const val PANEL_PREFS = "nicelytinned_panel_state"
        private const val KEY_DRAFT = "draft"
        private const val KEY_REPLY = "reply"
        private const val KEY_STATUS = "status"
        private const val KEY_LAST_PROMPT = "last_prompt"
        private const val IDLE_TIMEOUT_MS = 28_000L
        private const val WORKING_FADE_DELAY_MS = 1_800L
        private const val IDLE_ALPHA = 0.84f
        private const val WORKING_ALPHA = 0.90f

        private const val PURPLE = 0xFF6638D7.toInt()
        private const val PURPLE_DARK = 0xFF39208C.toInt()
        private const val PURPLE_LIGHT = 0xFF9B68FF.toInt()
        private const val PANEL_TOP = 0xFF211A35.toInt()
        private const val PANEL_BOTTOM = 0xFF100E1D.toInt()
        private const val COMPOSER_TOP = 0xFF28213E.toInt()
        private const val COMPOSER_BOTTOM = 0xFF1D1930.toInt()
        private const val RESPONSE_TOP = 0xFF2A223F.toInt()
        private const val RESPONSE_BOTTOM = 0xFF201B32.toInt()
        private const val RECENT_BG = 0xFF191528.toInt()
        private const val FOOTER_BG = 0xFF211B35.toInt()
        private const val STROKE = 0xFF51436F.toInt()
        private const val CARD_STROKE = 0xFF403654.toInt()
        private const val MUTED_LAVENDER = 0xFFB7A5E8.toInt()
        private const val LAVENDER = 0xFFC6A8FF.toInt()
        private const val HINT = 0xFF9B91B8.toInt()
        private const val GREEN = 0xFF65E6AA.toInt()

        fun openPanel(context: Context) {
            val intent = Intent(context, OverlayService::class.java).setAction(ACTION_OPEN_PANEL)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent) else context.startService(intent)
        }
    }
}
