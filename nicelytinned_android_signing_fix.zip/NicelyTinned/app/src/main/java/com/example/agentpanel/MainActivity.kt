package com.example.agentpanel

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import com.example.agentpanel.gemini.GeminiClient
import com.example.agentpanel.overlay.OverlayService
import com.example.agentpanel.security.KeyVault
import com.example.agentpanel.storage.ConversationStore
import com.example.agentpanel.voice.WakeWordService

/** Native Android setup screen styled to closely follow the supplied NicelyTinned reference. */
class MainActivity : Activity() {
    private lateinit var vault: KeyVault
    private lateinit var modelInput: EditText
    private lateinit var keysInput: EditText
    private lateinit var statusText: TextView
    private lateinit var voiceSwitch: Switch
    private lateinit var keyCountText: TextView
    private lateinit var overlayPermissionText: TextView
    private lateinit var accessibilityPermissionText: TextView
    private lateinit var micPermissionText: TextView
    private var pendingVoiceEnable = false
    private var voiceSwitchUpdating = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        vault = KeyVault(this)
        buildScreen()
        updateStatus()
        if (intent?.getBooleanExtra(EXTRA_STOP_VOICE, false) == true) stopVoice()
    }

    override fun onResume() {
        super.onResume()
        if (::statusText.isInitialized) updateStatus()
    }

    private fun buildScreen() {
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(28))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(BG_TOP, BG_BOTTOM)).apply { cornerRadius = dp(0).toFloat() }
        }
        val scroll = ScrollView(this).apply {
            fillViewport = true
            clipToPadding = false
            addView(content)
        }

        val topBar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val back = TextView(this).apply {
            text = "‹"
            textSize = 36f
            setTextColor(LAVENDER)
            gravity = Gravity.CENTER
            contentDescription = "Setup"
        }
        topBar.addView(back, LinearLayout.LayoutParams(dp(42), dp(50)))
        topBar.addView(text("Setup", 25f, Color.WHITE, true), LinearLayout.LayoutParams(0, dp(50), 1f))
        val mark = buildLogo(dp(34))
        topBar.addView(mark, LinearLayout.LayoutParams(dp(34), dp(34)))
        content.addView(topBar)
        content.addView(text("Configure your Android agent.", 13f, SUBTEXT, false).apply {
            setPadding(dp(4), 0, 0, dp(16))
        })

        // Gemini API keys card
        val keyCard = card()
        val keyHeader = iconHeading("⚿", "Gemini API Keys", "Add one or more API keys. They will be used in rotation.")
        keyCard.addView(keyHeader)
        keysInput = EditText(this).apply {
            hint = "Paste Gemini API key(s), one per line"
            setHintTextColor(HINT)
            setTextColor(Color.WHITE)
            textSize = 14f
            minLines = 2
            maxLines = 4
            gravity = Gravity.TOP or Gravity.START
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setPadding(dp(13), dp(12), dp(13), dp(12))
            background = rounded(INPUT_BG, 15)
        }
        keyCard.addView(keysInput, matchWrap().apply { topMargin = dp(12); bottomMargin = dp(10) })
        val keyAdd = actionButton("Add Key", true) { saveKeys() }
        keyCard.addView(keyAdd, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(48)))
        keyCountText = text("${vault.keyCount()} saved key(s) · encrypted on this device", 11f, SUBTEXT, false)
        keyCard.addView(keyCountText.apply { setPadding(dp(2), dp(9), 0, 0) })
        val clearKeysLink = text("Clear saved key pool", 10f, LAVENDER, false).apply {
            gravity = Gravity.END
            setPadding(0, dp(7), dp(2), 0)
            isClickable = true
            isFocusable = true
            setOnClickListener { clearKeys() }
        }
        keyCard.addView(clearKeysLink)
        content.addView(keyCard, matchWrap().apply { bottomMargin = dp(12) })

        // Voice activation card
        val voiceCard = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = cardBackground(CARD_TOP, CARD_BOTTOM, 20)
            setPadding(dp(14), dp(10), dp(13), dp(10))
        }
        voiceCard.addView(iconTile("⚙", 46), LinearLayout.LayoutParams(dp(46), dp(46)).apply { rightMargin = dp(12) })
        val voiceText = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        voiceText.addView(text("Voice Activation", 15f, Color.WHITE, true))
        voiceText.addView(text("Say ‘agent’ to open the assistant.", 11f, SUBTEXT, false).apply { setPadding(0, dp(3), 0, 0) })
        voiceCard.addView(voiceText, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        voiceSwitch = Switch(this).apply {
            isChecked = getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean(VOICE_ENABLED, false)
            thumbTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(Color.WHITE, 0xFF8C849F.toInt())
            )
            trackTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(PURPLE_LIGHT, 0xFF494253.toInt())
            )
            setOnCheckedChangeListener { _, checked ->
                if (!voiceSwitchUpdating) {
                    if (checked) enableVoice() else stopVoice()
                }
            }
        }
        voiceCard.addView(voiceSwitch)
        content.addView(voiceCard, matchWrap().apply { bottomMargin = dp(12) })

        // Permission status card
        val permissionCard = card()
        permissionCard.addView(iconHeading("⬡", "Permissions", "Required for the floating panel and on-screen controls."))
        overlayPermissionText = permissionRow(permissionCard, "Draw over other apps") {
            requestOverlayPermission()
        }
        accessibilityPermissionText = permissionRow(permissionCard, "Accessibility Service") {
            openAccessibilitySettings()
        }
        micPermissionText = permissionRow(permissionCard, "Microphone Access") {
            requestMicrophonePermission()
        }
        statusText = text("Checking permissions…", 10f, SUBTEXT, false).apply {
            setPadding(dp(3), dp(7), dp(2), dp(2))
        }
        permissionCard.addView(statusText)
        content.addView(permissionCard, matchWrap().apply { bottomMargin = dp(14) })

        content.addView(actionButton("Finish Setup", true) { finishSetup() }, matchWrap().apply {
            bottomMargin = dp(12)
            height = dp(50)
        })

        val instructions = card()
        val instructionHead = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        instructionHead.addView(TextView(this).apply {
            text = "ⓘ"
            textSize = 20f
            setTextColor(LAVENDER)
        }, LinearLayout.LayoutParams(dp(28), dp(30)))
        instructionHead.addView(text("Setup Instructions", 13f, Color.WHITE, true))
        instructions.addView(instructionHead)
        val instructionBody = text(
            "1. Enable ‘NicelyTinned AgentPanel’ in Android’s Display over other apps settings.\n" +
                "2. Turn on the Accessibility Service.\n" +
                "3. Add your Gemini API key.\n" +
                "4. Tap Finish Setup. You’re all set!",
            11f, SUBTEXT, false
        )
        instructionBody.setPadding(dp(28), dp(5), dp(2), dp(2))
        instructionBody.setLineSpacing(dp(3).toFloat(), 1f)
        instructions.addView(instructionBody)
        content.addView(instructions, matchWrap().apply { bottomMargin = dp(12) })

        val advanced = card()
        advanced.addView(text("Advanced · Gemini model", 13f, Color.WHITE, true))
        modelInput = EditText(this).apply {
            setText(getSharedPreferences(PREFS, MODE_PRIVATE).getString(MODEL_PREF, GeminiClient.DEFAULT_MODEL))
            hint = GeminiClient.DEFAULT_MODEL
            setHintTextColor(HINT)
            setTextColor(Color.WHITE)
            textSize = 12f
            setSingleLine(true)
            setPadding(dp(11), dp(9), dp(11), dp(9))
            background = rounded(INPUT_BG, 12)
        }
        advanced.addView(modelInput, matchWrap().apply { topMargin = dp(8) })
        advanced.addView(actionButton("Save Model", false) { saveModel(); toast("model saved") }, matchWrap().apply { topMargin = dp(8) })
        content.addView(advanced, matchWrap().apply { bottomMargin = dp(14) })

        content.addView(actionButton("View History & Tool Audit", false) { showHistory() }, matchWrap())
        content.addView(actionButton("Stop Floating Panel", false) { stopOverlay() }, matchWrap().apply { topMargin = dp(8) })
        content.addView(text("NicelyTinned AgentPanel · Secure & Private · local-first", 10f, FOOTER_TEXT, false).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(18), 0, 0)
        })
        setContentView(scroll)
    }

    private fun finishSetup() {
        saveModel()
        if (!Settings.canDrawOverlays(this)) {
            toast("Enable Draw over other apps first.")
            requestOverlayPermission()
            return
        }
        startOverlay()
        if (!com.example.agentpanel.accessibility.AccessibilityBridge.isConnected()) {
            toast("Panel started. Enable the Accessibility Service to let the agent interact with apps.")
        } else {
            toast("NicelyTinned is ready.")
        }
    }

    private fun saveKeys() {
        try {
            val keys = keysInput.text.toString().split(Regex("[\\r\\n,]+"))
            vault.saveKeys(keys)
            keysInput.setText("")
            refreshKeyCount()
            toast("saved ${vault.keyCount()} encrypted API key(s)")
        } catch (e: Exception) {
            toast(e.message ?: "could not save keys")
        }
        saveModel()
    }

    private fun clearKeys() {
        AlertDialog.Builder(this)
            .setTitle("Clear API keys?")
            .setMessage("This removes the encrypted key pool from this device.")
            .setNegativeButton("cancel", null)
            .setPositiveButton("clear") { _, _ -> vault.clearKeys(); refreshKeyCount(); toast("key pool cleared") }
            .show()
    }

    private fun saveModel() {
        if (::modelInput.isInitialized) GeminiClient(this, vault).saveModelName(modelInput.text.toString())
    }

    private fun refreshKeyCount() {
        if (::keyCountText.isInitialized) keyCountText.text = "${vault.keyCount()} saved key(s) · encrypted on this device"
    }

    private fun requestOverlayPermission() {
        if (Settings.canDrawOverlays(this)) { toast("overlay permission already enabled"); updateStatus(); return }
        val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        startActivityForResult(intent, REQUEST_OVERLAY)
    }

    private fun openAccessibilitySettings() {
        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    }

    private fun requestMicrophonePermission() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            toast("microphone permission already enabled")
        } else {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQUEST_MIC)
        }
    }

    private fun startOverlay() {
        saveModel()
        if (!Settings.canDrawOverlays(this)) {
            requestOverlayPermission()
            return
        }
        val intent = Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_START)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
        toast("edge panel started")
    }

    private fun stopOverlay() {
        stopService(Intent(this, OverlayService::class.java))
        toast("panel stopped")
    }

    private fun enableVoice() {
        if (!Settings.canDrawOverlays(this)) {
            pendingVoiceEnable = true
            setVoiceSwitchChecked(false)
            requestOverlayPermission()
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            pendingVoiceEnable = true
            setVoiceSwitchChecked(false)
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQUEST_MIC)
            return
        }
        startOverlay()
        val intent = Intent(this, WakeWordService::class.java).setAction(WakeWordService.ACTION_START)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(VOICE_ENABLED, true).apply()
        setVoiceSwitchChecked(true)
        toast("wake word listener enabled · microphone notification is active")
    }

    private fun stopVoice() {
        stopService(Intent(this, WakeWordService::class.java).setAction(WakeWordService.ACTION_STOP))
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(VOICE_ENABLED, false).apply()
        if (::voiceSwitch.isInitialized && voiceSwitch.isChecked) setVoiceSwitchChecked(false)
        toast("wake word listener stopped")
    }

    @Deprecated("Activity result compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_OVERLAY) {
            updateStatus()
            if (pendingVoiceEnable && Settings.canDrawOverlays(this)) {
                pendingVoiceEnable = false
                if (::voiceSwitch.isInitialized) voiceSwitch.isChecked = true else enableVoice()
            }
        }
    }

    @Deprecated("Permission callback compatibility")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_MIC) {
            if (grantResults.firstOrNull() == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                if (pendingVoiceEnable) enableVoice() else updateStatus()
            } else {
                pendingVoiceEnable = false
                if (::voiceSwitch.isInitialized) setVoiceSwitchChecked(false)
                toast("microphone permission was not granted")
                updateStatus()
            }
        }
    }

    private fun setVoiceSwitchChecked(checked: Boolean) {
        if (!::voiceSwitch.isInitialized) return
        voiceSwitchUpdating = true
        voiceSwitch.isChecked = checked
        voiceSwitchUpdating = false
    }

    private fun updateStatus() {
        if (!::statusText.isInitialized) return
        val overlay = Settings.canDrawOverlays(this)
        val accessibility = com.example.agentpanel.accessibility.AccessibilityBridge.isConnected()
        val mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED
        overlayPermissionText.text = permissionValue(overlay)
        overlayPermissionText.setTextColor(if (overlay) GREEN else MUTED)
        accessibilityPermissionText.text = permissionValue(accessibility)
        accessibilityPermissionText.setTextColor(if (accessibility) GREEN else MUTED)
        micPermissionText.text = permissionValue(mic)
        micPermissionText.setTextColor(if (mic) GREEN else MUTED)
        keyCountText.text = "${vault.keyCount()} saved key(s) · encrypted on this device"
        statusText.text = "Overlay: ${if (overlay) "on" else "off"} · Accessibility: ${if (accessibility) "connected" else "not connected"} · Microphone: ${if (mic) "on" else "off"}"
    }

    private fun permissionValue(enabled: Boolean): String = if (enabled) "✓ Enabled" else "Tap to enable"

    private fun showHistory() {
        val view = TextView(this).apply {
            text = ConversationStore(this@MainActivity).historyText(40)
            textSize = 12f
            setTextColor(Color.rgb(35, 28, 52))
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setTextIsSelectable(true)
        }
        val scroll = ScrollView(this).apply { addView(view) }
        AlertDialog.Builder(this).setTitle("Saved history & tool audit").setView(scroll).setPositiveButton("close", null).show()
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(14), dp(14), dp(14))
        background = cardBackground(CARD_TOP, CARD_BOTTOM, 20)
    }

    private fun iconHeading(icon: String, title: String, description: String): LinearLayout {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(iconTile(icon, 42), LinearLayout.LayoutParams(dp(42), dp(42)).apply { rightMargin = dp(12) })
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(text(title, 15f, Color.WHITE, true))
        texts.addView(text(description, 11f, SUBTEXT, false).apply { setPadding(0, dp(3), 0, 0) })
        row.addView(texts, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        return row
    }

    private fun permissionRow(parent: LinearLayout, title: String, action: () -> Unit): TextView {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(3), dp(9), dp(2), dp(5))
            isClickable = true
            isFocusable = true
            setOnClickListener { action() }
        }
        row.addView(TextView(this).apply {
            text = "●"
            textSize = 12f
            setTextColor(GREEN)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(dp(28), dp(28)))
        row.addView(text(title, 12f, Color.WHITE, false), LinearLayout.LayoutParams(0, dp(28), 1f))
        val status = text("Tap to enable", 10f, MUTED, false).apply { gravity = Gravity.CENTER_VERTICAL or Gravity.END }
        row.addView(status, LinearLayout.LayoutParams(dp(94), dp(28)))
        parent.addView(row)
        return status
    }

    private fun iconTile(symbol: String, size: Int): View = FrameLayout(this).apply {
        background = cardBackground(0xFF3E2C78.toInt(), 0xFF251A4A.toInt(), 15)
        addView(TextView(this@MainActivity).apply {
            text = symbol
            textSize = if (symbol.length > 1) 18f else 22f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(LAVENDER)
        }, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
    }

    private fun buildLogo(size: Int): View = FrameLayout(this).apply {
        background = cardBackground(PURPLE_LIGHT, PURPLE, 12)
        addView(TextView(this@MainActivity).apply {
            text = "●  ●"
            textSize = 9f
            gravity = Gravity.CENTER
            setTextColor(PURPLE)
            background = rounded(Color.WHITE, 9)
        }, FrameLayout.LayoutParams((size * .68f).toInt(), (size * .45f).toInt(), Gravity.CENTER))
        addView(TextView(this@MainActivity).apply {
            text = "✦"
            textSize = 13f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }, FrameLayout.LayoutParams(dp(17), dp(17), Gravity.TOP or Gravity.END))
    }

    private fun actionButton(value: String, primary: Boolean, action: () -> Unit) = Button(this).apply {
        text = value
        textSize = if (primary) 14f else 12f
        isAllCaps = false
        typeface = if (primary) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        setTextColor(Color.WHITE)
        background = if (primary) cardBackground(PURPLE_LIGHT, PURPLE, 14) else rounded(SECONDARY_BUTTON, 13)
        stateListAnimator = null
        setOnClickListener { action() }
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean) = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun cardBackground(top: Int, bottom: Int, radiusDp: Int) = GradientDrawable(
        GradientDrawable.Orientation.TL_BR, intArrayOf(top, bottom)
    ).apply {
        cornerRadius = dp(radiusDp).toFloat()
        setStroke(dp(1), CARD_STROKE)
    }

    private fun rounded(color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
        setStroke(dp(1), INPUT_STROKE)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    companion object {
        private const val PREFS = "agent_settings"
        private const val VOICE_ENABLED = "voice_wake_enabled"
        private const val MODEL_PREF = "gemini_model"
        private const val REQUEST_OVERLAY = 701
        private const val REQUEST_MIC = 702
        const val EXTRA_STOP_VOICE = "stop_voice"

        private const val BG_TOP = 0xFF110D20.toInt()
        private const val BG_BOTTOM = 0xFF090811.toInt()
        private const val CARD_TOP = 0xFF242039.toInt()
        private const val CARD_BOTTOM = 0xFF191629.toInt()
        private const val INPUT_BG = 0xFF11101C.toInt()
        private const val INPUT_STROKE = 0xFF443A5F.toInt()
        private const val CARD_STROKE = 0xFF39304F.toInt()
        private const val SECONDARY_BUTTON = 0xFF302849.toInt()
        private const val PURPLE = 0xFF6735D8.toInt()
        private const val PURPLE_LIGHT = 0xFF9B67FF.toInt()
        private const val LAVENDER = 0xFFD0B6FF.toInt()
        private const val SUBTEXT = 0xFFB0A8C7.toInt()
        private const val MUTED = 0xFF9D94B4.toInt()
        private const val HINT = 0xFF8B839F.toInt()
        private const val GREEN = 0xFF62DFA4.toInt()
        private const val FOOTER_TEXT = 0xFF827895.toInt()
    }
}
