package com.example.agentpanel.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback
import android.graphics.Bitmap
import android.graphics.Rect
import android.hardware.HardwareBuffer
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityWindowInfo
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONArray
import org.json.JSONObject
import java.util.ArrayDeque
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import java.io.ByteArrayOutputStream
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executor
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

class AgentAccessibilityService : AccessibilityService() {
    private data class NodePath(
        val path: List<Int>,
        val label: String,
        val packageName: String,
        val className: String,
        val viewId: String,
        val createdAt: Long
    )

    private val elementIds = ConcurrentHashMap<String, NodePath>()
    private val idCounter = AtomicInteger(1)
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    /**
     * Adds Agently's full-screen task surface as an accessibility overlay.
     * Unlike TYPE_APPLICATION_OVERLAY, TYPE_ACCESSIBILITY_OVERLAY is designed
     * to leave the covered application windows introspectable by this service.
     */
    fun addAgentAccessibilityOverlay(view: View, params: WindowManager.LayoutParams): Boolean {
        return try {
            params.type = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
            (getSystemService(WINDOW_SERVICE) as WindowManager).addView(view, params)
            true
        } catch (_: Exception) {
            false
        }
    }

    fun removeAgentAccessibilityOverlay(view: View): Boolean {
        return try {
            (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(view)
            true
        } catch (_: Exception) {
            false
        }
    }


    /** Captures the current display for the explicitly enabled Gemini visual fallback. */
    fun captureScreenshot(): AccessibilityBridge.ScreenCapture {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            throw IllegalStateException("Visual fallback requires Android 11 or newer.")
        }
        val latch = CountDownLatch(1)
        var capture: AccessibilityBridge.ScreenCapture? = null
        var failure: String? = null
        val callbackExecutor = Executor { command -> Thread(command, "AgentlyScreenshot").start() }
        mainHandler.post {
            try {
                takeScreenshot(Display.DEFAULT_DISPLAY, callbackExecutor, object : TakeScreenshotCallback {
                    override fun onSuccess(screenshot: ScreenshotResult) {
                        var hardwareBuffer: HardwareBuffer? = null
                        try {
                            hardwareBuffer = screenshot.hardwareBuffer
                            val hardwareBitmap = Bitmap.wrapHardwareBuffer(hardwareBuffer, screenshot.colorSpace)
                                ?: throw IllegalStateException("Android did not provide a screenshot bitmap.")
                            val source = hardwareBitmap.copy(Bitmap.Config.ARGB_8888, false)
                                ?: throw IllegalStateException("Could not convert the screenshot to a shareable image.")
                            try { hardwareBitmap.recycle() } catch (_: Exception) { }
                            val maxDimension = 1440
                            val scale = minOf(1.0, maxDimension.toDouble() / maxOf(source.width, source.height))
                            val output = if (scale < 1.0) Bitmap.createScaledBitmap(
                                source,
                                (source.width * scale).toInt().coerceAtLeast(1),
                                (source.height * scale).toInt().coerceAtLeast(1),
                                true
                            ) else source
                            val bytes = ByteArrayOutputStream().use { stream ->
                                if (!output.compress(Bitmap.CompressFormat.JPEG, 78, stream)) {
                                    throw IllegalStateException("Could not encode the screenshot.")
                                }
                                stream.toByteArray()
                            }
                            capture = AccessibilityBridge.ScreenCapture(bytes, output.width, output.height)
                            if (output !== source) output.recycle()
                            source.recycle()
                        } catch (error: Exception) {
                            failure = error.message ?: "Screenshot processing failed."
                        } finally {
                            try { hardwareBuffer?.close() } catch (_: Exception) { }
                            latch.countDown()
                        }
                    }

                    override fun onFailure(errorCode: Int) {
                        failure = "Android screenshot capture failed (code $errorCode). Check device support and Accessibility settings."
                        latch.countDown()
                    }
                })
            } catch (error: Exception) {
                failure = error.message ?: "Screenshot capture could not be started."
                latch.countDown()
            }
        }
        if (!latch.await(8, TimeUnit.SECONDS)) {
            throw IllegalStateException("Screenshot capture timed out. Try again after the screen settles.")
        }
        return capture ?: throw IllegalStateException(failure ?: "Screenshot capture returned no image.")
    }

    private data class CoordinateTarget(
        val screenX: Int,
        val screenY: Int,
        val label: String,
        val category: String,
        val known: Boolean
    )

    private fun resolveCoordinateTarget(
        x: Int, y: Int, screenshotWidth: Int, screenshotHeight: Int
    ): Pair<CoordinateTarget?, String> {
        if (screenshotWidth <= 0 || screenshotHeight <= 0) return null to "Screenshot dimensions must be positive."
        if (x < 0 || y < 0 || x >= screenshotWidth || y >= screenshotHeight) {
            return null to "Coordinates are outside the supplied screenshot dimensions."
        }
        val metrics = android.util.DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val screenX = (x.toDouble() * metrics.widthPixels / screenshotWidth).toInt()
        val screenY = (y.toDouble() * metrics.heightPixels / screenshotHeight).toInt()
        if (screenX !in 0 until metrics.widthPixels || screenY !in 0 until metrics.heightPixels) {
            return null to "Mapped coordinates are outside the active display. Capture a fresh screenshot."
        }
        if (isInsideAgentlyTouchableOverlay(screenX, screenY)) {
            return null to "That point belongs to an Agently control, not the app underneath. Choose a target-app coordinate."
        }
        val root = targetAppRoot() ?: return null to "No target app window is available."
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var best: AccessibilityNodeInfo? = null
        var bestArea = Long.MAX_VALUE
        var visited = 0
        while (queue.isNotEmpty() && visited++ < MAX_NODES) {
            val node = queue.removeFirst()
            if (node.isVisibleToUser && node.isEnabled) {
                val bounds = Rect()
                node.getBoundsInScreen(bounds)
                if (bounds.contains(screenX, screenY)) {
                    val area = bounds.width().toLong() * bounds.height().toLong()
                    if (area > 0L && area < bestArea) {
                        best = node
                        bestArea = area
                    }
                }
            }
            for (i in 0 until node.childCount) node.getChild(i)?.let(queue::add)
        }
        val selected = best
        if (selected == null) {
            return CoordinateTarget(screenX, screenY, "Unlabelled screen location ($x, $y)", "unknown", false) to ""
        }
        val labels = mutableListOf<String>()
        var current: AccessibilityNodeInfo? = selected
        var depth = 0
        while (current != null && depth++ < 6) {
            val label = if (current.isPassword || current.isEditable) "" else current.labelForAgent()
            if (label.isNotBlank() && label !in labels) labels.add(label)
            current = current.parent
        }
        val combined = labels.joinToString(" | ")
        val known = combined.isNotBlank()
        val category = if (known) actionCategory(combined) else "unknown"
        val description = combined.ifBlank { "Unlabelled control at ($x, $y)" }
        return CoordinateTarget(screenX, screenY, description, category, known) to ""
    }

    /** Never let visual coordinates accidentally activate Agently's own Cancel/approval/inspector controls. */
    private fun isInsideAgentlyTouchableOverlay(screenX: Int, screenY: Int): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return false
        return try {
            windows.asSequence()
                .filter { it.type == AccessibilityWindowInfo.TYPE_ACCESSIBILITY_OVERLAY }
                .any { window ->
                    val owner = runCatching { window.root?.packageName?.toString().orEmpty() }.getOrDefault("")
                    if (!owner.equals(packageName, ignoreCase = true)) return@any false
                    val touchableRegion = android.graphics.Region()
                    window.getRegionInScreen(touchableRegion)
                    touchableRegion.contains(screenX, screenY)
                }
        } catch (_: Exception) {
            false
        }
    }

    fun previewClickAt(x: Int, y: Int, screenshotWidth: Int, screenshotHeight: Int): String {
        val (target, error) = resolveCoordinateTarget(x, y, screenshotWidth, screenshotHeight)
        if (target == null) return JSONObject().put("valid", false).put("message", error).toString()
        return JSONObject().put("valid", true)
            .put("label", target.label)
            .put("category", target.category)
            .put("knownTarget", target.known)
            .put("screenX", target.screenX)
            .put("screenY", target.screenY)
            .toString()
    }

    /** Performs one tap in display coordinates derived from the exact screenshot dimensions. */
    fun clickAt(
        x: Int, y: Int, screenshotWidth: Int, screenshotHeight: Int,
        communicationActionApproved: Boolean = false, unknownTargetApproved: Boolean = false
    ): String {
        val (target, error) = resolveCoordinateTarget(x, y, screenshotWidth, screenshotHeight)
        val resolved = target ?: return error
        if (resolved.category == "restricted") {
            return "BLOCKED: '${resolved.label}' appears to affect payment, account, security, permissions, or stored data. Complete it manually."
        }
        if (resolved.category == "communication" && !communicationActionApproved) {
            return "NEEDS_APPROVAL: '${resolved.label}' may send or publish content. Obtain approval for this exact action first."
        }
        if (!resolved.known && !unknownTargetApproved) {
            return "NEEDS_CONFIRMATION: The target at ($x, $y) has no readable accessibility label. Ask the user to confirm this one coordinate tap."
        }
        val completed = AtomicBoolean(false)
        val accepted = AtomicBoolean(false)
        val latch = CountDownLatch(1)
        mainHandler.post {
            try {
                val path = android.graphics.Path().apply {
                    moveTo(resolved.screenX.toFloat(), resolved.screenY.toFloat())
                }
                val gesture = android.accessibilityservice.GestureDescription.Builder()
                    .addStroke(android.accessibilityservice.GestureDescription.StrokeDescription(path, 0, 75))
                    .build()
                accepted.set(dispatchGesture(gesture, object : GestureResultCallback() {
                    override fun onCompleted(gestureDescription: android.accessibilityservice.GestureDescription?) {
                        completed.set(true)
                        latch.countDown()
                    }
                    override fun onCancelled(gestureDescription: android.accessibilityservice.GestureDescription?) {
                        completed.set(false)
                        latch.countDown()
                    }
                }, mainHandler))
                if (!accepted.get()) latch.countDown()
            } catch (_: Exception) {
                accepted.set(false)
                latch.countDown()
            }
        }
        if (!latch.await(3, TimeUnit.SECONDS)) return "Coordinate tap timed out; Android did not confirm completion."
        return when {
            completed.get() -> "Tapped coordinate ($x, $y) on ${resolved.label}."
            accepted.get() -> "Android accepted the gesture but cancelled it before completion. Refresh the screenshot and retry."
            else -> "Android rejected the coordinate gesture. Check that gesture control is enabled in Accessibility settings."
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Our own full-screen status/approval UI must not invalidate target-app element IDs.
        val eventPackage = event?.packageName?.toString().orEmpty()
        if (eventPackage.equals(packageName, ignoreCase = true)) return
        when (event?.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,
            AccessibilityEvent.TYPE_WINDOWS_CHANGED -> elementIds.clear()
            // Keep IDs across content/scroll events; resolveClickTarget re-identifies
            // them against the latest accessibility tree before every action.
        }
    }

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        if (instance === this) instance = null
        elementIds.clear()
        super.onDestroy()
    }

    fun searchElements(query: String): String {
        val root = targetAppRoot() ?: return "No active app window. Open the app you want to use and try again."
        elementIds.clear()
        val needle = query.trim().lowercase()
        val results = JSONArray()
        val queue = ArrayDeque<Pair<AccessibilityNodeInfo, List<Int>>>()
        queue.add(root to emptyList())
        var inspected = 0
        while (queue.isNotEmpty() && inspected < MAX_NODES && results.length() < MAX_RESULTS) {
            val (node, path) = queue.removeFirst()
            inspected++
            // Do not expose text or descriptions from editable/password fields to the model.
            val sensitive = node.isPassword || node.isEditable
            val text = if (sensitive) "" else node.text?.toString().orEmpty()
            val description = if (sensitive) "" else node.contentDescription?.toString().orEmpty()
            val viewId = node.viewIdResourceName.orEmpty()
            val className = node.className?.toString().orEmpty()
            val label = listOf(text, description, viewId).filter { it.isNotBlank() }.joinToString(" | ")
            val hasClickAction = node.actionList.any { it.id == AccessibilityNodeInfo.ACTION_CLICK }
            val matches = needle.isBlank() || text.contains(needle, true) || description.contains(needle, true) ||
                viewId.contains(needle, true) || className.contains(needle, true)
            val inspectable = label.isNotBlank() || node.isClickable || hasClickAction
            if (matches && inspectable) {
                // Unlabelled controls can be shown in inspection results, but receive no
                // reusable element ID. The agent must use a fresh visual coordinate instead.
                val id = if (label.isNotBlank()) "el_${idCounter.getAndIncrement()}" else ""
                val packageName = node.packageName?.toString().orEmpty()
                if (id.isNotBlank()) elementIds[id] = NodePath(
                    path, label, packageName, className, viewId, System.currentTimeMillis()
                )
                val bounds = Rect()
                node.getBoundsInScreen(bounds)
                val actionJson = JSONArray()
                node.actionList.forEach { action ->
                    actionJson.put(JSONObject().put("id", action.id).put("label", action.label?.toString().orEmpty()))
                }
                var parent = node.parent
                var clickableAncestor = ""
                var parentDepth = 0
                while (parent != null && parentDepth++ < 8) {
                    val parentHasClickAction = parent.actionList.any { it.id == AccessibilityNodeInfo.ACTION_CLICK }
                    if ((parent.isClickable || parentHasClickAction) && parent.isEnabled && parent.isVisibleToUser) {
                        clickableAncestor = parent.labelForAgent() + if (parentHasClickAction) " [ACTION_CLICK]" else " [clickable]"
                        break
                    }
                    parent = parent.parent
                }
                results.put(JSONObject()
                    .put("id", id)
                    .put("label", label)
                    .put("text", text)
                    .put("contentDescription", description)
                    .put("viewId", viewId)
                    .put("className", className)
                    .put("clickable", node.isClickable)
                    .put("hasClickAction", hasClickAction)
                    .put("enabled", node.isEnabled)
                    .put("visible", node.isVisibleToUser)
                    .put("focusable", node.isFocusable)
                    .put("clickableAncestor", clickableAncestor)
                    .put("actions", actionJson.toString())
                    .put("editable", node.isEditable)
                    .put("password", node.isPassword)
                    .put("scrollable", node.isScrollable)
                    .put("bounds", "${bounds.left},${bounds.top},${bounds.right},${bounds.bottom}"))
            }
            for (i in 0 until node.childCount) {
                val child = node.getChild(i) ?: continue
                queue.add(child to (path + i))
            }
        }
        return JSONObject()
            .put("packageName", root.packageName?.toString().orEmpty())
            .put("query", query)
            .put("elements", results)
            .put("truncated", inspected >= MAX_NODES || results.length() >= MAX_RESULTS)
            .toString()
    }

    /** Developer-only, read-only accessibility tree snapshot for diagnosing unusual controls. */
    fun inspectUiTree(): String {
        val root = targetAppRoot() ?: return JSONObject()
            .put("packageName", "")
            .put("message", "No other app window is available. Open the app you want to inspect and refresh.")
            .put("elements", JSONArray())
            .toString()

        elementIds.clear()
        val results = JSONArray()
        val queue = ArrayDeque<Pair<AccessibilityNodeInfo, List<Int>>>()
        queue.add(root to emptyList())
        var inspected = 0
        while (queue.isNotEmpty() && inspected < DEBUG_MAX_NODES && results.length() < DEBUG_MAX_RESULTS) {
            val (node, path) = queue.removeFirst()
            inspected++
            val sensitive = node.isPassword || node.isEditable
            val text = if (sensitive) "" else node.text?.toString().orEmpty()
            val description = if (sensitive) "" else node.contentDescription?.toString().orEmpty()
            val viewId = node.viewIdResourceName.orEmpty()
            val label = listOf(text, description, viewId).filter { it.isNotBlank() }.joinToString(" | ")
            val actions = node.actionList
            val interesting = label.isNotBlank() || node.isClickable || node.isCheckable || actions.isNotEmpty()
            if (interesting) {
                val id = "dbg_${idCounter.getAndIncrement()}"
                val nodePackage = node.packageName?.toString().orEmpty()
                val className = node.className?.toString().orEmpty()
                elementIds[id] = NodePath(path, label, nodePackage, className, viewId, System.currentTimeMillis())
                val bounds = Rect()
                node.getBoundsInScreen(bounds)
                var parent = node.parent
                var clickableAncestor = ""
                var parentDepth = 0
                while (parent != null && parentDepth++ < 8) {
                    val parentHasClickAction = parent.actionList.any { it.id == AccessibilityNodeInfo.ACTION_CLICK }
                    if ((parent.isClickable || parentHasClickAction) && parent.isEnabled && parent.isVisibleToUser) {
                        clickableAncestor = parent.labelForAgent() + if (parentHasClickAction) " [ACTION_CLICK]" else " [clickable]"
                        break
                    }
                    parent = parent.parent
                }
                val actionJson = JSONArray()
                actions.forEach { action ->
                    actionJson.put(JSONObject()
                        .put("id", action.id)
                        .put("label", action.label?.toString().orEmpty()))
                }
                results.put(JSONObject()
                    .put("id", id)
                    .put("label", label)
                    .put("text", text)
                    .put("contentDescription", description)
                    .put("viewId", viewId)
                    .put("className", className)
                    .put("packageName", nodePackage)
                    .put("clickable", node.isClickable)
                    .put("hasClickAction", actions.any { it.id == AccessibilityNodeInfo.ACTION_CLICK })
                    .put("enabled", node.isEnabled)
                    .put("visible", node.isVisibleToUser)
                    .put("focusable", node.isFocusable)
                    .put("focused", node.isFocused)
                    .put("checkable", node.isCheckable)
                    .put("checked", node.isChecked)
                    .put("longClickable", node.isLongClickable)
                    .put("scrollable", node.isScrollable)
                    .put("clickableAncestor", clickableAncestor)
                    .put("actions", actionJson.toString())
                    .put("bounds", "${bounds.left},${bounds.top},${bounds.right},${bounds.bottom}"))
            }
            for (i in 0 until node.childCount) {
                node.getChild(i)?.let { queue.add(it to (path + i)) }
            }
        }
        return JSONObject()
            .put("packageName", root.packageName?.toString().orEmpty())
            .put("elements", results)
            .put("inspectedNodes", inspected)
            .put("truncated", inspected >= DEBUG_MAX_NODES || results.length() >= DEBUG_MAX_RESULTS)
            .toString()
    }

    private data class ClickTarget(
        val actionNode: AccessibilityNodeInfo,
        val targetLabel: String,
        val combinedLabel: String
    )

    /** Returns the exact visible control and its action class without activating it. */
    fun previewClickElement(elementId: String): String {
        val (target, error) = resolveClickTarget(elementId)
        if (target == null) {
            return JSONObject().put("valid", false).put("message", error).toString()
        }
        return JSONObject()
            .put("valid", true)
            .put("label", target.combinedLabel.ifBlank { target.targetLabel })
            .put("category", actionCategory(target.combinedLabel))
            .toString()
    }

    /**
     * Activates an ordinary control, or a communication control only after the agent runner
     * has obtained explicit approval for this specific outbound action. Restricted account/payment/data actions
     * remain blocked regardless of consent.
     */
    fun clickElement(elementId: String, communicationActionApproved: Boolean = false): String {
        val firstResolution = resolveClickTarget(elementId)
        var resolved = firstResolution.first ?: return firstResolution.second

        // The clickable ancestor can be replaced independently of the matched child.
        // Do not ignore refresh() == false: Android defines it as a detached/stale node.
        var actionNodeFresh = try { resolved.actionNode.refresh() } catch (_: Exception) { false }
        if (!actionNodeFresh) {
            val retry = resolveClickTarget(elementId)
            resolved = retry.first ?: return retry.second
            actionNodeFresh = try { resolved.actionNode.refresh() } catch (_: Exception) { false }
            if (!actionNodeFresh) {
                return "The control was replaced while Agently was preparing the click. Search for it again."
            }
        }

        val category = actionCategory(resolved.combinedLabel)
        if (category == "restricted") {
            return "BLOCKED: '${resolved.combinedLabel}' can change payment, account, security, permissions, or stored data. Complete this action manually."
        }
        if (category == "communication" && !communicationActionApproved) {
            return "NEEDS_APPROVAL: '${resolved.combinedLabel}' can send or publish content. Obtain explicit approval for this specific outbound action before clicking."
        }
        if (!resolved.actionNode.isEnabled || !resolved.actionNode.isVisibleToUser) {
            return "Element is currently unavailable. Search again after the UI settles."
        }
        val clicked = try {
            resolved.actionNode.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        } catch (_: Exception) {
            false
        }
        if (clicked) {
            elementIds.clear()
            return "Clicked: ${resolved.targetLabel.ifBlank { resolved.combinedLabel }}"
        }
        return "Android rejected ACTION_CLICK for '${resolved.combinedLabel}'. The target is still visible, but this app did not expose an actionable accessibility control."
    }

    private fun resolveClickTarget(elementId: String): Pair<ClickTarget?, String> {
        val saved = elementIds[elementId]
            ?: return null to "Element ID not found or expired. Run search_elements again."
        if (System.currentTimeMillis() - saved.createdAt > ELEMENT_ID_TTL_MS) {
            elementIds.remove(elementId)
            return null to "Element ID expired. Run search_elements again."
        }

        var root = targetAppRoot() ?: return null to "No active app window."
        if (!root.packageName?.toString().orEmpty().equals(saved.packageName, true)) {
            elementIds.remove(elementId)
            return null to "The active app changed. Run search_elements again."
        }

        fun matches(candidate: AccessibilityNodeInfo): Boolean {
            val label = if (candidate.isPassword || candidate.isEditable)
                candidate.viewIdResourceName.orEmpty() else candidate.labelForAgent()
            return candidate.packageName?.toString().orEmpty().equals(saved.packageName, true) &&
                label == saved.label &&
                candidate.className?.toString().orEmpty() == saved.className &&
                candidate.viewIdResourceName.orEmpty() == saved.viewId
        }

        fun findFreshMatch(searchRoot: AccessibilityNodeInfo): AccessibilityNodeInfo? {
            val queue = ArrayDeque<AccessibilityNodeInfo>()
            queue.add(searchRoot)
            var visited = 0
            while (queue.isNotEmpty() && visited++ < MAX_NODES) {
                val candidate = queue.removeFirst()
                if (candidate.isVisibleToUser && matches(candidate)) return candidate
                for (i in 0 until candidate.childCount) candidate.getChild(i)?.let(queue::add)
            }
            return null
        }

        // A saved child-index path is only a hint: list/Compose UIs can replace nodes
        // between search and click. Validate the fingerprint and, crucially, honour
        // refresh() == false, which Android documents as a node no longer in the view tree.
        var node: AccessibilityNodeInfo? = root
        for (index in saved.path) {
            node = node?.getChild(index)
            if (node == null) break
        }
        var pathNodeIsFresh = false
        if (node != null && matches(node) && node.isVisibleToUser) {
            pathNodeIsFresh = try { node.refresh() } catch (_: Exception) { false }
        }
        if (!pathNodeIsFresh) {
            root = targetAppRoot() ?: return null to "No active app window."
            node = findFreshMatch(root)
            var treeNodeIsFresh = if (node == null) false else try { node.refresh() } catch (_: Exception) { false }
            if (!treeNodeIsFresh) {
                // One more fresh-root pass handles views replaced during the first lookup.
                root = targetAppRoot() ?: return null to "No active app window."
                node = findFreshMatch(root)
                treeNodeIsFresh = if (node == null) false else try { node.refresh() } catch (_: Exception) { false }
            }
            if (!treeNodeIsFresh) {
                return null to "Element changed or left the active view tree before it could be clicked. Search for it again."
            }
        }

        val currentNode = node ?: return null to "Element could not be re-identified in the current screen. Run search_elements again."
        if (!currentNode.isVisibleToUser || !currentNode.isEnabled) {
            return null to "Element is currently hidden or disabled. Wait for the screen to settle and search again."
        }

        val targetLabel = if (currentNode.isPassword || currentNode.isEditable)
            currentNode.viewIdResourceName.orEmpty() else currentNode.labelForAgent()
        fun exposesClickAction(node: AccessibilityNodeInfo): Boolean =
            node.isClickable || node.actionList.any { it.id == AccessibilityNodeInfo.ACTION_CLICK }

        var clickable: AccessibilityNodeInfo? = currentNode
        while (clickable != null && (!exposesClickAction(clickable) || !clickable.isVisibleToUser || !clickable.isEnabled)) {
            clickable = clickable.parent
        }
        val actionNode = clickable ?: currentNode
        val combinedLabel = listOf(targetLabel, actionNode.labelForAgent())
            .filter { it.isNotBlank() }.distinct().joinToString(" | ")
        return ClickTarget(actionNode, targetLabel, combinedLabel) to ""
    }

    private fun actionCategory(label: String): String {
        // Match complete words/phrases so "submit post" and "confirm send" are
        // treated as outbound communication, without confusing "payment" with "pay".
        val normalized = label.lowercase().replace(Regex("[^a-z0-9]+"), " ").trim()
        fun hasPhrase(phrase: String): Boolean =
            (" $normalized ").contains(" ${phrase.lowercase()} ")

        val communication = listOf(
            "send", "post", "share", "publish", "upload", "comment", "reply"
        )
        val isCommunication = communication.any(::hasPhrase)

        val restricted = listOf(
            "purchase", "buy", "pay", "payment", "money", "bank", "donate", "donation", "tip",
            "transfer", "withdraw", "cash out", "top up", "delete", "remove", "place order",
            "checkout", "accept", "agree", "allow", "permission", "subscribe", "unsubscribe",
            "follow", "unfollow", "block", "report", "install", "uninstall", "reset", "sign out",
            "log out", "change password", "security", "grant access"
        )
        if (restricted.any(::hasPhrase)) return "restricted"

        // Generic confirmation/submit controls are not safe to activate without context.
        // When the same control is clearly a send/post action, the explicit approval gate applies.
        if (hasPhrase("submit") || hasPhrase("confirm")) {
            return if (isCommunication) "communication" else "restricted"
        }
        return if (isCommunication) "communication" else "ordinary"
    }

    fun typeText(text: String): String {
        val root = targetAppRoot() ?: return "No active app window."
        val focused = findFocusedEditable(root) ?: return "No focused editable field. Tap the field first, then retry."
        if (focused.isPassword) return "BLOCKED: typing into password fields is not supported."
        if (!focused.isEditable) return "The focused element is not editable."
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        val success = focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        return if (success) "Text entered into the focused field (${text.length} characters)." else "Android rejected text entry. Check that the field is focused and editable."
    }

    fun scroll(direction: String): String {
        val forward = when (direction.trim().lowercase()) {
            "down" -> true
            "up" -> false
            else -> return "Invalid direction. Use up or down."
        }
        val root = targetAppRoot() ?: return "No active app window."
        val scrollable = findScrollable(root) ?: return "No scrollable element found on this screen."
        val action = if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        return if (scrollable.performAction(action)) "Scrolled ${direction.lowercase()}." else "The scroll action was not accepted."
    }

    fun pressBack(): String = if (performGlobalAction(GLOBAL_ACTION_BACK)) "Pressed Back." else "Android did not accept Back."

    fun screenInfo(): String {
        val root = targetAppRoot() ?: return "No active app window."
        val text = StringBuilder()
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var count = 0
        while (queue.isNotEmpty() && count < MAX_NODES && text.length < 5000) {
            val node = queue.removeFirst()
            count++
            // Screen summaries must not leak text from editable or password fields.
            val label = if (node.isPassword || node.isEditable) {
                node.viewIdResourceName.orEmpty()
            } else node.labelForAgent()
            if (label.isNotBlank()) text.append("• ").append(label).append(if (node.isClickable) " [clickable]" else "").append('\n')
            for (i in 0 until node.childCount) node.getChild(i)?.let(queue::add)
        }
        return JSONObject()
            .put("packageName", root.packageName?.toString().orEmpty())
            .put("windowClass", root.className?.toString().orEmpty())
            .put("accessibleText", text.toString())
            .put("truncated", count >= MAX_NODES || text.length >= 5000)
            .toString()
    }

    /**
     * The run-state overlay belongs to Agently and sits above the target app. Prefer the
     * topmost ordinary application window that is not ours so the agent never inspects
     * or clicks its own progress/history surface.
     */
    private fun targetAppRoot(): AccessibilityNodeInfo? {
        val ownPackage = applicationContext.packageName
        val appWindows: List<AccessibilityWindowInfo> = try {
            windows.filter { it.type == AccessibilityWindowInfo.TYPE_APPLICATION }
        } catch (_: Exception) {
            emptyList()
        }
        for (window in appWindows.sortedByDescending { it.isActive || it.isFocused }) {
            val root = try { window.root } catch (_: Exception) { null } ?: continue
            if (!root.packageName?.toString().orEmpty().equals(ownPackage, true)) return root
        }
        return rootInActiveWindow?.takeIf {
            !it.packageName?.toString().orEmpty().equals(ownPackage, true)
        }
    }

    private fun findFocusedEditable(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var count = 0
        while (queue.isNotEmpty() && count++ < MAX_NODES) {
            val node = queue.removeFirst()
            if (node.isFocused && node.isEditable) return node
            for (i in 0 until node.childCount) node.getChild(i)?.let(queue::add)
        }
        return null
    }

    private fun findScrollable(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var count = 0
        while (queue.isNotEmpty() && count++ < MAX_NODES) {
            val node = queue.removeFirst()
            if (node.isScrollable && node.isEnabled) return node
            for (i in 0 until node.childCount) node.getChild(i)?.let(queue::add)
        }
        return null
    }

    private fun AccessibilityNodeInfo.labelForAgent(): String = listOf(
        text?.toString().orEmpty(),
        contentDescription?.toString().orEmpty(),
        viewIdResourceName.orEmpty()
    ).filter { it.isNotBlank() }.joinToString(" | ")

    companion object {
        @Volatile var instance: AgentAccessibilityService? = null
            private set
        private const val MAX_NODES = 700
        private const val MAX_RESULTS = 35
        private const val DEBUG_MAX_NODES = 900
        private const val DEBUG_MAX_RESULTS = 140
        private const val ELEMENT_ID_TTL_MS = 45_000L
    }
}
