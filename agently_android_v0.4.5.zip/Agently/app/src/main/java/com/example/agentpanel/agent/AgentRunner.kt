package com.example.agentpanel.agent

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Base64
import com.example.agentpanel.accessibility.AccessibilityBridge
import com.example.agentpanel.gemini.GeminiClient
import com.example.agentpanel.security.KeyVault
import com.example.agentpanel.storage.ConversationStore
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.CancellationException
import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

class AgentRunner(context: Context) {
    private val appContext = context.applicationContext
    private val vault = KeyVault(appContext)
    private val store = ConversationStore(appContext)
    private val gemini = GeminiClient(appContext, vault)
    private val mainHandler = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    private val auditExecutor = Executors.newSingleThreadExecutor()

    private class RunControl(val listener: Listener) {
        val cancelled = AtomicBoolean(false)
        val cancellationNotified = AtomicBoolean(false)
        val cancellationRecorded = AtomicBoolean(false)
        @Volatile var turnId: Long = -1L
        @Volatile var future: Future<*>? = null
        @Volatile var pendingApprovalLatch: CountDownLatch? = null
        val communicationDenied = AtomicBoolean(false)
        @Volatile var pendingScreenshot: AccessibilityBridge.ScreenCapture? = null
        @Volatile var latestScreenshotWidth: Int = 0
        @Volatile var latestScreenshotHeight: Int = 0
        @Volatile var latestScreenshotMutationVersion: Long = 0L
        @Volatile var uiMutationVersion: Long = 0L
        @Volatile var coordinateScreenshotValid: Boolean = false
        @Volatile var visualFallbackEligible: Boolean = false
    }

    @Volatile private var activeControl: RunControl? = null

    interface Listener {
        fun onStatus(status: String)
        fun onFinished(reply: String)
        fun onError(message: String)
        fun onCancelled()
        /** Approval is requested separately for each outbound send/post/share/comment/reply action. */
        fun onCommunicationApprovalRequired(actionLabel: String, respond: (Boolean) -> Unit)
        /** One-time confirmation for coordinate taps whose target has no readable accessibility label. */
        fun onCoordinateApprovalRequired(actionLabel: String, respond: (Boolean) -> Unit)
    }

    fun run(prompt: String, listener: Listener) {
        val control = RunControl(listener)
        activeControl = control
        control.future = executor.submit {
            var turnId = -1L
            try {
                ensureActive(control)
                val contextText = store.conversationContext()
                turnId = store.createTurn(prompt)
                control.turnId = turnId
                ensureActive(control)
                val contents = JSONArray().put(
                    JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put(
                        "text", "Conversation history and tool audit:\n$contextText\n\nCurrent user request:\n$prompt"
                    )))
                )

                var steps = 0
                var noToolResponses = 0
                while (steps < MAX_AGENT_STEPS) {
                    ensureActive(control)
                    steps++
                    status(control, "Thinking · step $steps")
                    val response = gemini.generate(contents, forceToolCall = noToolResponses >= 2)
                    ensureActive(control)
                    val candidate = response.optJSONArray("candidates")?.optJSONObject(0)
                        ?: throw IllegalStateException(response.optJSONObject("promptFeedback")?.toString() ?: "Gemini returned no candidate.")
                    val modelContent = candidate.optJSONObject("content")
                        ?: throw IllegalStateException("Gemini returned an empty message.")
                    val parts = modelContent.optJSONArray("parts") ?: JSONArray()
                    data class PendingCall(val name: String, val args: JSONObject, val id: String)
                    val calls = mutableListOf<PendingCall>()
                    for (i in 0 until parts.length()) {
                        val part = parts.optJSONObject(i) ?: continue
                        val call = part.optJSONObject("functionCall") ?: part.optJSONObject("function_call")
                        if (call != null) calls.add(PendingCall(
                            call.optString("name"),
                            call.optJSONObject("args") ?: JSONObject(),
                            call.optString("id")
                        ))
                    }
                    contents.put(modelContent)

                    if (calls.isEmpty()) {
                        noToolResponses++
                        contents.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put(
                            "text", "Do not return a plain-text final answer. Continue the agent loop and call finish(reply) when done. Use another tool if needed."
                        ))))
                        continue
                    }
                    noToolResponses = 0
                    var screenshotDeliveredForBatch = false

                    for (pendingCall in calls) {
                        ensureActive(control)
                        val name = pendingCall.name
                        val args = pendingCall.args
                        val decision = safeActionSummary(name, args)
                        status(control, "Using $name")
                        if (name == "finish") {
                            ensureActive(control)
                            val reply = args.optString("reply").ifBlank { "The task finished, but no reply text was provided." }
                            store.addToolEvent(turnId, name, args, "Agent loop completed through finish().", decision)
                            store.saveReply(turnId, reply)
                            mainHandler.post { if (!control.cancelled.get()) listener.onFinished(reply) }
                            return@submit
                        }
                        val result = executeTool(name, args, control)
                        // Persist the result before checking cancellation so an action that already
                        // reached Android is not silently omitted from the audit if Cancel arrives
                        // immediately afterward. Typed text itself is never written to the audit.
                        val auditArgs = if (name == "type_text") {
                            JSONObject(args.toString()).put("text", "[redacted · ${args.optString("text").length} characters]")
                        } else args
                        store.addToolEvent(turnId, name, auditArgs, result, decision)
                        ensureActive(control)
                        status(control, "Completed $name")
                        val responseData = JSONObject().put("result", result)
                        val functionResponse = JSONObject()
                            .put("name", name)
                            .put("response", responseData)
                        if (pendingCall.id.isNotBlank()) functionResponse.put("id", pendingCall.id)

                        val responsePart = JSONObject().put("functionResponse", functionResponse)
                        val responseParts = JSONArray().put(responsePart)
                        var legacyImageContent: JSONObject? = null
                        val screenshot = control.pendingScreenshot
                        if (screenshot != null) {
                            control.pendingScreenshot = null
                            val stillEnabled = appContext.getSharedPreferences("agent_settings", Context.MODE_PRIVATE)
                                .getBoolean("visual_fallback_enabled", true)
                            if (stillEnabled) {
                                val displayName = "agently-screen.jpg"
                                val imageBytes = Base64.encodeToString(screenshot.jpeg, Base64.NO_WRAP)
                                val imagePart = JSONObject().put("inlineData", JSONObject()
                                    .put("displayName", displayName)
                                    .put("mimeType", "image/jpeg")
                                    .put("data", imageBytes))
                                val imageInstruction = "Current screenshot attached as image input. Dimensions: ${screenshot.width}x${screenshot.height} pixels. Use these exact dimensions for click_xy and capture a new image after every UI change."
                                if (gemini.modelName().startsWith("gemini-3", ignoreCase = true)) {
                                    // Gemini 3 supports image parts embedded in a function response.
                                    responseData.put("image_ref", JSONObject().put("\$ref", displayName))
                                    functionResponse.put("parts", JSONArray().put(imagePart))
                                    responseData.put("result", "$result $imageInstruction")
                                    screenshotDeliveredForBatch = true
                                } else {
                                    // Older generateContent models receive a regular image-bearing user turn
                                    // immediately after the matching function response.
                                    responseData.put("result", "$result $imageInstruction")
                                    legacyImageContent = JSONObject().put("role", "user").put("parts", JSONArray()
                                        .put(JSONObject().put("text", imageInstruction))
                                        .put(imagePart))
                                    screenshotDeliveredForBatch = true
                                }
                            } else {
                                responseData.put("result", "${result} The user disabled Visual Fallback before upload. The screenshot was not attached or transmitted. Continue without visual input.")
                            }
                        }
                        contents.put(JSONObject().put("role", "user").put("parts", responseParts))
                        // For pre-Gemini-3 models, keep the image in a separate user turn,
                        // but only after the corresponding function response has been appended.
                        legacyImageContent?.let(contents::put)
                    }
                    // A screenshot only becomes usable by click_xy on the *next* model turn.
                    // A coordinate call returned in the same batch as inspect_screen was generated
                    // before Gemini had seen the image, so it must not be allowed to tap yet.
                    if (screenshotDeliveredForBatch &&
                        control.latestScreenshotMutationVersion == control.uiMutationVersion) {
                        control.coordinateScreenshotValid = true
                    }
                }
                throw IllegalStateException("Agent reached the $MAX_AGENT_STEPS-step safety limit without calling finish(). No normal final reply was produced.")
            } catch (e: Exception) {
                if (control.cancelled.get() || e is CancellationException || e is InterruptedException) {
                    recordCancellation(control)
                    notifyCancelled(control)
                } else {
                    val message = e.message ?: e.javaClass.simpleName
                    if (turnId > 0) {
                        store.addToolEvent(turnId, "agent_error", JSONObject(), message, "The agent could not complete the request.")
                        store.saveReply(turnId, "Agent stopped: $message")
                    }
                    mainHandler.post { if (!control.cancelled.get()) listener.onError(message) }
                }
            } finally {
                if (activeControl === control) activeControl = null
            }
        }
    }

    /** Stops future steps, interrupts waits and disconnects an in-flight Gemini request. */
    fun cancel() {
        val control = activeControl ?: return
        if (!control.cancelled.compareAndSet(false, true)) return
        control.future?.cancel(true)
        control.pendingApprovalLatch?.countDown()
        gemini.cancelCurrentRequest()
        try {
            auditExecutor.execute {
                recordCancellation(control)
                notifyCancelled(control)
            }
        } catch (_: Exception) {
            notifyCancelled(control)
        }
    }

    fun shutdown() {
        cancel()
        executor.shutdownNow()
        auditExecutor.shutdown()
    }

    private fun ensureActive(control: RunControl) {
        if (control.cancelled.get() || Thread.currentThread().isInterrupted) {
            throw CancellationException("Task cancelled by the user.")
        }
    }

    private fun recordCancellation(control: RunControl) {
        val turnId = control.turnId
        if (turnId <= 0 || !control.cancellationRecorded.compareAndSet(false, true)) return
        try {
            store.addToolEvent(turnId, "agent_cancelled", JSONObject(), "Stopped by the user.", "The user cancelled the running task; no further steps were started.")
            store.saveReply(turnId, "Stopped by you.")
        } catch (_: Exception) { }
    }

    private fun notifyCancelled(control: RunControl) {
        if (!control.cancellationNotified.compareAndSet(false, true)) return
        mainHandler.post { control.listener.onCancelled() }
    }


    private fun executeClickElement(elementId: String, requestedPurpose: String, control: RunControl): String {
        if (elementId.isBlank()) return "A temporary elementId from search_elements is required."
        val preview = try {
            JSONObject(AccessibilityBridge.previewClickElement(elementId))
        } catch (_: Exception) {
            return "Could not validate this control. Search for it again before clicking."
        }
        if (!preview.optBoolean("valid", false)) {
            return preview.optString("message", "This control is no longer available. Search again.")
        }

        val label = preview.optString("label").ifBlank { "the selected control" }
        val purpose = requestedPurpose.trim().lowercase()
        if (purpose !in setOf("navigation", "preparation", "communication")) {
            return "Invalid action purpose. Use navigation, preparation, or communication."
        }
        val category = preview.optString("category", "ordinary")
        if (category == "restricted") {
            return "BLOCKED: '$label' can change payment, account, security, permissions, or stored data. Complete that action manually."
        }
        if (category == "communication" || purpose == "communication") {
            if (control.communicationDenied.get()) {
                return "The user declined an outbound communication action. Do not try another send/post/share control in this task."
            }
            val approved = awaitCommunicationConsent(control, label)
            if (!approved) {
                control.communicationDenied.set(true)
                return "The user did not authorize this outbound action. Do not attempt another communication action in this task."
            }
            ensureActive(control)

            // Re-check the control after the approval pause. The app may have navigated,
            // refreshed, or changed its UI while the user was reviewing the destination.
            val finalPreview = try {
                JSONObject(AccessibilityBridge.previewClickElement(elementId))
            } catch (_: Exception) {
                return "Could not revalidate the approved control. Search for it again before continuing."
            }
            if (!finalPreview.optBoolean("valid", false)) {
                return "The approved control changed or expired. Search for the target again."
            }
            val finalLabel = finalPreview.optString("label").ifBlank { "the selected control" }
            if (!finalLabel.equals(label, ignoreCase = true) || finalPreview.optString("category") == "restricted") {
                return "The approved control no longer matches the reviewed action. No click was performed."
            }
            val result = AccessibilityBridge.clickElement(elementId, communicationActionApproved = true)
            if (result.startsWith("Clicked:", true)) invalidateCoordinateScreenshot(control)
            return result
        }
        ensureActive(control)
        val result = AccessibilityBridge.clickElement(elementId)
        if (result.startsWith("Clicked:", true)) invalidateCoordinateScreenshot(control)
        return result
    }

    private fun executeClickXY(
        x: Int, y: Int, screenshotWidth: Int, screenshotHeight: Int,
        requestedPurpose: String, control: RunControl
    ): String {
        if (screenshotWidth <= 0 || screenshotHeight <= 0) return "A valid screenshotWidth and screenshotHeight are required."
        val visualEnabled = appContext.getSharedPreferences("agent_settings", Context.MODE_PRIVATE)
            .getBoolean("visual_fallback_enabled", true)
        if (!visualEnabled) return "Visual fallback is disabled. Enable it before using screenshot-based coordinates."
        if (!control.coordinateScreenshotValid ||
            screenshotWidth != control.latestScreenshotWidth || screenshotHeight != control.latestScreenshotHeight) {
            return "These coordinates do not match the latest available screenshot. Call inspect_screen again and use its exact dimensions."
        }
        val purpose = requestedPurpose.trim().lowercase()
        if (purpose !in setOf("navigation", "preparation", "communication")) {
            return "Invalid action purpose. Use navigation, preparation, or communication."
        }
        val preview = try { JSONObject(AccessibilityBridge.previewClickAt(x, y, screenshotWidth, screenshotHeight)) }
            catch (_: Exception) { return "Could not inspect the coordinate target. Capture a fresh screenshot and retry." }
        if (!preview.optBoolean("valid", false)) return preview.optString("message", "The coordinate is not available.")
        val label = preview.optString("label").ifBlank { "coordinate ($x, $y)" }
        val category = preview.optString("category", "unknown")
        if (category == "restricted") {
            return "BLOCKED: '$label' appears to affect payment, account, security, permissions, or stored data. Complete it manually."
        }

        var communicationApproved = false
        if (category == "communication" || purpose == "communication") {
            if (control.communicationDenied.get()) return "The user declined an outbound action earlier in this task."
            communicationApproved = awaitCommunicationConsent(control, label)
            if (!communicationApproved) {
                control.communicationDenied.set(true)
                return "The user did not authorize this outbound action."
            }
            ensureActive(control)
        }

        var unknownApproved = preview.optBoolean("knownTarget").not()
        if (unknownApproved) {
            val approved = awaitCoordinateConsent(control, label)
            if (!approved) return "The user declined this unlabelled coordinate tap."
            ensureActive(control)
        }

        // Recheck the target after approval pauses; screen content may have moved.
        val finalPreview = try { JSONObject(AccessibilityBridge.previewClickAt(x, y, screenshotWidth, screenshotHeight)) }
            catch (_: Exception) { return "Could not revalidate the coordinate. Capture a fresh screenshot." }
        if (!finalPreview.optBoolean("valid", false)) return finalPreview.optString("message", "The coordinate target changed.")
        if (finalPreview.optString("label") != label || finalPreview.optString("category", "unknown") == "restricted") {
            return "The coordinate target changed after approval. No tap was performed; capture a fresh screenshot."
        }
        if (finalPreview.optString("category") == "communication" && !communicationApproved) {
            return "The target now appears to be an outbound communication control. Request approval before tapping."
        }
        if (!finalPreview.optBoolean("knownTarget", false) && !unknownApproved) {
            return "The target is unlabelled and needs one-time confirmation before tapping."
        }
        ensureActive(control)
        // A coordinate snapshot is single-use. Never let a delayed or repeated action reuse it.
        invalidateCoordinateScreenshot(control)
        return AccessibilityBridge.clickAt(
            x, y, screenshotWidth, screenshotHeight,
            communicationActionApproved = communicationApproved,
            unknownTargetApproved = unknownApproved
        )
    }

    private fun awaitCoordinateConsent(control: RunControl, actionLabel: String): Boolean {
        ensureActive(control)
        val latch = CountDownLatch(1)
        val approved = AtomicBoolean(false)
        control.pendingApprovalLatch = latch
        status(control, "Waiting for confirmation before an unlabelled tap")
        mainHandler.post {
            if (control.cancelled.get()) latch.countDown()
            else control.listener.onCoordinateApprovalRequired(actionLabel) { decision ->
                if (!control.cancelled.get()) approved.set(decision)
                latch.countDown()
            }
        }
        try {
            while (!latch.await(APPROVAL_POLL_INTERVAL_MS, TimeUnit.MILLISECONDS)) ensureActive(control)
            ensureActive(control)
            return approved.get()
        } catch (_: InterruptedException) {
            Thread.currentThread().interrupt()
            throw CancellationException("Task cancelled while waiting for coordinate confirmation.")
        } finally {
            if (control.pendingApprovalLatch === latch) control.pendingApprovalLatch = null
        }
    }

    /** Pauses the worker until the user approves this specific outbound control. */
    private fun awaitCommunicationConsent(control: RunControl, actionLabel: String): Boolean {
        ensureActive(control)
        val latch = CountDownLatch(1)
        val approved = AtomicBoolean(false)
        control.pendingApprovalLatch = latch
        if (control.turnId > 0) {
            store.addToolEvent(
                control.turnId,
                "communication_approval",
                JSONObject().put("control", actionLabel),
                "Waiting for the user to approve a send/post/share action.",
                "The agent paused before one outbound action and requested individual approval."
            )
        }
        status(control, "Waiting for approval before sending or publishing")
        mainHandler.post {
            if (control.cancelled.get()) {
                latch.countDown()
            } else {
                control.listener.onCommunicationApprovalRequired(actionLabel) { decision ->
                    if (!control.cancelled.get()) approved.set(decision)
                    latch.countDown()
                }
            }
        }
        try {
            while (!latch.await(APPROVAL_POLL_INTERVAL_MS, TimeUnit.MILLISECONDS)) {
                ensureActive(control)
            }
            ensureActive(control)
            val decision = approved.get()
            if (control.turnId > 0) {
                store.addToolEvent(
                    control.turnId,
                    "communication_approval_result",
                    JSONObject().put("control", actionLabel),
                    if (decision) "Approved for this action." else "Declined by the user.",
                    if (decision) "User approved this specific outbound action." else "No further communication actions are allowed in this task."
                )
            }
            return decision
        } catch (_: InterruptedException) {
            Thread.currentThread().interrupt()
            throw CancellationException("Task cancelled while waiting for communication approval.")
        } finally {
            if (control.pendingApprovalLatch === latch) control.pendingApprovalLatch = null
        }
    }

    /** Executes a bounded local macro. Conditions inspect the previous step result, so
     * simple branching does not require another model round-trip for every tap. */
    private fun executeSequence(args: JSONObject, control: RunControl): String {
        val steps = args.optJSONArray("steps") ?: return "sequence requires a steps array."
        if (steps.length() == 0) return "sequence has no steps."
        if (steps.length() > MAX_SEQUENCE_STEPS) return "sequence is limited to $MAX_SEQUENCE_STEPS steps."
        val log = JSONArray()
        var previous = ""
        var summary = args.optString("summary").trim()
        for (i in 0 until steps.length()) {
            ensureActive(control)
            val step = steps.optJSONObject(i) ?: continue
            val action = step.optString("action").lowercase()
            val condition = step.optString("if", "always").lowercase()
            val previousOk = previous.startsWith("Clicked:") || previous.startsWith("Text entered") ||
                previous.startsWith("Scrolled") || previous.startsWith("Pressed Back") || previous.startsWith("Found ")
            val shouldRun = when (condition) {
                "always" -> true
                "success" -> previousOk
                "failure" -> previous.isNotBlank() && !previousOk
                "found" -> previous.contains("Found ") || previous.contains("matching element")
                "not_found" -> previous.contains("No matching") || previous.contains("could not be found", true) || previous.contains("Timed out")
                else -> false
            }
            if (!shouldRun) {
                log.put(JSONObject().put("step", i + 1).put("action", action).put("status", "skipped").put("if", condition))
                continue
            }
            val result = when (action) {
                "search" -> {
                    val query = step.optString("target").ifBlank { step.optString("query") }
                    if (query.isBlank()) "Search step requires target/query." else {
                        val found = AccessibilityBridge.searchElements(query)
                        control.visualFallbackEligible = searchNeedsVisualFallback(found)
                        if (runCatching { JSONObject(found).optJSONArray("elements")?.length() ?: 0 }.getOrDefault(0) > 0) "Found matching element(s): $found" else found
                    }
                }
                "click" -> {
                    val target = step.optString("target").ifBlank { step.optString("query") }
                    if (target.isBlank()) "Click step requires target." else {
                        val search = AccessibilityBridge.searchElements(target)
                        val elements = runCatching { JSONObject(search).optJSONArray("elements") }.getOrNull()
                        val id = elements?.optJSONObject(0)?.optString("id").orEmpty()
                        if (id.isBlank()) {
                            control.visualFallbackEligible = true
                            "No matching element found for '$target'."
                        } else {
                            val clickResult = executeClickElement(id, step.optString("purpose", "navigation"), control)
                            control.visualFallbackEligible = clickNeedsVisualFallback(clickResult)
                            clickResult
                        }
                    }
                }
                "click_xy" -> {
                    val clickResult = executeClickXY(
                        step.optInt("x", -1), step.optInt("y", -1),
                        step.optInt("screenshotWidth", -1), step.optInt("screenshotHeight", -1),
                        step.optString("purpose", "navigation"), control
                    )
                    control.visualFallbackEligible = clickNeedsVisualFallback(clickResult)
                    clickResult
                }
                "type" -> AccessibilityBridge.typeText(step.optString("text")).also { invalidateCoordinateScreenshot(control) }
                "scroll" -> AccessibilityBridge.scroll(step.optString("direction", "down")).also { invalidateCoordinateScreenshot(control) }
                "wait" -> waitTime(step.optLong("milliseconds", 300L), control).also { invalidateCoordinateScreenshot(control) }
                "back" -> AccessibilityBridge.pressBack().also { invalidateCoordinateScreenshot(control) }
                "summary" -> {
                    val note = step.optString("text").ifBlank { step.optString("summary") }
                    if (note.isNotBlank()) summary = note
                    "Sequence summary recorded."
                }
                else -> "Unsupported sequence action '$action'."
            }
            previous = result
            log.put(JSONObject().put("step", i + 1).put("action", action).put("result", result.take(900)))
            status(control, "Sequence · ${i + 1}/${steps.length()} · $action")
            if (result.startsWith("BLOCKED:") || result.startsWith("NEEDS_APPROVAL:") ||
                result.startsWith("NEEDS_CONFIRMATION:") || result.startsWith("The user did not authorize") ||
                result.startsWith("The user declined")) break
        }
        val outcome = JSONObject().put("steps", log).put("lastResult", previous)
            .put("summary", summary.ifBlank { "Sequence completed ${log.length()} step(s)." })
        return outcome.toString()
    }

    private fun executeTool(name: String, args: JSONObject, control: RunControl): String = try {
        ensureActive(control)
        when (name) {
            "search_internet" -> gemini.searchInternet(args.optString("query"))
            "search_elements" -> {
                val result = AccessibilityBridge.searchElements(args.optString("query"))
                control.visualFallbackEligible = searchNeedsVisualFallback(result)
                result
            }
            "inspect_screen" -> {
                val visualEnabled = appContext.getSharedPreferences("agent_settings", Context.MODE_PRIVATE)
                    .getBoolean("visual_fallback_enabled", true)
                when {
                    !visualEnabled -> "Visual fallback is disabled in Agently settings. Do not capture or send screenshots. Continue with accessibility tools."
                    !control.visualFallbackEligible -> "Screenshot not captured: first search for the target or try click_element. Visual fallback is available only after accessibility cannot locate or activate a useful control."
                    else -> {
                        status(control, "Capturing screen for visual inspection")
                        val capture = AccessibilityBridge.captureScreenshot()
                        control.pendingScreenshot = capture
                        control.latestScreenshotWidth = capture.width
                        control.latestScreenshotHeight = capture.height
                        control.latestScreenshotMutationVersion = control.uiMutationVersion
                        control.coordinateScreenshotValid = false
                        control.visualFallbackEligible = false
                        "Captured the current screen (${capture.width}x${capture.height}). The image will be attached to this tool response for visual inspection."
                    }
                }
            }
            "click_element" -> {
                val result = executeClickElement(args.optString("elementId"), args.optString("purpose"), control)
                control.visualFallbackEligible = clickNeedsVisualFallback(result)
                result
            }
            "click_xy" -> {
                val result = executeClickXY(
                    args.optInt("x", -1), args.optInt("y", -1),
                    args.optInt("screenshotWidth", -1), args.optInt("screenshotHeight", -1),
                    args.optString("purpose"), control
                )
                control.visualFallbackEligible = clickNeedsVisualFallback(result)
                result
            }
            "type_text" -> AccessibilityBridge.typeText(args.optString("text")).also { invalidateCoordinateScreenshot(control) }
            "scroll" -> AccessibilityBridge.scroll(args.optString("direction")).also { invalidateCoordinateScreenshot(control) }
            "press_back" -> AccessibilityBridge.pressBack().also { invalidateCoordinateScreenshot(control) }
            "get_screen_info" -> AccessibilityBridge.getScreenInfo()
            "wait_time" -> waitTime(args.optLong("milliseconds", -1L), control).also { invalidateCoordinateScreenshot(control) }
            "wait_until_element" -> waitUntilElement(args.optString("keyword"), args.optLong("timeout", -1L), control).also { invalidateCoordinateScreenshot(control) }
            "sequence" -> executeSequence(args, control)
            else -> "Unknown tool: $name"
        }
    } catch (e: CancellationException) {
        throw e
    } catch (e: InterruptedException) {
        Thread.currentThread().interrupt()
        throw CancellationException("Task cancelled by the user.")
    } catch (e: Exception) {
        if (control.cancelled.get() || Thread.currentThread().isInterrupted) throw CancellationException("Task cancelled by the user.")
        "Tool error: ${e.message ?: e.javaClass.simpleName}"
    }

    private fun invalidateCoordinateScreenshot(control: RunControl) {
        control.uiMutationVersion += 1L
        control.coordinateScreenshotValid = false
        control.latestScreenshotWidth = 0
        control.latestScreenshotHeight = 0
    }

    private fun searchNeedsVisualFallback(raw: String): Boolean {
        return try {
            val elements = JSONObject(raw).optJSONArray("elements") ?: return true
            if (elements.length() == 0) return true
            (0 until elements.length()).none { index ->
                val item = elements.optJSONObject(index) ?: return@none false
                item.optBoolean("clickable") || item.optBoolean("hasClickAction") ||
                    item.optString("clickableAncestor").isNotBlank()
            }
        } catch (_: Exception) {
            true
        }
    }

    private fun clickNeedsVisualFallback(result: String): Boolean {
        val normalized = result.trim()
        if (normalized.startsWith("Clicked:", true) ||
            normalized.startsWith("BLOCKED:", true) ||
            normalized.startsWith("NEEDS_APPROVAL:", true) ||
            normalized.startsWith("NEEDS_CONFIRMATION:", true) ||
            normalized.startsWith("The user", true) ||
            normalized.startsWith("Invalid action purpose", true)) return false
        return normalized.isNotBlank()
    }

    private fun safeActionSummary(tool: String, args: JSONObject): String = when (tool) {
        "search_internet" -> "Search the public web for: ${args.optString("query").take(90)}"
        "search_elements" -> "Find visible accessibility elements matching: ${args.optString("query").take(90)}"
        "inspect_screen" -> "Capture the current screen for Gemini visual inspection; transmission is controlled by the Visual Fallback setting."
        "click_element" -> "Activate temporary UI element ${args.optString("elementId")} for purpose '${args.optString("purpose")}'. Each outbound communication click requires individual user approval; restricted account/payment/data actions remain blocked."
        "click_xy" -> "Tap screenshot coordinate (${args.optInt("x")}, ${args.optInt("y")}) using screenshot dimensions ${args.optInt("screenshotWidth")}x${args.optInt("screenshotHeight")}; restricted and unlabelled targets are checked before tapping."
        "type_text" -> "Enter user-provided text into the focused editable field; text contents are omitted from this summary."
        "scroll" -> "Scroll the current screen ${args.optString("direction")}."
        "press_back" -> "Navigate back one screen."
        "get_screen_info" -> "Inspect the active app's accessibility labels and window information."
        "wait_time" -> "Wait for ${args.optLong("milliseconds")} milliseconds before continuing."
        "wait_until_element" -> "Wait up to ${args.optLong("timeout")} milliseconds for an element matching '${args.optString("keyword").take(70)}'."
        "sequence" -> "Run a bounded local sequence of UI searches, clicks, typing, waits, and conditional steps."
        "finish" -> "Return the final reply and end the agent loop."
        else -> "Use $tool to continue the requested task."
    }

    private fun waitTime(requestedMs: Long, control: RunControl): String {
        if (requestedMs < 0L) return "Invalid milliseconds. Provide a non-negative duration."
        val duration = requestedMs.coerceAtMost(MAX_WAIT_TIME_MS)
        Thread.sleep(duration)
        ensureActive(control)
        return if (duration == requestedMs) "Waited ${duration} ms."
        else "Waited ${duration} ms (capped from the requested ${requestedMs} ms)."
    }

    private fun waitUntilElement(keyword: String, requestedTimeoutMs: Long, control: RunControl): String {
        if (keyword.isBlank()) return "A non-empty keyword is required."
        if (requestedTimeoutMs <= 0L) return "Invalid timeout. Provide a positive timeout in milliseconds."
        val timeoutMs = requestedTimeoutMs.coerceAtMost(MAX_WAIT_UNTIL_MS)
        val deadline = System.nanoTime() + timeoutMs * 1_000_000L
        var lastResult = ""
        while (System.nanoTime() < deadline) {
            ensureActive(control)
            lastResult = AccessibilityBridge.searchElements(keyword)
            if (lastResult.startsWith("Accessibility service is not connected")) return lastResult
            try {
                val matches = JSONObject(lastResult).optJSONArray("elements")
                if (matches != null && matches.length() > 0) {
                    return "Found ${matches.length()} matching element(s): $lastResult"
                }
            } catch (_: Exception) {
                // A status message such as 'No active window' is not a match; keep waiting.
            }
            val remainingMs = ((deadline - System.nanoTime()) / 1_000_000L).coerceAtLeast(1L)
            Thread.sleep(minOf(WAIT_POLL_INTERVAL_MS, remainingMs))
        }
        ensureActive(control)
        return "Timed out after ${timeoutMs} ms waiting for '$keyword'. Last screen search: ${lastResult.ifBlank { "no active accessibility window" }}"
    }

    private fun status(control: RunControl, value: String) {
        ensureActive(control)
        mainHandler.post { if (!control.cancelled.get()) control.listener.onStatus(value) }
    }

    companion object {
        private const val MAX_AGENT_STEPS = 36
        private const val MAX_SEQUENCE_STEPS = 20
        private const val MAX_WAIT_TIME_MS = 30_000L
        private const val MAX_WAIT_UNTIL_MS = 60_000L
        private const val WAIT_POLL_INTERVAL_MS = 250L
        private const val APPROVAL_POLL_INTERVAL_MS = 150L
    }
}
