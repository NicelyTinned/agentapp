package com.example.agentpanel.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONArray
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey

/** Encrypts the user-managed Gemini key pool with an AES-GCM key held by Android Keystore. */
class KeyVault(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("key_vault", Context.MODE_PRIVATE)
    private val lock = Any()

    fun saveKeys(rawKeys: List<String>) {
        val keys = rawKeys.map { it.trim() }.filter { it.isNotEmpty() }.distinct()
        require(keys.isNotEmpty()) { "Add at least one API key." }
        val json = JSONArray()
        keys.forEach { json.put(it) }
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        val encrypted = cipher.doFinal(json.toString().toByteArray(StandardCharsets.UTF_8))
        val packed = cipher.iv + encrypted
        prefs.edit().putString(KEYS_BLOB, Base64.encodeToString(packed, Base64.NO_WRAP)).putInt(NEXT_INDEX, 0).apply()
    }

    fun keyCount(): Int = try { decryptKeys().size } catch (_: Exception) { 0 }

    /** Advances the persisted index before returning, so each API request consumes the next key. */
    fun nextApiKey(): String? = synchronized(lock) {
        val keys = decryptKeys()
        if (keys.isEmpty()) return@synchronized null
        val index = prefs.getInt(NEXT_INDEX, 0).coerceAtLeast(0) % keys.size
        prefs.edit().putInt(NEXT_INDEX, (index + 1) % keys.size).commit()
        keys[index]
    }

    fun clearKeys() {
        prefs.edit().remove(KEYS_BLOB).putInt(NEXT_INDEX, 0).apply()
    }

    private fun decryptKeys(): List<String> {
        val packedString = prefs.getString(KEYS_BLOB, null) ?: return emptyList()
        val packed = Base64.decode(packedString, Base64.NO_WRAP)
        require(packed.size > GCM_IV_BYTES) { "Stored API key data is incomplete." }
        val iv = packed.copyOfRange(0, GCM_IV_BYTES)
        val ciphertext = packed.copyOfRange(GCM_IV_BYTES, packed.size)
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), javax.crypto.spec.GCMParameterSpec(128, iv))
        val text = String(cipher.doFinal(ciphertext), StandardCharsets.UTF_8)
        val json = JSONArray(text)
        return (0 until json.length()).map { json.getString(it) }.filter { it.isNotBlank() }
    }

    private fun getOrCreateKey(): SecretKey {
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (keyStore.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            ).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }

    companion object {
        private const val KEY_ALIAS = "agent_panel_gemini_keys"
        private const val KEYS_BLOB = "encrypted_keys"
        private const val NEXT_INDEX = "next_key_index"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"
        private const val GCM_IV_BYTES = 12
    }
}
