package com.example.agentpanel.overlay

import android.app.AlertDialog
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.example.agentpanel.MainActivity
import com.example.agentpanel.accessibility.AccessibilityBridge
import com.example.agentpanel.agent.AgentRunner
import com.example.agentpanel.security.KeyVault
import com.example.agentpanel.storage.ConversationStore
import com.example.agentpanel.util.Notifications

/** Persistent floating agent surface. UI state is saved independently from the overlay view. */
class OverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private lateinit var agentRunner: AgentRunner
    private val mainHandler = Handler(Looper.getMainLooper())
    private val panelPrefs by lazy { getSharedPreferences(PANEL_PREFS, Context.MODE_PRIVATE) }

    private var chipView: View? = null
    private var panelView: View? = null
    private var runningView: View? = null
    private var runningCancelOverlay: View? = null
    private var approvalOverlayView: View? = null
    private var runningViewIsAccessibilityOverlay = false
    private var debugInspectorView: View? = null
    private var logoDebugTapCount = 0
    private var lastLogoDebugTapAt = 0L
    private var runningStatusText: TextView? = null
    private var runningHistoryText: TextView? = null
    private var runningCancelButton: TextView? = null
    private var communicationApprovalCard: View? = null
    private var communicationApprovalText: TextView? = null
    private var runningTaskCard: View? = null
    private var runningHistoryHeader: View? = null
    private var runningHistoryScroll: View? = null
    private var pendingCommunicationResponse: ((Boolean) -> Unit)? = null
    private var replyText: TextView? = null
    private var statusText: TextView? = null
    private var recentText: TextView? = null
    private var clearHistoryControl: TextView? = null
    private var historyToggleControl: TextView? = null
    private var promptInput: EditText? = null
    private var sendButton: TextView? = null
    private var isBusy = false
    private var isShuttingDown = false
    private var showingHistory = false

    private val idleFade = Runnable {
        val panel = panelView ?: return@Runnable
        if (!isBusy && promptInput?.hasFocus() != true) {
            panel.animate().alpha(IDLE_ALPHA).setDuration(420).setInterpolator(DecelerateInterpolator()).start()
        }
    }
    private val workingFade = Runnable {
        if (isBusy) panelView?.animate()?.alpha(WORKING_ALPHA)?.setDuration(360)?.start()
    }

    override fun onCreate() {
        super.onCreate()
        Notifications.createChannel(this, Notifications.OVERLAY_CHANNEL, "Agently", "Notification while the Agently panel is active.")
        val notification = Notifications.build(this, Notifications.OVERLAY_CHANNEL, "Agently is active", "The floating panel is ready.")
        if (Build.VERSION.SDK_INT >= 34) startForeground(4201, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(4201, notification)
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        agentRunner = AgentRunner(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!android.provider.Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (isBusy) return START_STICKY
        if (intent?.action == ACTION_OPEN_PANEL) showPanel() else if (panelView == null) showChip()
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun showChip() {
        if (isBusy || runningView != null) return
        if (panelView != null) removePanel()
        if (chipView != null) return
        val chipSize = dp(40)
        val chip = TextView(this).apply {
            text = "✦"
            textSize = 21f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = gradientBackground(intArrayOf(PURPLE, PURPLE_DARK), 24f, STROKE)
            elevation = dp(10).toFloat()
            contentDescription = "Open Agently. Drag to move and snap to a screen edge."
        }
        val screenW = resources.displayMetrics.widthPixels
        val screenH = resources.displayMetrics.heightPixels
        val savedLeft = panelPrefs.getBoolean(KEY_CHIP_LEFT, false)
        val margin = dp(6)
        val savedY = panelPrefs.getInt(KEY_CHIP_Y, (screenH - chipSize) / 2)
        val params = WindowManager.LayoutParams(
            chipSize, chipSize, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.LEFT
            x = if (savedLeft) margin else (screenW - chipSize - margin).coerceAtLeast(margin)
            y = savedY.coerceIn(margin, (screenH - chipSize - margin).coerceAtLeast(margin))
        }
        try {
            windowManager.addView(chip, params)
            chipView = chip
            attachChipDrag(chip)
            chip.scaleX = 0.82f
            chip.scaleY = 0.82f
            chip.alpha = 0f
            chip.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(220).setInterpolator(DecelerateInterpolator()).start()
        } catch (_: Exception) {
            stopSelf()
        }
    }

    private fun attachChipDrag(chip: View) {
        val touchSlop = ViewConfiguration.get(this).scaledTouchSlop
        var downRawX = 0f
        var downRawY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        chip.setOnTouchListener { view, event ->
            val params = view.layoutParams as? WindowManager.LayoutParams ?: return@setOnTouchListener false
            val screenW = resources.displayMetrics.widthPixels
            val screenH = resources.displayMetrics.heightPixels
            val maxX = (screenW - view.width).coerceAtLeast(0)
            val maxY = (screenH - view.height).coerceAtLeast(0)
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX
                    downRawY = event.rawY
                    startX = params.x
                    startY = params.y
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downRawX
                    val dy = event.rawY - downRawY
                    if (kotlin.math.abs(dx) > touchSlop || kotlin.math.abs(dy) > touchSlop) moved = true
                    if (moved) {
                        params.x = (startX + dx.toInt()).coerceIn(0, maxX)
                        params.y = (startY + dy.toInt()).coerceIn(0, maxY)
                        try { windowManager.updateViewLayout(view, params) } catch (_: Exception) { }
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (!moved && event.actionMasked == MotionEvent.ACTION_UP) {
                        showPanel()
                    } else {
                        val snapLeft = params.x + view.width / 2 < screenW / 2
                        params.x = if (snapLeft) dp(6) else (screenW - view.width - dp(6)).coerceAtLeast(0)
                        params.y = params.y.coerceIn(dp(6), (screenH - view.height - dp(6)).coerceAtLeast(dp(6)))
                        try { windowManager.updateViewLayout(view, params) } catch (_: Exception) { }
                        panelPrefs.edit().putBoolean(KEY_CHIP_LEFT, snapLeft).putInt(KEY_CHIP_Y, params.y).apply()
                    }
                    true
                }
                else -> true
            }
        }
    }

    private fun showPanel() {
        if (isBusy || runningView != null) return
        removeChip()
        if (panelView != null) return

        val shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = gradientBackground(intArrayOf(PANEL_TOP, PANEL_BOTTOM), 26f, STROKE)
            elevation = dp(20).toFloat()
            alpha = 0f
            translationY = dp(14).toFloat()
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_YES
            contentDescription = "Agently floating agent panel"
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brand = TextView(this).apply {
            text = "✦  NICELYTINNED"
            textSize = 11f
            letterSpacing = 0.12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(MUTED_LAVENDER)
        }
        val settings = TextView(this).apply {
            text = "⚙"
            textSize = 22f
            gravity = Gravity.CENTER
            setTextColor(LAVENDER)
            contentDescription = "Open Agently setup"
            setOnClickListener {
                bumpIdleTimer()
                startActivity(Intent(this@OverlayService, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
        val collapse = TextView(this).apply {
            text = "×"
            textSize = 28f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            contentDescription = "Collapse agent panel"
            setPadding(dp(8), 0, 0, 0)
            setOnClickListener { collapsePanel() }
        }
        header.addView(brand, LinearLayout.LayoutParams(0, dp(34), 1f))
        attachDrag(brand)
        header.addView(settings, LinearLayout.LayoutParams(dp(38), dp(38)))
        header.addView(collapse, LinearLayout.LayoutParams(dp(34), dp(38)))
        shell.addView(header)

        val logo = buildLogo(dp(66))
        val logoHolder = FrameLayout(this).apply {
            isClickable = true
            contentDescription = "Agently logo"
            addView(logo, FrameLayout.LayoutParams(dp(66), dp(66), Gravity.CENTER))
            setOnClickListener { registerDebugInspectorTap() }
        }
        shell.addView(logoHolder, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(78)))

        val title = TextView(this).apply {
            text = "Agently"
            textSize = 20f
            gravity = Gravity.CENTER
            setLineSpacing(0f, 0.96f)
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        }
        shell.addView(title, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = dp(14)
        })

        val composer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = gradientBackground(intArrayOf(COMPOSER_TOP, COMPOSER_BOTTOM), 17f, CARD_STROKE)
            setPadding(dp(10), dp(7), dp(8), dp(7))
        }
        val input = EditText(this).apply {
            hint = "What should I do?"
            setHintTextColor(HINT)
            setTextColor(Color.WHITE)
            textSize = 14f
            minLines = 2
            maxLines = 4
            gravity = Gravity.TOP or Gravity.START
            imeOptions = EditorInfo.IME_ACTION_SEND or EditorInfo.IME_FLAG_NO_EXTRACT_UI
            setPadding(dp(6), dp(6), dp(6), dp(6))
            background = null
            setText(panelPrefs.getString(KEY_DRAFT, "").orEmpty())
            setOnFocusChangeListener { _, hasFocus -> if (hasFocus) brightenPanel() }
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    panelPrefs.edit().putString(KEY_DRAFT, s?.toString().orEmpty()).apply()
                }
                override fun afterTextChanged(s: Editable?) = Unit
            })
        }
        promptInput = input
        val send = TextView(this).apply {
            text = "➤"
            textSize = 23f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = gradientBackground(intArrayOf(PURPLE_LIGHT, PURPLE), 13f, Color.TRANSPARENT)
            contentDescription = "Send task to agent"
            isEnabled = !isBusy
            setOnClickListener { bumpIdleTimer(); submitPrompt() }
            elevation = dp(4).toFloat()
        }
        sendButton = send
        composer.addView(input, LinearLayout.LayoutParams(0, dp(76), 1f))
        composer.addView(send, LinearLayout.LayoutParams(dp(46), dp(46)))
        shell.addView(composer, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = dp(12)
        })
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) { submitPrompt(); true } else false
        }

        val savedTranscript = ConversationStore(this@OverlayService).conversationTranscript(6)
        val restoredTranscript = if (isBusy) savedTranscript else savedTranscript.replace(
            "Working on it…", "This task stopped before a final response. You can retry it."
        )
        val savedStatus = panelPrefs.getString(KEY_STATUS, "Ready to help!") ?: "Ready to help!"
        val restoredStatus = if (!isBusy && (savedStatus.startsWith("Thinking") || savedStatus.startsWith("Using ") || savedStatus.startsWith("Working"))) {
            "Previous task interrupted · ready when you are"
        } else savedStatus
        if (restoredStatus != savedStatus) panelPrefs.edit().putString(KEY_STATUS, restoredStatus).apply()

        val statusRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(2), dp(4), dp(12))
        }
        val statusDot = TextView(this).apply {
            text = "●"
            textSize = 13f
            setTextColor(GREEN)
        }
        val status = TextView(this).apply {
            text = restoredStatus
            textSize = 12f
            setTextColor(Color.rgb(221, 221, 236))
            setPadding(dp(7), 0, 0, 0)
        }
        statusText = status
        statusRow.addView(statusDot)
        statusRow.addView(status)
        shell.addView(statusRow)
        shell.addView(divider())

        val responseLabel = TextView(this).apply {
            text = "AGENT RESPONSE"
            textSize = 10f
            letterSpacing = 0.12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(MUTED_LAVENDER)
            setPadding(dp(2), dp(12), dp(2), dp(7))
        }
        shell.addView(responseLabel)

        val response = TextView(this).apply {
            text = restoredTranscript
            textSize = 13f
            setTextColor(Color.rgb(237, 235, 247))
            setPadding(dp(12), dp(11), dp(12), dp(11))
            background = gradientBackground(intArrayOf(RESPONSE_TOP, RESPONSE_BOTTOM), 15f, CARD_STROKE)
            setTextIsSelectable(true)
            setLineSpacing(dp(2).toFloat(), 1f)
        }
        replyText = response
        val responseScroll = ScrollView(this).apply {
            isFillViewport = false
            addView(response, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT))
        }
        shell.addView(responseScroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(112)).apply {
            bottomMargin = dp(10)
        })

        val recentHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val recentTitle = TextView(this).apply {
            text = "Recent Actions"
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        }
        val historyButton = TextView(this).apply {
            text = "View History  ↗"
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(LAVENDER)
            setPadding(dp(7), dp(6), dp(7), dp(6))
            setOnClickListener { bumpIdleTimer(); showHistory() }
        }
        val clearHistoryButton = TextView(this).apply {
            text = "Clear History"
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(0xFFFF9DB3.toInt())
            setPadding(dp(7), dp(6), 0, dp(6))
            visibility = View.GONE
            setOnClickListener { bumpIdleTimer(); confirmClearHistory() }
        }
        recentHeader.addView(recentTitle, LinearLayout.LayoutParams(0, dp(34), 1f))
        recentHeader.addView(historyButton)
        recentHeader.addView(clearHistoryButton)
        shell.addView(recentHeader)

        val recent = TextView(this).apply {
            text = ConversationStore(this@OverlayService).recentActions(4)
            textSize = 11f
            setTextColor(Color.rgb(197, 193, 220))
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = roundBackground(RECENT_BG, 13f, CARD_STROKE)
            setTextIsSelectable(true)
            setLineSpacing(dp(3).toFloat(), 1f)
        }
        recentText = recent
        clearHistoryControl = clearHistoryButton
        historyToggleControl = historyButton
        val recentScroll = ScrollView(this).apply {
            isFillViewport = false
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
            addView(recent, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT))
        }
        shell.addView(recentScroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f).apply {
            topMargin = dp(3)
            bottomMargin = dp(4)
        })

        val footer = TextView(this).apply {
            text = "◷   History & action log"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(LAVENDER)
            background = roundBackground(FOOTER_BG, 15f, CARD_STROKE)
            setPadding(dp(10), dp(11), dp(10), dp(11))
            setOnClickListener { bumpIdleTimer(); showHistory() }
        }
        shell.addView(footer, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(42)).apply { topMargin = dp(8) })

        val screenWidth = resources.displayMetrics.widthPixels
        val screenHeight = resources.displayMetrics.heightPixels
        val panelWidth = minOf(dp(370), screenWidth - dp(24))
        val panelHeight = minOf(dp(650), screenHeight - dp(54))
        val params = WindowManager.LayoutParams(
            panelWidth, panelHeight,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            x = dp(12)
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN
        }

        try {
            windowManager.addView(shell, params)
            panelView = shell
            attachIdleReset(shell, composer, input, send, historyButton, clearHistoryButton, footer, collapse, settings, responseScroll, recentScroll, statusRow)
            shell.animate().alpha(1f).translationY(0f).setDuration(260).setInterpolator(DecelerateInterpolator()).start()
            bumpIdleTimer()
        } catch (_: Exception) {
            showChip()
        }
    }

    private fun submitPrompt() {
        if (isBusy) return
        val prompt = promptInput?.text?.toString()?.trim().orEmpty()
        if (prompt.isBlank()) return
        if (KeyVault(this).keyCount() == 0) {
            updateReply("Add a Gemini API key in Agently setup before sending a task.")
            updateStatus("API key needed")
            return
        }
        isBusy = true
        showingHistory = false
        panelPrefs.edit().putString(KEY_DRAFT, "").putString(KEY_LAST_PROMPT, prompt).apply()
        (getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager)?.hideSoftInputFromWindow(promptInput?.windowToken, 0)
        promptInput?.clearFocus()
        removeDebugInspectorOverlay()
        removePanel()
        removeChip()
        if (!showRunningOverlay(prompt)) {
            isBusy = false
            panelPrefs.edit().putString(KEY_DRAFT, prompt)
                .putString(KEY_STATUS, "Accessibility overlay unavailable")
                .putString(KEY_REPLY, "Task not started. Agently could not create its accessibility status HUD. Make sure Agently's Accessibility Service is enabled, then retry.").apply()
            showPanel()
            updateStatus("Overlay unavailable")
            updateReply(panelPrefs.getString(KEY_REPLY, "Task not started.").orEmpty())
            return
        }

        agentRunner.run(prompt, object : AgentRunner.Listener {
            override fun onStatus(status: String) {
                if (isShuttingDown) return
                runningStatusText?.text = status
                panelPrefs.edit().putString(KEY_STATUS, status).apply()
                refreshRunningHistory()
            }

            override fun onFinished(reply: String) {
                if (isShuttingDown) return
                isBusy = false
                resolveCommunicationApproval(false)
                val transcript = ConversationStore(this@OverlayService).conversationTranscript(6)
                panelPrefs.edit().putString(KEY_STATUS, "Finished successfully").putString(KEY_REPLY, transcript).apply()
                removeRunningOverlay()
                showPanel()
                updateStatus("Finished successfully")
                updateReply(transcript)
                refreshRecentActions()
                bumpIdleTimer()
            }

            override fun onError(message: String) {
                if (isShuttingDown) return
                isBusy = false
                resolveCommunicationApproval(false)
                val transcript = ConversationStore(this@OverlayService).conversationTranscript(6)
                panelPrefs.edit().putString(KEY_STATUS, "Needs attention").putString(KEY_REPLY, transcript).apply()
                removeRunningOverlay()
                showPanel()
                updateStatus("Needs attention")
                updateReply(transcript)
                refreshRecentActions()
                bumpIdleTimer()
            }

            override fun onCancelled() {
                if (isShuttingDown) return
                isBusy = false
                resolveCommunicationApproval(false)
                val transcript = ConversationStore(this@OverlayService).conversationTranscript(6)
                panelPrefs.edit().putString(KEY_STATUS, "Stopped by you").putString(KEY_REPLY, transcript).apply()
                removeRunningOverlay()
                showPanel()
                updateStatus("Stopped by you")
                updateReply(transcript)
                refreshRecentActions()
                bumpIdleTimer()
            }

            override fun onCommunicationApprovalRequired(actionLabel: String, respond: (Boolean) -> Unit) {
                if (isShuttingDown || !isBusy) respond(false) else showActionApproval(actionLabel, respond, false)
            }

            override fun onCoordinateApprovalRequired(actionLabel: String, respond: (Boolean) -> Unit) {
                if (isShuttingDown || !isBusy) respond(false) else showActionApproval(actionLabel, respond, true)
            }
        })
    }

    /**
     * Passive, click-through task HUD. The history window cannot receive touches at all;
     * the only touchable area is the separate, small Cancel button window.
     */
    private fun showRunningOverlay(prompt: String): Boolean {
        if (runningView != null) return true
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = roundBackground(0xEE171326.toInt(), 18f, CARD_STROKE)
            isClickable = false
            isFocusable = false
            contentDescription = "Agently task status and latest three actions. This status display is touch-through."
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val titleGroup = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleGroup.addView(TextView(this).apply {
            text = "AGENTLY  ·  RUNNING"
            textSize = 13f
            letterSpacing = 0.06f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        })
        titleGroup.addView(TextView(this).apply {
            text = prompt.take(90)
            textSize = 10f
            setTextColor(MUTED_LAVENDER)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            setPadding(0, dp(3), 0, 0)
        })
        header.addView(titleGroup, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            rightMargin = dp(82)
        })
        root.addView(header)

        val status = TextView(this).apply {
            text = "Starting…"
            textSize = 11f
            setTextColor(0xFFE3DDF4.toInt())
            setPadding(0, dp(7), 0, dp(7))
        }
        runningStatusText = status
        root.addView(status)
        root.addView(View(this).apply { setBackgroundColor(0x553F365B); layoutParams = LinearLayout.LayoutParams(-1, dp(1)) })

        root.addView(TextView(this).apply {
            text = "LATEST 3 ACTIONS"
            textSize = 9f
            letterSpacing = 0.12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(MUTED_LAVENDER)
            setPadding(0, dp(7), 0, dp(4))
        })
        val history = TextView(this).apply {
            text = "Starting the task…"
            textSize = 10.5f
            setTextColor(Color.rgb(222, 218, 239))
            setLineSpacing(dp(2).toFloat(), 1f)
            maxLines = 6
            ellipsize = android.text.TextUtils.TruncateAt.END
            setTextIsSelectable(false)
        }
        runningHistoryText = history
        root.addView(history, LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT))

        val passiveParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(28)
            alpha = 0.96f
        }

        try {
            if (!AccessibilityBridge.addAgentAccessibilityOverlay(root, passiveParams)) {
                throw IllegalStateException("Accessibility Service is not connected or could not add the passive status HUD.")
            }
            runningView = root
            runningViewIsAccessibilityOverlay = true

            val cancel = TextView(this).apply {
                text = "Cancel"
                textSize = 12f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                background = roundBackground(0xFF8F2D54.toInt(), 12f, 0xFFFF789D.toInt())
                contentDescription = "Cancel and stop the running agent task"
                setPadding(dp(10), dp(7), dp(10), dp(7))
                setOnClickListener {
                    isEnabled = false
                    text = "Stopping…"
                    runningStatusText?.text = "Stopping the agent loop…"
                    agentRunner.cancel()
                }
            }
            runningCancelButton = cancel
            val cancelParams = WindowManager.LayoutParams(
                dp(76), dp(40),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.END
                x = dp(22)
                y = dp(34)
            }
            if (!AccessibilityBridge.addAgentAccessibilityOverlay(cancel, cancelParams)) {
                throw IllegalStateException("Could not add the separate Cancel control.")
            }
            runningCancelOverlay = cancel
            refreshRunningHistory()
            return true
        } catch (_: Exception) {
            removeRunningOverlay()
            return false
        }
    }

    /** A small, focusless approval surface; taps outside it continue to the target app. */
    private fun showActionApproval(actionLabel: String, respond: (Boolean) -> Unit, coordinateOnly: Boolean) {
        resolveCommunicationApproval(false)
        pendingCommunicationResponse = respond
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(17), dp(15), dp(17), dp(15))
            background = roundBackground(0xFF241C33.toInt(), 18f, 0xFFFF8CA8.toInt())
            isClickable = true
            isFocusable = false
        }
        card.addView(TextView(this).apply {
            text = if (coordinateOnly) "COORDINATE TAP CONFIRMATION" else "SEND / POST APPROVAL"
            textSize = 10f
            letterSpacing = 0.10f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFFFFB4C5.toInt())
        })
        val description = TextView(this).apply {
            text = if (coordinateOnly) {
                "Agently cannot read a label for this screen location: $actionLabel\n\nInspect the app behind this prompt and confirm that this exact point is safe to tap. Approval applies only to this one coordinate tap."
            } else {
                "Agently is ready to activate: $actionLabel\n\nCheck the recipient, audience, text, and selected image in the app behind this prompt. Approval applies only to this one outbound action. Later sends/posts/shares require separate approval. Payments, purchases, transfers, deletion, account/security changes, permissions, and subscriptions remain blocked."
            }
            textSize = 12f
            setTextColor(Color.WHITE)
            setPadding(0, dp(8), 0, dp(12))
            setLineSpacing(dp(2).toFloat(), 1f)
        }
        communicationApprovalText = description
        card.addView(description)
        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
        }
        val notNow = TextView(this).apply {
            text = "Not now"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setOnClickListener { resolveCommunicationApproval(false) }
        }
        val allow = TextView(this).apply {
            text = if (coordinateOnly) "Allow this tap" else "Allow this action"
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = roundBackground(0xFF7A3BA5.toInt(), 12f, 0xFFC99BFF.toInt())
            setPadding(dp(13), dp(10), dp(13), dp(10))
            setOnClickListener { resolveCommunicationApproval(true) }
        }
        buttons.addView(notNow)
        buttons.addView(allow, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(8) })
        card.addView(buttons)

        val params = WindowManager.LayoutParams(
            resources.displayMetrics.widthPixels - dp(28),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }
        if (AccessibilityBridge.addAgentAccessibilityOverlay(card, params)) {
            approvalOverlayView = card
            runningStatusText?.text = if (coordinateOnly) "Waiting for coordinate confirmation" else "Waiting for your approval before sending or publishing"
        } else {
            pendingCommunicationResponse = null
            respond(false)
            runningStatusText?.text = "Approval view unavailable · action declined"
        }
    }

    private fun resolveCommunicationApproval(approved: Boolean) {
        approvalOverlayView?.let { AccessibilityBridge.removeAgentAccessibilityOverlay(it) }
        approvalOverlayView = null
        communicationApprovalCard = null
        communicationApprovalText = null
        val response = pendingCommunicationResponse
        pendingCommunicationResponse = null
        response?.invoke(approved)
        if (!approved && response != null) {
            runningStatusText?.text = "Communication action declined · stopping outbound actions"
        } else if (approved) {
            runningStatusText?.text = "This communication action was approved"
        }
    }

    private fun refreshRunningHistory() {
        val text = ConversationStore(this).latestTurnActions(3)
        runningHistoryText?.text = text.ifBlank { "No actions logged yet. The task is starting." }
    }

    private fun removeRunningOverlay() {
        resolveCommunicationApproval(false)
        runningCancelOverlay?.let { AccessibilityBridge.removeAgentAccessibilityOverlay(it) }
        runningCancelOverlay = null
        runningView?.let { view ->
            if (runningViewIsAccessibilityOverlay) {
                if (!AccessibilityBridge.removeAgentAccessibilityOverlay(view)) {
                    try { windowManager.removeView(view) } catch (_: Exception) { }
                }
            } else {
                try { windowManager.removeView(view) } catch (_: Exception) { }
            }
        }
        runningView = null
        runningViewIsAccessibilityOverlay = false
        runningStatusText = null
        runningHistoryText = null
        runningCancelButton = null
        communicationApprovalCard = null
        communicationApprovalText = null
        runningTaskCard = null
        runningHistoryHeader = null
        runningHistoryScroll = null
        pendingCommunicationResponse = null
    }

    private fun registerDebugInspectorTap() {
        val now = android.os.SystemClock.elapsedRealtime()
        if (now - lastLogoDebugTapAt > 3_000L) logoDebugTapCount = 0
        lastLogoDebugTapAt = now
        logoDebugTapCount++
        if (logoDebugTapCount >= 7) {
            logoDebugTapCount = 0
            showDebugInspectorOverlay()
        }
    }

    /** Hidden developer inspector: reads the app underneath without taking its window focus. */
    private fun showDebugInspectorOverlay() {
        if (debugInspectorView != null) {
            removeDebugInspectorOverlay()
            return
        }
        if (!AccessibilityBridge.isConnected()) {
            Toast.makeText(this, "Enable Agently's Accessibility Service first.", Toast.LENGTH_LONG).show()
            return
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(13), dp(12), dp(13), dp(12))
            background = roundBackground(0xF31A1529.toInt(), 18f, STROKE)
            isClickable = true
            isFocusable = false
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(TextView(this).apply {
            text = "DEBUG INSPECTOR"
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        }, LinearLayout.LayoutParams(0, dp(38), 1f))
        val refresh = smallInspectorButton("Refresh") { refreshDebugInspector() }
        header.addView(refresh)
        header.addView(smallInspectorButton("Close") { removeDebugInspectorOverlay() }, LinearLayout.LayoutParams(-2, dp(36)).apply { leftMargin = dp(6) })
        root.addView(header)
        val packageLine = TextView(this).apply {
            text = "Reading the foreground app's accessibility tree…"
            textSize = 10f
            setTextColor(MUTED_LAVENDER)
            setPadding(0, 0, 0, dp(8))
        }
        root.addView(packageLine)
        val searchRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, dp(8))
        }
        val searchInput = EditText(this).apply {
            hint = "Search element text / description / ID"
            textSize = 11f
            setSingleLine(true)
            setTextColor(Color.WHITE)
            setHintTextColor(MUTED_LAVENDER)
            setPadding(dp(9), dp(7), dp(9), dp(7))
            background = roundBackground(0xFF211A32.toInt(), 9f, CARD_STROKE)
        }
        searchRow.addView(searchInput, LinearLayout.LayoutParams(0, dp(38), 1f))
        searchRow.addView(smallInspectorButton("Search") { refreshDebugInspector() }, LinearLayout.LayoutParams(-2, dp(36)).apply { leftMargin = dp(7) })
        root.addView(searchRow)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply {
            isFillViewport = false
            addView(list, FrameLayout.LayoutParams(-1, -2))
        }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.tag = InspectorViews(packageLine, list, searchInput)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            (resources.displayMetrics.heightPixels * 0.52f).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = dp(8)
            softInputMode = android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        try {
            if (!AccessibilityBridge.addAgentAccessibilityOverlay(root, params)) {
                Toast.makeText(this, "Could not open the debug inspector.", Toast.LENGTH_SHORT).show()
                return
            }
            debugInspectorView = root
            refreshDebugInspector()
        } catch (_: Exception) {
            debugInspectorView = null
            Toast.makeText(this, "Could not open the debug inspector.", Toast.LENGTH_SHORT).show()
        }
    }

    private data class InspectorViews(val packageLine: TextView, val list: LinearLayout, val searchInput: EditText)

    private fun smallInspectorButton(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        textSize = 10f
        gravity = Gravity.CENTER
        setTextColor(Color.WHITE)
        background = roundBackground(0xFF3A2D58.toInt(), 9f, CARD_STROKE)
        setPadding(dp(10), dp(7), dp(10), dp(7))
        setOnClickListener { onClick() }
    }

    private fun refreshDebugInspector() {
        val root = debugInspectorView ?: return
        val views = root.tag as? InspectorViews ?: return
        val query = views.searchInput.text.toString().trim()
        val raw = if (query.isBlank()) AccessibilityBridge.inspectUiTree() else AccessibilityBridge.searchElements(query)
        try {
            val json = org.json.JSONObject(raw)
            val pkg = json.optString("packageName", "unknown app")
            val elements = json.optJSONArray("elements") ?: org.json.JSONArray()
            views.packageLine.text = "$pkg  ·  ${elements.length()} nodes sampled"
            views.list.removeAllViews()
            for (i in 0 until elements.length()) {
                val item = elements.optJSONObject(i) ?: continue
                val id = item.optString("id")
                val label = item.optString("label").ifBlank {
                    listOf(item.optString("text"), item.optString("contentDescription"), item.optString("viewId"), item.optString("className"))
                        .filter { it.isNotBlank() }.joinToString(" | ")
                }
                val className = item.optString("className")
                val viewId = item.optString("viewId")
                val parentLabel = item.optString("clickableAncestor")
                val actions = item.optString("actions")
                val clickable = item.optBoolean("clickable")
                val clickAction = item.optBoolean("hasClickAction")
                val enabled = item.optBoolean("enabled")
                val visible = item.optBoolean("visible")
                val bounds = item.optString("bounds")
                val card = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(10), dp(8), dp(10), dp(8))
                    background = roundBackground(0xFF241D37.toInt(), 10f, CARD_STROKE)
                }
                card.addView(TextView(this).apply {
                    text = label.take(120)
                    textSize = 11f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(Color.WHITE)
                })
                card.addView(TextView(this).apply {
                    text = "class=$className  clickable=$clickable  ACTION_CLICK=$clickAction  enabled=$enabled  visible=$visible\nviewId=$viewId\nbounds=$bounds" +
                        (if (actions.isNotBlank()) "\nactions=$actions" else "") +
                        (if (parentLabel.isNotBlank()) "\nclickable parent=$parentLabel" else "")
                    textSize = 9f
                    setTextColor(0xFFC7BEDF.toInt())
                    setPadding(0, dp(4), 0, dp(6))
                })
                if (id.isNotBlank()) {
                    val test = smallInspectorButton("Test click") {
                        val preview = try { org.json.JSONObject(AccessibilityBridge.previewClickElement(id)) } catch (_: Exception) { org.json.JSONObject() }
                        when {
                            !preview.optBoolean("valid", false) -> Toast.makeText(this, preview.optString("message", "Element is not available."), Toast.LENGTH_LONG).show()
                            preview.optString("category") != "ordinary" -> Toast.makeText(this, "Inspector won't activate send/post or restricted controls. Category: ${preview.optString("category")}", Toast.LENGTH_LONG).show()
                            else -> {
                                val result = AccessibilityBridge.clickElement(id, false)
                                Toast.makeText(this, result, Toast.LENGTH_LONG).show()
                                refreshDebugInspector()
                            }
                        }
                    }
                    card.addView(test, LinearLayout.LayoutParams(-2, dp(34)))
                } else {
                    card.addView(TextView(this).apply {
                        text = "No stable accessibility ID · use visual inspection for this control"
                        textSize = 9f
                        setTextColor(0xFFFFC88A.toInt())
                    })
                }
                views.list.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })
            }
            if (elements.length() == 0) {
                views.list.addView(TextView(this).apply {
                    text = if (query.isNotBlank()) "No elements match '$query'. Clear the search and refresh to inspect the full tree." else json.optString("message", "No app window was found. Open the app to inspect, then tap Refresh.")
                    textSize = 11f
                    setTextColor(Color.WHITE)
                })
            }
        } catch (_: Exception) {
            views.packageLine.text = raw.take(500)
            views.list.removeAllViews()
        }
    }

    private fun removeDebugInspectorOverlay() {
        debugInspectorView?.let { AccessibilityBridge.removeAgentAccessibilityOverlay(it) }
        debugInspectorView = null
    }

    private fun showHistory() {
        val recent = recentText ?: return
        showingHistory = !showingHistory
        val store = ConversationStore(this)
        if (showingHistory) {
            recent.text = store.historyText(12)
            recent.textSize = 10f
            recent.setTextColor(Color.rgb(221, 218, 237))
            clearHistoryControl?.visibility = View.VISIBLE
            historyToggleControl?.text = "Recent Actions  ↙"
        } else {
            recent.text = store.recentActions(4)
            recent.textSize = 11f
            recent.setTextColor(Color.rgb(197, 193, 220))
            clearHistoryControl?.visibility = View.GONE
            historyToggleControl?.text = "View History  ↗"
        }
        statusText?.text = if (showingHistory) "Showing saved history" else "Recent actions"
        panelPrefs.edit().putString(KEY_STATUS, statusText?.text?.toString().orEmpty()).apply()
    }

    private fun confirmClearHistory() {
        val dialog = AlertDialog.Builder(this)
            .setTitle("Clear saved history?")
            .setMessage("This permanently deletes all saved conversations and action logs stored by Agently on this device. It does not delete messages or posts in other apps.")
            .setNegativeButton("Keep history", null)
            .setPositiveButton("Clear history") { _, _ ->
                ConversationStore(this).clearHistory()
                val store = ConversationStore(this)
                recentText?.text = if (showingHistory) store.historyText(12) else store.recentActions(4)
                replyText?.text = "No saved conversation history."
                panelPrefs.edit().putString(KEY_REPLY, "No saved conversation history.").apply()
                Toast.makeText(this, "Agently history cleared", Toast.LENGTH_SHORT).show()
            }
            .create()
        try {
            dialog.window?.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
            dialog.show()
        } catch (_: Exception) {
            Toast.makeText(this, "Open Agently setup to clear history.", Toast.LENGTH_LONG).show()
        }
    }

    private fun updateReply(value: String) {
        panelPrefs.edit().putString(KEY_REPLY, value).apply()
        replyText?.apply {
            text = value
            alpha = 0.72f
            animate().alpha(1f).setDuration(240).start()
        }
    }

    private fun updateStatus(value: String) {
        panelPrefs.edit().putString(KEY_STATUS, value).apply()
        statusText?.text = value
    }

    private fun refreshRecentActions() {
        if (!showingHistory) recentText?.text = ConversationStore(this).recentActions(4)
    }

    private fun collapsePanel() {
        val panel = panelView ?: return
        panelPrefs.edit().putString(KEY_DRAFT, promptInput?.text?.toString().orEmpty()).apply()
        removeDebugInspectorOverlay()
        (getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager)?.hideSoftInputFromWindow(promptInput?.windowToken, 0)
        promptInput?.clearFocus()
        mainHandler.removeCallbacks(idleFade)
        mainHandler.removeCallbacks(workingFade)
        panel.animate().alpha(0f).translationY(dp(12).toFloat()).setDuration(180).withEndAction {
            removePanel()
            showChip()
        }.start()
    }

    private fun brightenPanel() {
        panelView?.animate()?.alpha(1f)?.setDuration(180)?.start()
        mainHandler.removeCallbacks(idleFade)
    }

    private fun bumpIdleTimer() {
        brightenPanel()
        mainHandler.removeCallbacks(idleFade)
        mainHandler.removeCallbacks(workingFade)
        if (isBusy) mainHandler.postDelayed(workingFade, WORKING_FADE_DELAY_MS)
        else mainHandler.postDelayed(idleFade, IDLE_TIMEOUT_MS)
    }

    private fun attachDrag(handle: View) {
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        handle.setOnTouchListener { _, event ->
            val panel = panelView ?: return@setOnTouchListener false
            val params = panel.layoutParams as? WindowManager.LayoutParams ?: return@setOnTouchListener false
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    startX = params.x
                    startY = params.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = (startX - (event.rawX - downX).toInt()).coerceAtLeast(0)
                    params.y = startY + (event.rawY - downY).toInt()
                    try { windowManager.updateViewLayout(panel, params) } catch (_: Exception) { }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    bumpIdleTimer()
                    true
                }
                else -> false
            }
        }
    }

    private fun attachIdleReset(vararg views: View) {
        views.forEach { view ->
            view.setOnTouchListener { _, _ -> bumpIdleTimer(); false }
        }
    }

    private fun buildLogo(size: Int): View {
        val outer = FrameLayout(this).apply {
            background = gradientBackground(intArrayOf(PURPLE_LIGHT, PURPLE_DARK), 20f, Color.TRANSPARENT)
            elevation = dp(7).toFloat()
        }
        val face = TextView(this).apply {
            text = "●   ●"
            textSize = 13f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(PURPLE_LIGHT)
            background = roundBackground(Color.rgb(20, 15, 39), 18f, Color.rgb(236, 228, 255))
        }
        val faceParams = FrameLayout.LayoutParams((size * 0.70f).toInt(), (size * 0.48f).toInt(), Gravity.CENTER).apply {
            topMargin = dp(7)
        }
        outer.addView(face, faceParams)
        val sparkle = TextView(this).apply {
            text = "✦"
            textSize = 17f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        outer.addView(sparkle, FrameLayout.LayoutParams(dp(24), dp(24), Gravity.TOP or Gravity.END))
        return outer
    }

    private fun divider(): View = View(this).apply {
        setBackgroundColor(Color.rgb(62, 54, 88))
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1))
    }

    private fun removeChip() {
        chipView?.let { try { windowManager.removeView(it) } catch (_: Exception) { } }
        chipView = null
    }

    private fun removePanel() {
        panelView?.let { try { windowManager.removeView(it) } catch (_: Exception) { } }
        panelView = null
        replyText = null
        promptInput = null
        statusText = null
        recentText = null
        clearHistoryControl = null
        historyToggleControl = null
        sendButton = null
    }

    private fun gradientBackground(colors: IntArray, radiusDp: Float, stroke: Int): GradientDrawable = GradientDrawable(
        GradientDrawable.Orientation.TL_BR, colors
    ).apply {
        cornerRadius = dp(radiusDp.toInt()).toFloat()
        if (stroke != Color.TRANSPARENT) setStroke(dp(1), stroke)
    }

    private fun roundBackground(color: Int, radiusDp: Float, stroke: Int = Color.TRANSPARENT): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp.toInt()).toFloat()
        if (stroke != Color.TRANSPARENT) setStroke(dp(1), stroke)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        isShuttingDown = true
        panelPrefs.edit().putString(KEY_DRAFT, promptInput?.text?.toString().orEmpty()).apply()
        mainHandler.removeCallbacksAndMessages(null)
        agentRunner.shutdown()
        removeRunningOverlay()
        removeDebugInspectorOverlay()
        removeChip()
        removePanel()
        super.onDestroy()
    }

    companion object {
        const val ACTION_OPEN_PANEL = "com.example.agentpanel.OPEN_PANEL"
        const val ACTION_START = "com.example.agentpanel.START_OVERLAY"
        private const val PANEL_PREFS = "nicelytinned_panel_state"
        private const val KEY_DRAFT = "draft"
        private const val KEY_REPLY = "reply"
        private const val KEY_STATUS = "status"
        private const val KEY_LAST_PROMPT = "last_prompt"
        private const val KEY_CHIP_LEFT = "mini_chip_left"
        private const val KEY_CHIP_Y = "mini_chip_y"
        private const val IDLE_TIMEOUT_MS = 28_000L
        private const val WORKING_FADE_DELAY_MS = 1_800L
        private const val IDLE_ALPHA = 0.84f
        private const val WORKING_ALPHA = 0.90f

        private const val PURPLE = 0xFF6638D7.toInt()
        private const val PURPLE_DARK = 0xFF39208C.toInt()
        private const val PURPLE_LIGHT = 0xFF9B68FF.toInt()
        private const val PANEL_TOP = 0xFF211A35.toInt()
        private const val PANEL_BOTTOM = 0xFF100E1D.toInt()
        private const val COMPOSER_TOP = 0xFF28213E.toInt()
        private const val COMPOSER_BOTTOM = 0xFF1D1930.toInt()
        private const val RESPONSE_TOP = 0xFF2A223F.toInt()
        private const val RESPONSE_BOTTOM = 0xFF201B32.toInt()
        private const val RECENT_BG = 0xFF191528.toInt()
        private const val FOOTER_BG = 0xFF211B35.toInt()
        private const val STROKE = 0xFF51436F.toInt()
        private const val CARD_STROKE = 0xFF403654.toInt()
        private const val MUTED_LAVENDER = 0xFFB7A5E8.toInt()
        private const val LAVENDER = 0xFFC6A8FF.toInt()
        private const val HINT = 0xFF9B91B8.toInt()
        private const val GREEN = 0xFF65E6AA.toInt()

        fun openPanel(context: Context) {
            val intent = Intent(context, OverlayService::class.java).setAction(ACTION_OPEN_PANEL)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent) else context.startService(intent)
        }
    }
}
