package com.example.agentpanel.agent

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Base64
import com.example.agentpanel.accessibility.AccessibilityBridge
import com.example.agentpanel.gemini.GeminiClient
import com.example.agentpanel.security.KeyVault
import com.example.agentpanel.storage.ConversationStore
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.CancellationException
import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

class AgentRunner(context: Context) {
    private val appContext = context.applicationContext
    private val vault = KeyVault(appContext)
    private val store = ConversationStore(appContext)
    private val gemini = GeminiClient(appContext, vault)
    private val mainHandler = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    private val auditExecutor = Executors.newSingleThreadExecutor()

    private class RunControl(val listener: Listener) {
        val cancelled = AtomicBoolean(false)
        val cancellationNotified = AtomicBoolean(false)
        val cancellationRecorded = AtomicBoolean(false)
        @Volatile var turnId: Long = -1L
        @Volatile var future: Future<*>? = null
        @Volatile var pendingApprovalLatch: CountDownLatch? = null
        val communicationDenied = AtomicBoolean(false)
        @Volatile var pendingScreenshot: AccessibilityBridge.ScreenCapture? = null
        @Volatile var latestScreenshotWidth: Int = 0
        @Volatile var latestScreenshotHeight: Int = 0
        @Volatile var latestScreenshotMutationVersion: Long = 0L
        @Volatile var uiMutationVersion: Long = 0L
        @Volatile var coordinateScreenshotValid: Boolean = false
    }

    @Volatile private var activeControl: RunControl? = null

    interface Listener {
        fun onStatus(status: String)
        fun onFinished(reply: String)
        fun onError(message: String)
        fun onCancelled()
        /** Outbound approval follows the user's messaging/posting preference (per-action by default). */
        fun onCommunicationApprovalRequired(actionLabel: String, respond: (Boolean) -> Unit)
        /** One-time confirmation for coordinate taps whose target has no readable accessibility label. */
        fun onCoordinateApprovalRequired(actionLabel: String, respond: (Boolean) -> Unit)
    }

    fun run(prompt: String, listener: Listener) {
        val control = RunControl(listener)
        activeControl = control
        control.future = executor.submit {
            var turnId = -1L
            try {
                ensureActive(control)
                val contextText = store.conversationContext()
                turnId = store.createTurn(prompt)
                control.turnId = turnId
                ensureActive(control)
                val contents = JSONArray().put(
                    JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put(
                        "text", "Conversation history and tool audit:\n$contextText\n\nCurrent user request:\n$prompt"
                    )))
                )

                var steps = 0
                var noToolResponses = 0
                while (steps < MAX_AGENT_STEPS) {
                    ensureActive(control)
                    steps++
                    status(control, "Thinking · step $steps")
                    val response = gemini.generate(contents, forceToolCall = noToolResponses >= 2)
                    ensureActive(control)
                    val candidate = response.optJSONArray("candidates")?.optJSONObject(0)
                        ?: throw IllegalStateException(response.optJSONObject("promptFeedback")?.toString() ?: "Gemini returned no candidate.")
                    val modelContent = candidate.optJSONObject("content")
                        ?: throw IllegalStateException("Gemini returned an empty message.")
                    val parts = modelContent.optJSONArray("parts") ?: JSONArray()
                    data class PendingCall(val name: String, val args: JSONObject, val id: String)
                    val calls = mutableListOf<PendingCall>()
                    for (i in 0 until parts.length()) {
                        val part = parts.optJSONObject(i) ?: continue
                        val call = part.optJSONObject("functionCall") ?: part.optJSONObject("function_call")
                        if (call != null) calls.add(PendingCall(
                            call.optString("name"),
                            call.optJSONObject("args") ?: JSONObject(),
                            call.optString("id")
                        ))
                    }
                    contents.put(modelContent)

                    if (calls.isEmpty()) {
                        noToolResponses++
                        contents.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put(
                            "text", "Do not return a plain-text final answer. Continue the agent loop and call finish(reply) when done. Use another tool if needed."
                        ))))
                        continue
                    }
                    noToolResponses = 0
                    var screenshotDeliveredForBatch = false

                    for (pendingCall in calls) {
                        ensureActive(control)
                        val name = pendingCall.name
                        val args = pendingCall.args
                        val decision = safeActionSummary(name, args)
                        status(control, "Using $name")
                        if (name == "finish") {
                            ensureActive(control)
                            val reply = args.optString("reply").ifBlank { "The task finished, but no reply text was provided." }
                            store.addToolEvent(turnId, name, args, "Agent loop completed through finish().", decision)
                            store.saveReply(turnId, reply)
                            mainHandler.post { if (!control.cancelled.get()) listener.onFinished(reply) }
                            return@submit
                        }
                        val result = executeTool(name, args, control)
                        // Persist the result before checking cancellation so an action that already
                        // reached Android is not silently omitted from the audit if Cancel arrives
                        // immediately afterward. Typed text itself is never written to the audit.
                        val auditArgs = when (name) {
                            "type_text" -> JSONObject(args.toString()).put("text", "[redacted · ${args.optString("text").length} characters]")
                            "sequence" -> redactSequenceAuditArgs(args)
                            else -> args
                        }
                        store.addToolEvent(turnId, name, auditArgs, result, decision)
                        ensureActive(control)
                        status(control, "Completed $name")
                        val responseData = JSONObject().put("result", result)
                        val functionResponse = JSONObject()
                            .put("name", name)
                            .put("response", responseData)
                        if (pendingCall.id.isNotBlank()) functionResponse.put("id", pendingCall.id)

                        val responsePart = JSONObject().put("functionResponse", functionResponse)
                        val responseParts = JSONArray().put(responsePart)
                        var legacyImageContent: JSONObject? = null
                        val screenshot = control.pendingScreenshot
                        if (screenshot != null) {
                            control.pendingScreenshot = null
                            val stillEnabled = appContext.getSharedPreferences("agent_settings", Context.MODE_PRIVATE)
                                .getBoolean("visual_fallback_enabled", true)
                            if (stillEnabled) {
                                val displayName = "agently-screen.jpg"
                                val imageBytes = Base64.encodeToString(screenshot.jpeg, Base64.NO_WRAP)
                                val imagePart = JSONObject().put("inlineData", JSONObject()
                                    .put("displayName", displayName)
                                    .put("mimeType", "image/jpeg")
                                    .put("data", imageBytes))
                                val imageInstruction = "Current screenshot attached as image input. Dimensions: ${screenshot.width}x${screenshot.height} pixels. Use these exact dimensions for click_xy and capture a new image after every UI change."
                                if (gemini.modelName().startsWith("gemini-3", ignoreCase = true)) {
                                    // Gemini 3 supports image parts embedded in a function response.
                                    responseData.put("image_ref", JSONObject().put("\$ref", displayName))
                                    functionResponse.put("parts", JSONArray().put(imagePart))
                                    responseData.put("result", "$result $imageInstruction")
                                    screenshotDeliveredForBatch = true
                                } else {
                                    // Older generateContent models receive a regular image-bearing user turn
                                    // immediately after the matching function response.
                                    responseData.put("result", "$result $imageInstruction")
                                    legacyImageContent = JSONObject().put("role", "user").put("parts", JSONArray()
                                        .put(JSONObject().put("text", imageInstruction))
                                        .put(imagePart))
                                    screenshotDeliveredForBatch = true
                                }
                            } else {
                                responseData.put("result", "${result} The user disabled Visual Fallback before upload. The screenshot was not attached or transmitted. Continue without visual input.")
                            }
                        }
                        contents.put(JSONObject().put("role", "user").put("parts", responseParts))
                        // For pre-Gemini-3 models, keep the image in a separate user turn,
                        // but only after the corresponding function response has been appended.
                        legacyImageContent?.let(contents::put)
                    }
                    // A screenshot only becomes usable by click_xy on the *next* model turn.
                    // A coordinate call returned in the same batch as inspect_screen was generated
                    // before Gemini had seen the image, so it must not be allowed to tap yet.
                    if (screenshotDeliveredForBatch &&
                        control.latestScreenshotMutationVersion == control.uiMutationVersion) {
                        control.coordinateScreenshotValid = true
                    }
                }
                throw IllegalStateException("Agent reached the $MAX_AGENT_STEPS-step safety limit without calling finish(). No normal final reply was produced.")
            } catch (e: Exception) {
                if (control.cancelled.get() || e is CancellationException || e is InterruptedException) {
                    recordCancellation(control)
                    notifyCancelled(control)
                } else {
                    val message = e.message ?: e.javaClass.simpleName
                    if (turnId > 0) {
                        store.addToolEvent(turnId, "agent_error", JSONObject(), message, "The agent could not complete the request.")
                        store.saveReply(turnId, "Agent stopped: $message")
                    }
                    mainHandler.post { if (!control.cancelled.get()) listener.onError(message) }
                }
            } finally {
                if (activeControl === control) activeControl = null
            }
        }
    }

    /** Stops future steps, interrupts waits and disconnects an in-flight Gemini request. */
    fun cancel() {
        val control = activeControl ?: return
        if (!control.cancelled.compareAndSet(false, true)) return
        control.future?.cancel(true)
        control.pendingApprovalLatch?.countDown()
        gemini.cancelCurrentRequest()
        try {
            auditExecutor.execute {
                recordCancellation(control)
                notifyCancelled(control)
            }
        } catch (_: Exception) {
            notifyCancelled(control)
        }
    }

    fun shutdown() {
        cancel()
        executor.shutdownNow()
        auditExecutor.shutdown()
    }

    private fun ensureActive(control: RunControl) {
        if (control.cancelled.get() || Thread.currentThread().isInterrupted) {
            throw CancellationException("Task cancelled by the user.")
        }
    }

    private fun recordCancellation(control: RunControl) {
        val turnId = control.turnId
        if (turnId <= 0 || !control.cancellationRecorded.compareAndSet(false, true)) return
        try {
            store.addToolEvent(turnId, "agent_cancelled", JSONObject(), "Stopped by the user.", "The user cancelled the running task; no further steps were started.")
            store.saveReply(turnId, "Stopped by you.")
        } catch (_: Exception) { }
    }

    private fun notifyCancelled(control: RunControl) {
        if (!control.cancellationNotified.compareAndSet(false, true)) return
        mainHandler.post { control.listener.onCancelled() }
    }


    private fun executeClickElement(elementId: String, requestedPurpose: String, control: RunControl): String {
        if (elementId.isBlank()) return "A temporary elementId from search_elements is required."
        val preview = try {
            JSONObject(AccessibilityBridge.previewClickElement(elementId))
        } catch (_: Exception) {
            return "Could not validate this control. Search for it again before clicking."
        }
        if (!preview.optBoolean("valid", false)) {
            return preview.optString("message", "This control is no longer available. Search again.")
        }

        val label = preview.optString("label").ifBlank { "the selected control" }
        val purpose = requestedPurpose.trim().lowercase()
        if (purpose !in setOf("navigation", "preparation", "communication")) {
            return "Invalid action purpose. Use navigation, preparation, or communication."
        }
        val category = preview.optString("category", "ordinary")
        if (category == "restricted") {
            return "BLOCKED: '$label' can change payment, account, security, permissions, or stored data. Complete that action manually."
        }
        if (category == "communication" || purpose == "communication") {
            if (control.communicationDenied.get()) {
                return "The user declined an outbound communication action. Do not try another send/post/share control in this task."
            }
            val approved = awaitCommunicationConsent(control, label)
            if (!approved) {
                control.communicationDenied.set(true)
                return "The user did not authorize this outbound action. Do not attempt another communication action in this task."
            }
            ensureActive(control)

            // Re-check the control after the approval pause. The app may have navigated,
            // refreshed, or changed its UI while the user was reviewing the destination.
            val finalPreview = try {
                JSONObject(AccessibilityBridge.previewClickElement(elementId))
            } catch (_: Exception) {
                return "Could not revalidate the approved control. Search for it again before continuing."
            }
            if (!finalPreview.optBoolean("valid", false)) {
                return "The approved control changed or expired. Search for the target again."
            }
            val finalLabel = finalPreview.optString("label").ifBlank { "the selected control" }
            if (!finalLabel.equals(label, ignoreCase = true) || finalPreview.optString("category") == "restricted") {
                return "The approved control no longer matches the reviewed action. No click was performed."
            }
            val result = AccessibilityBridge.clickElement(elementId, communicationActionApproved = true)
            if (result.startsWith("Clicked:", true)) invalidateCoordinateScreenshot(control)
            return result
        }
        ensureActive(control)
        val result = AccessibilityBridge.clickElement(elementId)
        if (result.startsWith("Clicked:", true)) invalidateCoordinateScreenshot(control)
        return result
    }

    private fun executeClickXY(
        x: Int, y: Int, screenshotWidth: Int, screenshotHeight: Int,
        requestedPurpose: String, control: RunControl
    ): String {
        if (screenshotWidth <= 0 || screenshotHeight <= 0) return "A valid screenshotWidth and screenshotHeight are required."
        val visualEnabled = appContext.getSharedPreferences("agent_settings", Context.MODE_PRIVATE)
            .getBoolean("visual_fallback_enabled", true)
        if (!visualEnabled) return "Visual fallback is disabled. Enable it before using screenshot-based coordinates."
        if (!control.coordinateScreenshotValid ||
            screenshotWidth != control.latestScreenshotWidth || screenshotHeight != control.latestScreenshotHeight) {
            return "These coordinates do not match the latest available screenshot. Call inspect_screen again and use its exact dimensions."
        }
        val purpose = requestedPurpose.trim().lowercase()
        if (purpose !in setOf("navigation", "preparation", "communication")) {
            return "Invalid action purpose. Use navigation, preparation, or communication."
        }
        val preview = try { JSONObject(AccessibilityBridge.previewClickAt(x, y, screenshotWidth, screenshotHeight)) }
            catch (_: Exception) { return "Could not inspect the coordinate target. Capture a fresh screenshot and retry." }
        if (!preview.optBoolean("valid", false)) return preview.optString("message", "The coordinate is not available.")
        val label = preview.optString("label").ifBlank { "coordinate ($x, $y)" }
        val category = preview.optString("category", "unknown")
        if (category == "restricted") {
            return "BLOCKED: '$label' appears to affect payment, account, security, permissions, or stored data. Complete it manually."
        }

        var communicationApproved = false
        if (category == "communication" || purpose == "communication") {
            if (control.communicationDenied.get()) return "The user declined an outbound action earlier in this task."
            communicationApproved = awaitCommunicationConsent(control, label)
            if (!communicationApproved) {
                control.communicationDenied.set(true)
                return "The user did not authorize this outbound action."
            }
            ensureActive(control)
        }

        var unknownApproved = preview.optBoolean("knownTarget").not()
        if (unknownApproved) {
            val approved = awaitCoordinateConsent(control, label)
            if (!approved) return "The user declined this unlabelled coordinate tap."
            ensureActive(control)
        }

        // Recheck the target after approval pauses; screen content may have moved.
        val finalPreview = try { JSONObject(AccessibilityBridge.previewClickAt(x, y, screenshotWidth, screenshotHeight)) }
            catch (_: Exception) { return "Could not revalidate the coordinate. Capture a fresh screenshot." }
        if (!finalPreview.optBoolean("valid", false)) return finalPreview.optString("message", "The coordinate target changed.")
        if (finalPreview.optString("label") != label || finalPreview.optString("category", "unknown") == "restricted") {
            return "The coordinate target changed after approval. No tap was performed; capture a fresh screenshot."
        }
        if (finalPreview.optString("category") == "communication" && !communicationApproved) {
            return "The target now appears to be an outbound communication control. Request approval before tapping."
        }
        if (!finalPreview.optBoolean("knownTarget", false) && !unknownApproved) {
            return "The target is unlabelled and needs one-time confirmation before tapping."
        }
        ensureActive(control)
        // A coordinate snapshot is single-use. Never let a delayed or repeated action reuse it.
        invalidateCoordinateScreenshot(control)
        return AccessibilityBridge.clickAt(
            x, y, screenshotWidth, screenshotHeight,
            communicationActionApproved = communicationApproved,
            unknownTargetApproved = unknownApproved
        )
    }

    private fun firstElementId(searchResult: String): String = runCatching {
        JSONObject(searchResult).optJSONArray("elements")?.optJSONObject(0)?.optString("id").orEmpty()
    }.getOrDefault("")

    private fun executeDragElement(
        startTarget: String, endTarget: String, durationMs: Long, requestedPurpose: String, control: RunControl
    ): String {
        if (startTarget.isBlank() || endTarget.isBlank()) return "drag_element requires both startTarget and endTarget."
        val purpose = requestedPurpose.trim().lowercase()
        if (purpose !in setOf("navigation", "preparation", "communication")) {
            return "Invalid drag purpose. Use navigation, preparation, or communication."
        }
        val startId = firstElementId(AccessibilityBridge.searchElements(startTarget))
        if (startId.isBlank()) return "Could not find drag start '$startTarget'. Search again or use drag_xy with a fresh screenshot."
        // searchElements retains recent IDs from the same app for this two-endpoint operation.
        val endId = firstElementId(AccessibilityBridge.searchElements(endTarget))
        if (endId.isBlank()) return "Could not find drag destination '$endTarget'. Search again or use drag_xy with a fresh screenshot."
        fun preview(id: String): JSONObject? = runCatching { JSONObject(AccessibilityBridge.previewClickElement(id)) }.getOrNull()
        val start = preview(startId) ?: return "Could not inspect the drag start. Search again."
        val end = preview(endId) ?: return "Could not inspect the drag destination. Search again."
        if (!start.optBoolean("valid", false)) return start.optString("message", "Drag start is unavailable.")
        if (!end.optBoolean("valid", false)) return end.optString("message", "Drag destination is unavailable.")
        val startLabel = start.optString("label").ifBlank { startTarget }
        val endLabel = end.optString("label").ifBlank { endTarget }
        val startCategory = start.optString("category", "ordinary")
        val endCategory = end.optString("category", "ordinary")
        if (startCategory == "restricted" || endCategory == "restricted") {
            return "BLOCKED: This drag touches a restricted payment, account, security, permission, or data control."
        }
        val communication = startCategory == "communication" || endCategory == "communication" || purpose == "communication"
        if (communication) {
            if (control.communicationDenied.get()) return "The user declined an outbound communication action earlier in this task."
            if (!awaitCommunicationConsent(control, "Drag from $startLabel to $endLabel")) {
                control.communicationDenied.set(true)
                return "The user did not authorize this outbound drag."
            }
        }
        ensureActive(control)
        val finalStart = preview(startId) ?: return "Could not revalidate the drag start. Search again."
        val finalEnd = preview(endId) ?: return "Could not revalidate the drag destination. Search again."
        if (!finalStart.optBoolean("valid", false) || !finalEnd.optBoolean("valid", false) ||
            finalStart.optString("label") != start.optString("label") ||
            finalEnd.optString("label") != end.optString("label") ||
            finalStart.optString("category") == "restricted" || finalEnd.optString("category") == "restricted" ||
            ((finalStart.optString("category") == "communication" || finalEnd.optString("category") == "communication") && !communication)) {
            return "The drag targets changed after approval. No drag was performed; search again."
        }
        val result = AccessibilityBridge.dragElements(startId, endId, durationMs, communication)
        if (result.startsWith("Dragged ", true)) invalidateCoordinateScreenshot(control)
        return result
    }

    private fun redactSequenceAuditArgs(args: JSONObject): JSONObject {
        val safe = JSONObject(args.toString())
        val steps = safe.optJSONArray("steps") ?: return safe
        for (index in 0 until steps.length()) {
            val step = steps.optJSONObject(index) ?: continue
            when (step.optString("action").lowercase()) {
                "type" -> if (step.has("text")) {
                    val length = step.optString("text").length
                    step.put("text", "[redacted · $length characters]")
                }
                "set" -> if (step.has("value")) step.put("value", "[redacted]")
                "append" -> {
                    if (step.has("value")) step.put("value", "[redacted]")
                    if (step.has("text")) step.put("text", "[redacted]")
                }
            }
            val conditions = step.optJSONArray("conditions")
            if (conditions != null) {
                for (conditionIndex in 0 until conditions.length()) {
                    conditions.optJSONObject(conditionIndex)?.let { condition ->
                        if (condition.has("value")) condition.put("value", "[redacted]")
                    }
                }
            }
        }
        return safe
    }

    private fun executeHoldXY(
        x: Int, y: Int, screenshotWidth: Int, screenshotHeight: Int, durationMs: Long,
        requestedPurpose: String, control: RunControl
    ): String {
        if (!hasFreshCoordinateScreenshot(screenshotWidth, screenshotHeight, control)) {
            return "These coordinates do not match the latest screenshot. Call inspect_screen again."
        }
        val purpose = requestedPurpose.trim().lowercase()
        if (purpose !in setOf("navigation", "preparation", "communication")) return "Invalid purpose. Use navigation, preparation, or communication."
        val preview = runCatching { JSONObject(AccessibilityBridge.previewClickAt(x, y, screenshotWidth, screenshotHeight)) }.getOrElse {
            return "Could not inspect the long-press target. Capture a fresh screenshot."
        }
        if (!preview.optBoolean("valid", false)) return preview.optString("message", "The long-press target is unavailable.")
        val label = preview.optString("label").ifBlank { "coordinate ($x, $y)" }
        val category = preview.optString("category", "unknown")
        if (category == "restricted") return "BLOCKED: '$label' is a restricted action. Complete it manually."
        val communication = category == "communication" || purpose == "communication"
        if (communication) {
            if (control.communicationDenied.get()) return "The user declined an outbound action earlier in this task."
            if (!awaitCommunicationConsent(control, label)) {
                control.communicationDenied.set(true)
                return "The user did not authorize this outbound action."
            }
        }
        val unknown = !preview.optBoolean("knownTarget", false)
        if (unknown && !awaitCoordinateConsent(control, "Long-press $label")) return "The user declined this unlabelled long-press."
        ensureActive(control)
        val finalPreview = runCatching { JSONObject(AccessibilityBridge.previewClickAt(x, y, screenshotWidth, screenshotHeight)) }.getOrElse {
            return "Could not revalidate the long-press target."
        }
        if (!finalPreview.optBoolean("valid", false) || finalPreview.optString("label") != preview.optString("label") ||
            finalPreview.optString("category", "unknown") == "restricted" ||
            (finalPreview.optString("category", "unknown") == "communication" && !communication)) {
            return "The long-press target changed after confirmation. Capture a fresh screenshot."
        }
        invalidateCoordinateScreenshot(control)
        return AccessibilityBridge.holdAt(x, y, screenshotWidth, screenshotHeight, durationMs, communication, unknown)
    }

    private fun executeDragXY(
        startX: Int, startY: Int, endX: Int, endY: Int, screenshotWidth: Int, screenshotHeight: Int,
        durationMs: Long, requestedPurpose: String, control: RunControl
    ): String {
        if (!hasFreshCoordinateScreenshot(screenshotWidth, screenshotHeight, control)) {
            return "These coordinates do not match the latest screenshot. Call inspect_screen again."
        }
        val purpose = requestedPurpose.trim().lowercase()
        if (purpose !in setOf("navigation", "preparation", "communication")) return "Invalid purpose."
        fun preview(x: Int, y: Int): JSONObject? = runCatching {
            JSONObject(AccessibilityBridge.previewClickAt(x, y, screenshotWidth, screenshotHeight))
        }.getOrNull()
        val start = preview(startX, startY) ?: return "Could not inspect the drag start. Capture a fresh screenshot."
        val end = preview(endX, endY) ?: return "Could not inspect the drag destination. Capture a fresh screenshot."
        if (!start.optBoolean("valid", false)) return "Drag start: ${start.optString("message")}"
        if (!end.optBoolean("valid", false)) return "Drag destination: ${end.optString("message")}"
        val fromLabel = start.optString("label").ifBlank { "unlabelled drag start" }
        val toLabel = end.optString("label").ifBlank { "unlabelled drag destination" }
        if (start.optString("category") == "restricted" || end.optString("category") == "restricted") {
            return "BLOCKED: This drag touches a restricted payment, account, security, permission, or data control."
        }
        val communication = start.optString("category") == "communication" || end.optString("category") == "communication" || purpose == "communication"
        if (communication) {
            if (control.communicationDenied.get()) return "The user declined an outbound action earlier in this task."
            if (!awaitCommunicationConsent(control, "Drag from $fromLabel to $toLabel")) {
                control.communicationDenied.set(true)
                return "The user did not authorize this outbound action."
            }
        }
        val unknown = !start.optBoolean("knownTarget", false) || !end.optBoolean("knownTarget", false)
        if (unknown && !awaitCoordinateConsent(control, "Drag from $fromLabel to $toLabel")) return "The user declined this unlabelled drag."
        ensureActive(control)
        val finalStart = preview(startX, startY) ?: return "Could not revalidate drag start."
        val finalEnd = preview(endX, endY) ?: return "Could not revalidate drag destination."
        if (!finalStart.optBoolean("valid", false) || !finalEnd.optBoolean("valid", false) ||
            finalStart.optString("label") != start.optString("label") || finalEnd.optString("label") != end.optString("label") ||
            finalStart.optString("category") == "restricted" || finalEnd.optString("category") == "restricted" ||
            ((finalStart.optString("category") == "communication" || finalEnd.optString("category") == "communication") && !communication)) {
            return "The drag targets changed after confirmation. Capture a fresh screenshot."
        }
        invalidateCoordinateScreenshot(control)
        return AccessibilityBridge.dragAt(startX, startY, endX, endY, screenshotWidth, screenshotHeight,
            durationMs, communication, unknown)
    }

    private fun hasFreshCoordinateScreenshot(width: Int, height: Int, control: RunControl): Boolean {
        if (width <= 0 || height <= 0) return false
        val enabled = appContext.getSharedPreferences("agent_settings", Context.MODE_PRIVATE)
            .getBoolean("visual_fallback_enabled", true)
        return enabled && control.coordinateScreenshotValid && width == control.latestScreenshotWidth && height == control.latestScreenshotHeight
    }

    private fun awaitCoordinateConsent(control: RunControl, actionLabel: String): Boolean {
        ensureActive(control)
        val latch = CountDownLatch(1)
        val approved = AtomicBoolean(false)
        control.pendingApprovalLatch = latch
        status(control, "Waiting for confirmation before an unlabelled tap")
        mainHandler.post {
            if (control.cancelled.get()) latch.countDown()
            else control.listener.onCoordinateApprovalRequired(actionLabel) { decision ->
                if (!control.cancelled.get()) approved.set(decision)
                latch.countDown()
            }
        }
        try {
            while (!latch.await(APPROVAL_POLL_INTERVAL_MS, TimeUnit.MILLISECONDS)) ensureActive(control)
            ensureActive(control)
            return approved.get()
        } catch (_: InterruptedException) {
            Thread.currentThread().interrupt()
            throw CancellationException("Task cancelled while waiting for coordinate confirmation.")
        } finally {
            if (control.pendingApprovalLatch === latch) control.pendingApprovalLatch = null
        }
    }

    /** Applies the explicit communication auto-approval preference, or pauses for this specific action. */
    private fun awaitCommunicationConsent(control: RunControl, actionLabel: String): Boolean {
        ensureActive(control)
        val autoApproved = appContext.getSharedPreferences("agent_settings", Context.MODE_PRIVATE)
            .getBoolean(AUTO_APPROVE_COMMUNICATIONS_KEY, false)
        if (autoApproved) {
            if (control.turnId > 0) {
                store.addToolEvent(
                    control.turnId,
                    "communication_auto_approval",
                    JSONObject().put("control", actionLabel.take(180)),
                    "Automatically approved by the user's enabled messaging/posting setting.",
                    "This preference applies only to send/post/share/upload/comment/reply actions. Restricted action categories remain blocked."
                )
            }
            return true
        }
        val latch = CountDownLatch(1)
        val approved = AtomicBoolean(false)
        control.pendingApprovalLatch = latch
        if (control.turnId > 0) {
            store.addToolEvent(
                control.turnId,
                "communication_approval",
                JSONObject().put("control", actionLabel),
                "Waiting for the user to approve a send/post/share action.",
                "The agent paused before one outbound action and requested individual approval."
            )
        }
        status(control, "Waiting for approval before sending or publishing")
        mainHandler.post {
            if (control.cancelled.get()) {
                latch.countDown()
            } else {
                control.listener.onCommunicationApprovalRequired(actionLabel) { decision ->
                    if (!control.cancelled.get()) approved.set(decision)
                    latch.countDown()
                }
            }
        }
        try {
            while (!latch.await(APPROVAL_POLL_INTERVAL_MS, TimeUnit.MILLISECONDS)) {
                ensureActive(control)
            }
            ensureActive(control)
            val decision = approved.get()
            if (control.turnId > 0) {
                store.addToolEvent(
                    control.turnId,
                    "communication_approval_result",
                    JSONObject().put("control", actionLabel),
                    if (decision) "Approved for this action." else "Declined by the user.",
                    if (decision) "User approved this specific outbound action." else "No further communication actions are allowed in this task."
                )
            }
            return decision
        } catch (_: InterruptedException) {
            Thread.currentThread().interrupt()
            throw CancellationException("Task cancelled while waiting for communication approval.")
        } finally {
            if (control.pendingApprovalLatch === latch) control.pendingApprovalLatch = null
        }
    }

    /** Bounded local workflow: variables, substitutions, branching and gesture actions. */
    private data class SequenceOutcome(val message: String, val success: Boolean, val found: Boolean? = null)

    private fun executeSequence(args: JSONObject, control: RunControl): String {
        val steps = args.optJSONArray("steps") ?: return "sequence requires a steps array."
        if (steps.length() == 0) return "sequence has no steps."
        if (steps.length() > MAX_SEQUENCE_STEPS) return "sequence is limited to $MAX_SEQUENCE_STEPS steps."
        val startedAt = System.nanoTime()
        val log = JSONArray()
        val variables = linkedMapOf<String, String>()
        var previous = SequenceOutcome("", false, null)
        var summary = args.optString("summary").trim()

        fun interpolate(raw: String): String {
            val pattern = Regex("\\$\\{([A-Za-z_][A-Za-z0-9_]*)}")
            return pattern.replace(raw) { match ->
                when (val key = match.groupValues[1]) {
                    "last_result" -> previous.message.take(1500)
                    "last_success" -> previous.success.toString()
                    "last_found" -> (previous.found == true).toString()
                    else -> variables[key].orEmpty()
                }
            }.take(4000)
        }
        fun valueCondition(actual: String, operator: String, expected: String): Boolean {
            return when (operator) {
                "equals" -> actual == expected
                "not_equals" -> actual != expected
                "contains" -> actual.contains(expected, ignoreCase = true)
                "not_contains" -> !actual.contains(expected, ignoreCase = true)
                "starts_with" -> actual.startsWith(expected, ignoreCase = true)
                "ends_with" -> actual.endsWith(expected, ignoreCase = true)
                "greater_than", "less_than", "greater_or_equal", "less_or_equal" -> {
                    val actualNumber = actual.toDoubleOrNull() ?: return false
                    val expectedNumber = expected.toDoubleOrNull() ?: return false
                    when (operator) {
                        "greater_than" -> actualNumber > expectedNumber
                        "less_than" -> actualNumber < expectedNumber
                        "greater_or_equal" -> actualNumber >= expectedNumber
                        else -> actualNumber <= expectedNumber
                    }
                }
                "truthy" -> actual.isNotBlank() && actual.lowercase() !in setOf("false", "0", "null", "no")
                "falsey" -> actual.isBlank() || actual.lowercase() in setOf("false", "0", "null", "no")
                "empty" -> actual.isBlank()
                "not_empty" -> actual.isNotBlank()
                else -> false
            }
        }
        fun conditionPasses(step: JSONObject, condition: String): Boolean {
            val variable = step.optString("variable").trim()
            val actual = variables[variable].orEmpty()
            val expected = interpolate(step.optString("value"))
            return when (condition) {
                "always" -> true
                "success", "last_success" -> previous.success
                "failure", "last_failure" -> previous.message.isNotBlank() && !previous.success
                "found", "last_found" -> previous.found == true
                "not_found" -> previous.found == false
                "truthy", "falsey", "equals", "not_equals", "contains", "not_contains",
                "starts_with", "ends_with", "greater_than", "less_than", "greater_or_equal", "less_or_equal", "empty", "not_empty" ->
                    valueCondition(actual, condition, expected)
                "last_contains" -> previous.message.contains(expected, ignoreCase = true)
                "last_not_contains" -> !previous.message.contains(expected, ignoreCase = true)
                else -> false
            }
        }
        fun conditionsPass(step: JSONObject): Boolean {
            val conditions = step.optJSONArray("conditions") ?: return true
            if (conditions.length() == 0) return true
            val results = (0 until conditions.length()).map { index ->
                val item = conditions.optJSONObject(index) ?: return@map false
                val variable = item.optString("variable").trim()
                val actual = variables[variable].orEmpty()
                val expected = interpolate(item.optString("value"))
                valueCondition(actual, item.optString("operator", "equals").lowercase(), expected)
            }
            return if (step.optString("match", "all").equals("any", true)) results.any { it } else results.all { it }
        }
        fun result(message: String, success: Boolean, found: Boolean? = null) = SequenceOutcome(message, success, found)

        for (i in 0 until steps.length()) {
            ensureActive(control)
            if ((System.nanoTime() - startedAt) / 1_000_000L >= MAX_SEQUENCE_RUNTIME_MS) {
                previous = result("Sequence stopped at the ${MAX_SEQUENCE_RUNTIME_MS / 1000}-second runtime limit.", false)
                break
            }
            val step = steps.optJSONObject(i) ?: continue
            val action = step.optString("action").lowercase()
            val condition = step.optString("if", "always").lowercase().ifBlank { "always" }
            if (!conditionPasses(step, condition) || !conditionsPass(step)) {
                log.put(JSONObject().put("step", i + 1).put("action", action).put("status", "skipped").put("if", condition))
                continue
            }
            fun field(key: String, fallback: String = ""): String = interpolate(step.optString(key, fallback))
            val stepResult = when (action) {
                "search" -> {
                    val query = field("target").ifBlank { field("query") }
                    if (query.isBlank()) result("Search step requires target/query.", false) else {
                        val raw = AccessibilityBridge.searchElements(query)
                        val count = runCatching { JSONObject(raw).optJSONArray("elements")?.length() ?: 0 }.getOrDefault(0)
                        result(if (count > 0) "Found $count matching element(s): $raw" else raw, count > 0, count > 0)
                    }
                }
                "click" -> {
                    val target = field("target").ifBlank { field("query") }
                    val raw = if (target.isBlank()) "" else AccessibilityBridge.searchElements(target)
                    val id = runCatching { JSONObject(raw).optJSONArray("elements")?.optJSONObject(0)?.optString("id").orEmpty() }.getOrDefault("")
                    if (id.isBlank()) result("No matching element found for '$target'.", false, false) else {
                        val value = executeClickElement(id, field("purpose", "navigation"), control)
                        result(value, value.startsWith("Clicked:", true), true)
                    }
                }
                "click_xy" -> {
                    val value = executeClickXY(step.optInt("x", -1), step.optInt("y", -1), step.optInt("screenshotWidth", -1),
                        step.optInt("screenshotHeight", -1), field("purpose", "navigation"), control)
                    result(value, value.startsWith("Tapped coordinate", true))
                }
                "hold_xy" -> {
                    val value = executeHoldXY(step.optInt("x", -1), step.optInt("y", -1), step.optInt("screenshotWidth", -1),
                        step.optInt("screenshotHeight", -1), step.optLong("durationMs", 900L), field("purpose", "navigation"), control)
                    result(value, value.startsWith("Held ", true))
                }
                "drag_xy" -> {
                    val value = executeDragXY(step.optInt("startX", -1), step.optInt("startY", -1), step.optInt("endX", -1),
                        step.optInt("endY", -1), step.optInt("screenshotWidth", -1), step.optInt("screenshotHeight", -1),
                        step.optLong("durationMs", 650L), field("purpose", "navigation"), control)
                    result(value, value.startsWith("Dragged ", true))
                }
                "drag_element" -> {
                    val value = executeDragElement(field("startTarget"), field("endTarget"),
                        step.optLong("durationMs", 650L), field("purpose", "navigation"), control)
                    result(value, value.startsWith("Dragged ", true))
                }
                "hold_element" -> {
                    val target = field("target")
                    val raw = if (target.isBlank()) "" else AccessibilityBridge.searchElements(target)
                    val id = runCatching { JSONObject(raw).optJSONArray("elements")?.optJSONObject(0)?.optString("id").orEmpty() }.getOrDefault("")
                    if (id.isBlank()) result("No matching element found for long-press target '$target'.", false, false) else {
                        val preview = runCatching { JSONObject(AccessibilityBridge.previewClickElement(id)) }.getOrNull()
                        if (preview == null || !preview.optBoolean("valid", false)) result("The long-press element is unavailable. Search again.", false)
                        else {
                            val label = preview.optString("label").ifBlank { target }
                            val category = preview.optString("category", "ordinary")
                            if (category == "restricted") result("BLOCKED: '$label' is restricted.", false)
                            else {
                                val communication = category == "communication" || field("purpose", "navigation") == "communication"
                                val approved = if (!communication) true else if (control.communicationDenied.get()) false else awaitCommunicationConsent(control, label)
                                if (!approved) {
                                    control.communicationDenied.set(true)
                                    result("The user did not authorize this outbound long-press.", false)
                                } else {
                                    val value = AccessibilityBridge.holdElement(id, step.optLong("durationMs", 900L), communication)
                                    invalidateCoordinateScreenshot(control)
                                    result(value, value.startsWith("Long-pressed ", true))
                                }
                            }
                        }
                    }
                }
                "type" -> {
                    val value = AccessibilityBridge.typeText(field("text"))
                    invalidateCoordinateScreenshot(control)
                    result(value, value.startsWith("Text entered", true))
                }
                "scroll" -> {
                    val value = AccessibilityBridge.scroll(field("direction", "down"))
                    invalidateCoordinateScreenshot(control)
                    result(value, value.startsWith("Scrolled", true))
                }
                "wait" -> {
                    val value = waitTime(step.optLong("milliseconds", 300L), control)
                    invalidateCoordinateScreenshot(control)
                    result(value, value.startsWith("Waited", true))
                }
                "wait_for" -> {
                    val value = waitUntilElement(field("target").ifBlank { field("query") }, step.optLong("timeout", 5000L), control)
                    invalidateCoordinateScreenshot(control)
                    val found = value.startsWith("Found ", true)
                    result(value, found, found)
                }
                "back" -> {
                    val value = AccessibilityBridge.pressBack()
                    invalidateCoordinateScreenshot(control)
                    result(value, value.startsWith("Pressed Back", true))
                }
                "set" -> {
                    val variable = step.optString("variable").trim()
                    if (!VARIABLE_NAME.matches(variable)) result("Invalid variable name '$variable'.", false) else {
                        val source = step.optString("from").lowercase()
                        val value = when (source) {
                            "last_result" -> previous.message
                            "last_success" -> previous.success.toString()
                            "last_found" -> (previous.found == true).toString()
                            else -> field("value")
                        }.take(MAX_SEQUENCE_VARIABLE_LENGTH)
                        variables[variable] = value
                        result("Set variable '$variable'.", true)
                    }
                }
                "increment" -> {
                    val variable = step.optString("variable").trim()
                    if (!VARIABLE_NAME.matches(variable)) result("Invalid variable name '$variable'.", false) else {
                        val current = variables[variable]?.toLongOrNull() ?: 0L
                        val amount = step.optLong("amount", 1L).coerceIn(-100000L, 100000L)
                        val updated = (current + amount).coerceIn(-1_000_000L, 1_000_000L)
                        variables[variable] = updated.toString()
                        result("Variable '$variable' is now $updated.", true)
                    }
                }
                "append" -> {
                    val variable = step.optString("variable").trim()
                    if (!VARIABLE_NAME.matches(variable)) result("Invalid variable name '$variable'.", false) else {
                        val updated = (variables[variable].orEmpty() + field("text").ifBlank { field("value") })
                            .take(MAX_SEQUENCE_VARIABLE_LENGTH)
                        variables[variable] = updated
                        result("Appended text to variable '$variable'.", true)
                    }
                }
                "unset" -> {
                    val variable = step.optString("variable").trim()
                    if (!VARIABLE_NAME.matches(variable)) result("Invalid variable name '$variable'.", false) else {
                        variables.remove(variable)
                        result("Cleared variable '$variable'.", true)
                    }
                }
                "summary" -> {
                    val note = field("text").ifBlank { field("summary") }
                    if (note.isNotBlank()) summary = note
                    result("Sequence summary recorded.", true)
                }
                else -> result("Unsupported sequence action '$action'.", false)
            }
            previous = stepResult
            log.put(JSONObject().put("step", i + 1).put("action", action)
                .put("status", if (stepResult.success) "success" else "failure")
                .put("result", stepResult.message.take(900)))
            status(control, "Sequence · ${i + 1}/${steps.length()} · $action")
            if (stepResult.message.startsWith("BLOCKED:") || stepResult.message.startsWith("NEEDS_APPROVAL:") ||
                stepResult.message.startsWith("NEEDS_CONFIRMATION:") || stepResult.message.startsWith("The user did not authorize") ||
                stepResult.message.startsWith("The user declined")) break
        }
        val variableNames = JSONArray()
        variables.keys.forEach { variableNames.put(it) }
        return JSONObject().put("steps", log).put("lastResult", previous.message)
            .put("lastSuccess", previous.success).put("lastFound", previous.found == true)
            .put("variableNames", variableNames)
            .put("summary", summary.ifBlank { "Sequence completed ${log.length()} step(s)." }).toString()
    }

    private fun executeTool(name: String, args: JSONObject, control: RunControl): String = try {
        ensureActive(control)
        when (name) {
            "search_internet" -> gemini.searchInternet(args.optString("query"))
            "search_elements" -> {
                val result = AccessibilityBridge.searchElements(args.optString("query"))
                result
            }
            "inspect_screen" -> {
                val visualEnabled = appContext.getSharedPreferences("agent_settings", Context.MODE_PRIVATE)
                    .getBoolean("visual_fallback_enabled", true)
                if (!visualEnabled) {
                    "Visual Screenshots are disabled in Agently settings. No screenshot was captured or sent. Enable Visual Fallback to let Gemini inspect on-screen images and visual content."
                } else {
                    status(control, "Capturing screen for visual inspection")
                    val capture = AccessibilityBridge.captureScreenshot()
                    control.pendingScreenshot = capture
                    control.latestScreenshotWidth = capture.width
                    control.latestScreenshotHeight = capture.height
                    control.latestScreenshotMutationVersion = control.uiMutationVersion
                    control.coordinateScreenshotValid = false
                    "Captured the current screen (${capture.width}x${capture.height}). The image will be attached as Gemini image input on the next turn."
                }
            }
            "click_element" -> {
                val result = executeClickElement(args.optString("elementId"), args.optString("purpose"), control)
                result
            }
            "click_xy" -> {
                executeClickXY(args.optInt("x", -1), args.optInt("y", -1),
                    args.optInt("screenshotWidth", -1), args.optInt("screenshotHeight", -1), args.optString("purpose"), control)
            }
            "hold_xy" -> executeHoldXY(args.optInt("x", -1), args.optInt("y", -1),
                args.optInt("screenshotWidth", -1), args.optInt("screenshotHeight", -1),
                args.optLong("durationMs", 900L), args.optString("purpose"), control)
            "drag_xy" -> executeDragXY(args.optInt("startX", -1), args.optInt("startY", -1),
                args.optInt("endX", -1), args.optInt("endY", -1), args.optInt("screenshotWidth", -1),
                args.optInt("screenshotHeight", -1), args.optLong("durationMs", 650L), args.optString("purpose"), control)
            "drag_element" -> executeDragElement(
                args.optString("startTarget"), args.optString("endTarget"),
                args.optLong("durationMs", 650L), args.optString("purpose", "navigation"), control
            )
            "hold_element" -> {
                val id = args.optString("elementId")
                val preview = runCatching { JSONObject(AccessibilityBridge.previewClickElement(id)) }.getOrNull()
                if (preview == null || !preview.optBoolean("valid", false)) preview?.optString("message") ?: "Could not validate element. Search again."
                else {
                    val label = preview.optString("label").ifBlank { "the selected control" }
                    val category = preview.optString("category", "ordinary")
                    if (category == "restricted") "BLOCKED: '$label' is a restricted action."
                    else {
                        val communication = category == "communication" || args.optString("purpose") == "communication"
                        val approved = if (!communication) true else if (control.communicationDenied.get()) false else awaitCommunicationConsent(control, label)
                        if (!approved) {
                            control.communicationDenied.set(true)
                            "The user did not authorize this outbound long-press."
                        } else AccessibilityBridge.holdElement(id, args.optLong("durationMs", 900L), communication)
                            .also { invalidateCoordinateScreenshot(control) }
                    }
                }
            }
            "type_text" -> AccessibilityBridge.typeText(args.optString("text")).also { invalidateCoordinateScreenshot(control) }
            "scroll" -> AccessibilityBridge.scroll(args.optString("direction")).also { invalidateCoordinateScreenshot(control) }
            "press_back" -> AccessibilityBridge.pressBack().also { invalidateCoordinateScreenshot(control) }
            "get_screen_info" -> AccessibilityBridge.getScreenInfo()
            "wait_time" -> waitTime(args.optLong("milliseconds", -1L), control).also { invalidateCoordinateScreenshot(control) }
            "wait_until_element" -> waitUntilElement(args.optString("keyword"), args.optLong("timeout", -1L), control).also { invalidateCoordinateScreenshot(control) }
            "sequence" -> executeSequence(args, control)
            else -> "Unknown tool: $name"
        }
    } catch (e: CancellationException) {
        throw e
    } catch (e: InterruptedException) {
        Thread.currentThread().interrupt()
        throw CancellationException("Task cancelled by the user.")
    } catch (e: Exception) {
        if (control.cancelled.get() || Thread.currentThread().isInterrupted) throw CancellationException("Task cancelled by the user.")
        "Tool error: ${e.message ?: e.javaClass.simpleName}"
    }

    private fun invalidateCoordinateScreenshot(control: RunControl) {
        control.uiMutationVersion += 1L
        control.coordinateScreenshotValid = false
        control.latestScreenshotWidth = 0
        control.latestScreenshotHeight = 0
    }

    private fun safeActionSummary(tool: String, args: JSONObject): String = when (tool) {
        "search_internet" -> "Search the public web for: ${args.optString("query").take(90)}"
        "search_elements" -> "Find visible accessibility elements matching: ${args.optString("query").take(90)}"
        "inspect_screen" -> "Capture the current screen for Gemini visual inspection; transmission is controlled by the Visual Fallback setting."
        "click_element" -> "Activate temporary UI element ${args.optString("elementId")} for purpose '${args.optString("purpose")}'. Outbound communication follows the user's messaging/posting approval preference; restricted account/payment/data actions remain blocked."
        "click_xy" -> "Tap screenshot coordinate (${args.optInt("x")}, ${args.optInt("y")}) using screenshot dimensions ${args.optInt("screenshotWidth")}x${args.optInt("screenshotHeight")}; restricted and unlabelled targets are checked before tapping."
        "hold_xy" -> "Long-press screenshot coordinate (${args.optInt("x")}, ${args.optInt("y")}) for ${args.optLong("durationMs")} ms after target checks."
        "drag_xy" -> "Drag from (${args.optInt("startX")}, ${args.optInt("startY")}) to (${args.optInt("endX")}, ${args.optInt("endY")}) for ${args.optLong("durationMs")} ms after target checks."
        "hold_element" -> "Long-press temporary accessibility element ${args.optString("elementId")} for ${args.optLong("durationMs")} ms."
        "drag_element" -> "Drag accessibility element '${args.optString("startTarget").take(60)}' to '${args.optString("endTarget").take(60)}' for ${args.optLong("durationMs")} ms."
        "type_text" -> "Enter user-provided text into the focused editable field; text contents are omitted from this summary."
        "scroll" -> "Scroll the current screen ${args.optString("direction")}."
        "press_back" -> "Navigate back one screen."
        "get_screen_info" -> "Inspect the active app's accessibility labels and window information."
        "wait_time" -> "Wait for ${args.optLong("milliseconds")} milliseconds before continuing."
        "wait_until_element" -> "Wait up to ${args.optLong("timeout")} milliseconds for an element matching '${args.optString("keyword").take(70)}'."
        "sequence" -> "Run a bounded 50-step local workflow with variables, conditions, gestures, and verification."
        "finish" -> "Return the final reply and end the agent loop."
        else -> "Use $tool to continue the requested task."
    }

    private fun waitTime(requestedMs: Long, control: RunControl): String {
        if (requestedMs < 0L) return "Invalid milliseconds. Provide a non-negative duration."
        val duration = requestedMs.coerceAtMost(MAX_WAIT_TIME_MS)
        Thread.sleep(duration)
        ensureActive(control)
        return if (duration == requestedMs) "Waited ${duration} ms."
        else "Waited ${duration} ms (capped from the requested ${requestedMs} ms)."
    }

    private fun waitUntilElement(keyword: String, requestedTimeoutMs: Long, control: RunControl): String {
        if (keyword.isBlank()) return "A non-empty keyword is required."
        if (requestedTimeoutMs <= 0L) return "Invalid timeout. Provide a positive timeout in milliseconds."
        val timeoutMs = requestedTimeoutMs.coerceAtMost(MAX_WAIT_UNTIL_MS)
        val deadline = System.nanoTime() + timeoutMs * 1_000_000L
        var lastResult = ""
        while (System.nanoTime() < deadline) {
            ensureActive(control)
            lastResult = AccessibilityBridge.searchElements(keyword)
            if (lastResult.startsWith("Accessibility service is not connected")) return lastResult
            try {
                val matches = JSONObject(lastResult).optJSONArray("elements")
                if (matches != null && matches.length() > 0) {
                    return "Found ${matches.length()} matching element(s): $lastResult"
                }
            } catch (_: Exception) {
                // A status message such as 'No active window' is not a match; keep waiting.
            }
            val remainingMs = ((deadline - System.nanoTime()) / 1_000_000L).coerceAtLeast(1L)
            Thread.sleep(minOf(WAIT_POLL_INTERVAL_MS, remainingMs))
        }
        ensureActive(control)
        return "Timed out after ${timeoutMs} ms waiting for '$keyword'. Last screen search: ${lastResult.ifBlank { "no active accessibility window" }}"
    }

    private fun status(control: RunControl, value: String) {
        ensureActive(control)
        mainHandler.post { if (!control.cancelled.get()) control.listener.onStatus(value) }
    }

    companion object {
        private const val MAX_AGENT_STEPS = 36
        private const val MAX_SEQUENCE_STEPS = 50
        private const val MAX_SEQUENCE_RUNTIME_MS = 180_000L
        private const val MAX_SEQUENCE_VARIABLE_LENGTH = 2000
        private val VARIABLE_NAME = Regex("[A-Za-z_][A-Za-z0-9_]{0,31}")
        private const val AUTO_APPROVE_COMMUNICATIONS_KEY = "auto_approve_communications"
        private const val MAX_WAIT_TIME_MS = 30_000L
        private const val MAX_WAIT_UNTIL_MS = 60_000L
        private const val WAIT_POLL_INTERVAL_MS = 250L
        private const val APPROVAL_POLL_INTERVAL_MS = 150L
    }
}
