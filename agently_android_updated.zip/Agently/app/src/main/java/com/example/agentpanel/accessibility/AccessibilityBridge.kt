package com.example.agentpanel.accessibility

object AccessibilityBridge {
    fun isConnected(): Boolean = AgentAccessibilityService.instance != null

    fun searchElements(query: String): String =
        AgentAccessibilityService.instance?.searchElements(query)
            ?: "Accessibility service is not connected. Enable Agently in Android Settings > Accessibility."

    fun clickElement(id: String): String =
        AgentAccessibilityService.instance?.clickElement(id)
            ?: "Accessibility service is not connected. Enable it in Android Settings > Accessibility."

    fun typeText(text: String): String =
        AgentAccessibilityService.instance?.typeText(text)
            ?: "Accessibility service is not connected. Enable it in Android Settings > Accessibility."

    fun scroll(direction: String): String =
        AgentAccessibilityService.instance?.scroll(direction)
            ?: "Accessibility service is not connected. Enable it in Android Settings > Accessibility."

    fun pressBack(): String =
        AgentAccessibilityService.instance?.pressBack()
            ?: "Accessibility service is not connected. Enable it in Android Settings > Accessibility."

    fun getScreenInfo(): String =
        AgentAccessibilityService.instance?.screenInfo()
            ?: "Accessibility service is not connected. Enable it in Android Settings > Accessibility."
}
