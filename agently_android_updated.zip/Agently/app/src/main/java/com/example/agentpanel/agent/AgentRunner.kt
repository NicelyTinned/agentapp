package com.example.agentpanel.agent

import android.content.Context
import android.os.Handler
import android.os.Looper
import com.example.agentpanel.accessibility.AccessibilityBridge
import com.example.agentpanel.gemini.GeminiClient
import com.example.agentpanel.security.KeyVault
import com.example.agentpanel.storage.ConversationStore
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.CancellationException
import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.concurrent.atomic.AtomicBoolean

class AgentRunner(context: Context) {
    private val appContext = context.applicationContext
    private val vault = KeyVault(appContext)
    private val store = ConversationStore(appContext)
    private val gemini = GeminiClient(appContext, vault)
    private val mainHandler = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    private val auditExecutor = Executors.newSingleThreadExecutor()

    private class RunControl(val listener: Listener) {
        val cancelled = AtomicBoolean(false)
        val cancellationNotified = AtomicBoolean(false)
        val cancellationRecorded = AtomicBoolean(false)
        @Volatile var turnId: Long = -1L
        @Volatile var future: Future<*>? = null
    }

    @Volatile private var activeControl: RunControl? = null

    interface Listener {
        fun onStatus(status: String)
        fun onFinished(reply: String)
        fun onError(message: String)
        fun onCancelled()
    }

    fun run(prompt: String, listener: Listener) {
        val control = RunControl(listener)
        activeControl = control
        control.future = executor.submit {
            var turnId = -1L
            try {
                ensureActive(control)
                val contextText = store.conversationContext()
                turnId = store.createTurn(prompt)
                control.turnId = turnId
                ensureActive(control)
                val contents = JSONArray().put(
                    JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put(
                        "text", "Conversation history and tool audit:\n$contextText\n\nCurrent user request:\n$prompt"
                    )))
                )

                var steps = 0
                var noToolResponses = 0
                while (steps < MAX_AGENT_STEPS) {
                    ensureActive(control)
                    steps++
                    status(control, "Thinking · step $steps")
                    val response = gemini.generate(contents, forceToolCall = noToolResponses >= 2)
                    ensureActive(control)
                    val candidate = response.optJSONArray("candidates")?.optJSONObject(0)
                        ?: throw IllegalStateException(response.optJSONObject("promptFeedback")?.toString() ?: "Gemini returned no candidate.")
                    val modelContent = candidate.optJSONObject("content")
                        ?: throw IllegalStateException("Gemini returned an empty message.")
                    val parts = modelContent.optJSONArray("parts") ?: JSONArray()
                    data class PendingCall(val name: String, val args: JSONObject, val id: String)
                    val calls = mutableListOf<PendingCall>()
                    for (i in 0 until parts.length()) {
                        val part = parts.optJSONObject(i) ?: continue
                        val call = part.optJSONObject("functionCall") ?: part.optJSONObject("function_call")
                        if (call != null) calls.add(PendingCall(
                            call.optString("name"),
                            call.optJSONObject("args") ?: JSONObject(),
                            call.optString("id")
                        ))
                    }
                    contents.put(modelContent)

                    if (calls.isEmpty()) {
                        noToolResponses++
                        contents.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put(
                            "text", "Do not return a plain-text final answer. Continue the agent loop and call finish(reply) when done. Use another tool if needed."
                        ))))
                        continue
                    }
                    noToolResponses = 0

                    for (pendingCall in calls) {
                        ensureActive(control)
                        val name = pendingCall.name
                        val args = pendingCall.args
                        val decision = safeActionSummary(name, args)
                        status(control, "Using $name")
                        if (name == "finish") {
                            ensureActive(control)
                            val reply = args.optString("reply").ifBlank { "The task finished, but no reply text was provided." }
                            store.addToolEvent(turnId, name, args, "Agent loop completed through finish().", decision)
                            store.saveReply(turnId, reply)
                            mainHandler.post { if (!control.cancelled.get()) listener.onFinished(reply) }
                            return@submit
                        }
                        val result = executeTool(name, args, control)
                        ensureActive(control)
                        // The action log records that text was entered, never the literal text itself.
                        val auditArgs = if (name == "type_text") {
                            JSONObject(args.toString()).put("text", "[redacted · ${args.optString("text").length} characters]")
                        } else args
                        store.addToolEvent(turnId, name, auditArgs, result, decision)
                        status(control, "Completed $name")
                        val functionResponse = JSONObject()
                            .put("name", name)
                            .put("response", JSONObject().put("result", result))
                        if (pendingCall.id.isNotBlank()) functionResponse.put("id", pendingCall.id)
                        contents.put(
                            JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("functionResponse", functionResponse)))
                        )
                    }
                }
                throw IllegalStateException("Agent reached the $MAX_AGENT_STEPS-step safety limit without calling finish(). No normal final reply was produced.")
            } catch (e: Exception) {
                if (control.cancelled.get() || e is CancellationException || e is InterruptedException) {
                    recordCancellation(control)
                    notifyCancelled(control)
                } else {
                    val message = e.message ?: e.javaClass.simpleName
                    if (turnId > 0) {
                        store.addToolEvent(turnId, "agent_error", JSONObject(), message, "The agent could not complete the request.")
                        store.saveReply(turnId, "Agent stopped: $message")
                    }
                    mainHandler.post { if (!control.cancelled.get()) listener.onError(message) }
                }
            } finally {
                if (activeControl === control) activeControl = null
            }
        }
    }

    /** Stops future steps, interrupts waits and disconnects an in-flight Gemini request. */
    fun cancel() {
        val control = activeControl ?: return
        if (!control.cancelled.compareAndSet(false, true)) return
        control.future?.cancel(true)
        gemini.cancelCurrentRequest()
        try {
            auditExecutor.execute {
                recordCancellation(control)
                notifyCancelled(control)
            }
        } catch (_: Exception) {
            notifyCancelled(control)
        }
    }

    fun shutdown() {
        cancel()
        executor.shutdownNow()
        auditExecutor.shutdown()
    }

    private fun ensureActive(control: RunControl) {
        if (control.cancelled.get() || Thread.currentThread().isInterrupted) {
            throw CancellationException("Task cancelled by the user.")
        }
    }

    private fun recordCancellation(control: RunControl) {
        val turnId = control.turnId
        if (turnId <= 0 || !control.cancellationRecorded.compareAndSet(false, true)) return
        try {
            store.addToolEvent(turnId, "agent_cancelled", JSONObject(), "Stopped by the user.", "The user cancelled the running task; no further steps were started.")
            store.saveReply(turnId, "Stopped by you.")
        } catch (_: Exception) { }
    }

    private fun notifyCancelled(control: RunControl) {
        if (!control.cancellationNotified.compareAndSet(false, true)) return
        mainHandler.post { control.listener.onCancelled() }
    }

    private fun executeTool(name: String, args: JSONObject, control: RunControl): String = try {
        ensureActive(control)
        when (name) {
            "search_internet" -> gemini.searchInternet(args.optString("query"))
            "search_elements" -> AccessibilityBridge.searchElements(args.optString("query"))
            "click_element" -> AccessibilityBridge.clickElement(args.optString("elementId"))
            "type_text" -> AccessibilityBridge.typeText(args.optString("text"))
            "scroll" -> AccessibilityBridge.scroll(args.optString("direction"))
            "press_back" -> AccessibilityBridge.pressBack()
            "get_screen_info" -> AccessibilityBridge.getScreenInfo()
            "wait_time" -> waitTime(args.optLong("milliseconds", -1L), control)
            "wait_until_element" -> waitUntilElement(args.optString("keyword"), args.optLong("timeout", -1L), control)
            else -> "Unknown tool: $name"
        }
    } catch (e: CancellationException) {
        throw e
    } catch (e: InterruptedException) {
        Thread.currentThread().interrupt()
        throw CancellationException("Task cancelled by the user.")
    } catch (e: Exception) {
        if (control.cancelled.get() || Thread.currentThread().isInterrupted) throw CancellationException("Task cancelled by the user.")
        "Tool error: ${e.message ?: e.javaClass.simpleName}"
    }

    private fun safeActionSummary(tool: String, args: JSONObject): String = when (tool) {
        "search_internet" -> "Search the public web for: ${args.optString("query").take(90)}"
        "search_elements" -> "Find visible accessibility elements matching: ${args.optString("query").take(90)}"
        "click_element" -> "Activate temporary UI element ${args.optString("elementId")}; consequential labels are blocked."
        "type_text" -> "Enter user-provided text into the focused editable field; text contents are omitted from this summary."
        "scroll" -> "Scroll the current screen ${args.optString("direction")}."
        "press_back" -> "Navigate back one screen."
        "get_screen_info" -> "Inspect the active app's accessibility labels and window information."
        "wait_time" -> "Wait for ${args.optLong("milliseconds")} milliseconds before continuing."
        "wait_until_element" -> "Wait up to ${args.optLong("timeout")} milliseconds for an element matching '${args.optString("keyword").take(70)}'."
        "finish" -> "Return the final reply and end the agent loop."
        else -> "Use $tool to continue the requested task."
    }

    private fun waitTime(requestedMs: Long, control: RunControl): String {
        if (requestedMs < 0L) return "Invalid milliseconds. Provide a non-negative duration."
        val duration = requestedMs.coerceAtMost(MAX_WAIT_TIME_MS)
        Thread.sleep(duration)
        ensureActive(control)
        return if (duration == requestedMs) "Waited ${duration} ms."
        else "Waited ${duration} ms (capped from the requested ${requestedMs} ms)."
    }

    private fun waitUntilElement(keyword: String, requestedTimeoutMs: Long, control: RunControl): String {
        if (keyword.isBlank()) return "A non-empty keyword is required."
        if (requestedTimeoutMs <= 0L) return "Invalid timeout. Provide a positive timeout in milliseconds."
        val timeoutMs = requestedTimeoutMs.coerceAtMost(MAX_WAIT_UNTIL_MS)
        val deadline = System.nanoTime() + timeoutMs * 1_000_000L
        var lastResult = ""
        while (System.nanoTime() < deadline) {
            ensureActive(control)
            lastResult = AccessibilityBridge.searchElements(keyword)
            if (lastResult.startsWith("Accessibility service is not connected")) return lastResult
            try {
                val matches = JSONObject(lastResult).optJSONArray("elements")
                if (matches != null && matches.length() > 0) {
                    return "Found ${matches.length()} matching element(s): $lastResult"
                }
            } catch (_: Exception) {
                // A status message such as 'No active window' is not a match; keep waiting.
            }
            val remainingMs = ((deadline - System.nanoTime()) / 1_000_000L).coerceAtLeast(1L)
            Thread.sleep(minOf(WAIT_POLL_INTERVAL_MS, remainingMs))
        }
        ensureActive(control)
        return "Timed out after ${timeoutMs} ms waiting for '$keyword'. Last screen search: ${lastResult.ifBlank { "no active accessibility window" }}"
    }

    private fun status(control: RunControl, value: String) {
        ensureActive(control)
        mainHandler.post { if (!control.cancelled.get()) control.listener.onStatus(value) }
    }

    companion object {
        private const val MAX_AGENT_STEPS = 36
        private const val MAX_WAIT_TIME_MS = 30_000L
        private const val MAX_WAIT_UNTIL_MS = 60_000L
        private const val WAIT_POLL_INTERVAL_MS = 250L
    }
}
