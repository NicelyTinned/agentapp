# Agently for Android

Agently is the Android app from NicelyTinned. It provides a floating task panel, Gemini-powered task processing, optional voice activation, and local conversation/action history.

## Changes in this update

- The app display name and in-app title are now **Agently**. **NicelyTinned** is retained as the company/publisher name.
- Marketing slogans have been removed from the app UI.
- The launcher foreground artwork has been scaled to 65% of its previous size.
- Submitting a task closes the floating panel and opens a full-screen running view with the current task, live activity history, and a prominent Cancel button.
- Cancel interrupts the agent loop, interrupts bounded waits, and disconnects an active Gemini HTTP request. It prevents later steps from starting. Android actions already dispatched before cancellation cannot be rolled back, and a currently executing system action may finish.
- The full-screen running view excludes Agently's own window from accessibility-tree targeting, so the agent does not inspect or click its own status/history overlay.
- Accessibility access is described on the setup screen and again in a consent dialog before Android's Accessibility settings are opened. The disclosure explains that visible interface text, the task prompt, and relevant prior conversation context may be sent to Google Gemini. Screenshots are not captured, and editable/password contents are excluded from screen summaries.
- The app keeps its existing Android application ID so a properly signed update can replace the previous installation. Version code/name are advanced to 3 / 0.3.0.

## Build

1. Install Android Studio with Android SDK Platform 36 and JDK 17.
2. Open the `Agently` project folder in Android Studio.
3. Use Gradle 8.13 with JDK 17, sync the Android Gradle Plugin, then build the `app` module on an Android device (API 26+).
4. This source archive does not include an APK, Gradle wrapper, or release keystore. A local Android SDK/Gradle installation is required for a full Android build.

## First-run setup

1. Open **Agently**.
2. Create one or more Gemini API keys in Google AI Studio, paste them into **Gemini API Keys** (one per line), and tap **Add Key**. Keys are encrypted with AES-GCM using an Android Keystore key.
3. Approve **Draw over other apps**.
4. Read the accessibility disclosure in Agently. Continue to Android's Accessibility settings and enable **Agently accessibility service** only if you accept the described access.
5. Tap **Finish Setup**. The floating edge tab appears at the right edge; tap it to open Agently.
6. Type a task and tap the send arrow. While the agent runs, the floating panel closes and the full-screen activity view appears. **Cancel** stops subsequent agent steps. An action already dispatched to Android or another app cannot be undone by cancellation.
7. Use **View History** for saved conversations and action logs. Voice activation is optional and separately requires microphone permission.

## Accessibility and Play Protect

The service uses Android's `AccessibilityService` API to inspect visible interface labels and controls and to perform user-requested navigation/actions. The project does **not** set `isAccessibilityTool=true`: that designation is reserved for apps whose primary purpose is direct disability support, and it must not be set simply to avoid security checks. Do not modify the declaration to disguise the app's purpose.

Google's current Play policy says the Accessibility API must not power a general-purpose app that autonomously initiates, plans, and executes actions or decisions. A verified accessibility tool is a narrow exception only when the app's primary purpose is to help people with disabilities. This project is a general-purpose assistant, so it must not claim `isAccessibilityTool=true` merely to get around a warning. The in-app disclosure and consent dialog are transparency safeguards; they do not make this agent eligible or guarantee Play Protect approval.

Google also documents that Play Protect may automatically block internet-sideloaded apps in some markets when they request sensitive permissions such as Accessibility. There is no legitimate source-code flag, name change, icon change, or ordinary signing change that makes an ineligible app trusted. The compliant path is to redesign the automation around narrower Android APIs and user-directed flows, or build a genuine disability-support tool whose primary purpose meets Google's accessibility-tool criteria. Only after verifying policy compliance should a developer use Google's official false-positive review/appeal process.

Official references:
- [Google Play policy: Use of the AccessibilityService API](https://support.google.com/googleplay/android-developer/answer/10964491?hl=en)
- [Google Play policy: Permissions and APIs that access sensitive information](https://support.google.com/googleplay/android-developer/answer/16558241)
- [Google for Developers: Play Protect warning guidance](https://developers.google.com/android/play-protect/warning-dev-guidance)

## Tools exposed to Gemini

- `finish(reply: String)`
- `search_internet(query: String)`
- `search_elements(query: String)`
- `click_element(elementId: String)`
- `type_text(text: String)`
- `scroll(direction: String)`
- `press_back()`
- `get_screen_info()`
- `wait_time(milliseconds: Int)` — waits up to 30 seconds.
- `wait_until_element(keyword: String, timeout: Int)` — polls the accessibility tree every 250 ms, up to 60 seconds.

The agent loop has a 36-step safety limit. The app blocks clicks on controls whose labels indicate consequential actions such as send, post, share, buy, pay, transfer, delete, submit, checkout, or confirm; the user must complete those final actions manually. Password fields are never typed into. Text entered by `type_text` is redacted in the local action audit.

## Saved history and privacy

Prompts, final replies, and tool events are stored in a local SQLite database. When a new task is submitted, relevant prior conversation context may be included in Gemini requests. API keys are encrypted locally and are not written to the tool history. The app does not capture screenshots through its accessibility service.

## Project layout

- `MainActivity.kt` — setup, permissions, model/key settings, disclosure, wake-word toggle, and history view.
- `overlay/OverlayService.kt` — floating panel and full-screen task/history/cancel surface.
- `voice/WakeWordService.kt` — explicit foreground `agent` wake-word listener.
- `accessibility/` — Android AccessibilityService and temporary element-ID bridge.
- `gemini/GeminiClient.kt` — Gemini REST client, tool declarations, Google Search grounding, and cancellable HTTP requests.
- `agent/AgentRunner.kt` — bounded multi-step tool loop and cancellation handling.
- `storage/ConversationStore.kt` — local SQLite conversation and redacted tool audit.
- `security/KeyVault.kt` — AES-GCM encrypted API-key list using Android Keystore.

## Gradle signing/build configuration

- Base64 keystore decoding uses an explicit `java.util.Base64` import, avoiding the Gradle Kotlin DSL `java` extension name collision.
- Kotlin bytecode targeting is configured with `kotlin.compilerOptions` and `JvmTarget.JVM_17`; the deprecated `android.kotlinOptions.jvmTarget` DSL is no longer used.
- Base64 input is whitespace-tolerant, so wrapped environment-secret values are accepted.

## Signed release APK (GitHub Actions)

The project supports release signing through environment variables. Do not commit a keystore, passwords, or a populated `local.properties` file. The decoded keystore is written only under `app/build/signing/`, which is ignored by Git.

### 1. Create or choose a release keystore

If you do not already have one, create it locally with the JDK `keytool` command:

```bash
keytool -genkeypair -v -keystore nicelytinned-release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias nicelytinned
```

Keep this keystore and its passwords backed up securely. Losing the signing key can prevent you from publishing updates over an app signed with that key. Never upload the keystore to the source repository.

### 2. Add GitHub Actions secrets

In the GitHub repository, open **Settings → Secrets and variables → Actions → New repository secret** and create these four secrets:

- `ANDROID_KEYSTORE_BASE64`: Base64-encoded bytes of the `.jks`/`.keystore` file.
- `ANDROID_KEYSTORE_PASSWORD`: keystore password.
- `ANDROID_KEY_ALIAS`: alias used when creating the key (for the example above, `nicelytinned`).
- `ANDROID_KEY_PASSWORD`: password for that key alias.

Encode the keystore without adding line breaks. On Linux/macOS:

```bash
base64 -w 0 nicelytinned-release.jks
```

On macOS, where `-w` is unavailable:

```bash
base64 < nicelytinned-release.jks | tr -d '\n'
```

On Windows PowerShell:

```powershell
[Convert]::ToBase64String([IO.File]::ReadAllBytes("nicelytinned-release.jks"))
```

Copy the encoded output into the `ANDROID_KEYSTORE_BASE64` secret. Do not paste any signing secret into chat, source files, or commit history.

### 3. Build the signed APK

Open the repository's **Actions** tab, select **Android signed release**, and choose **Run workflow**. The workflow builds `:app:assembleRelease` with JDK 17 and Gradle 8.13, then uploads the APK as the `agently-release-apk` workflow artifact.

For a local release build, export the same four environment variables in your shell and run:

```bash
gradle :app:assembleRelease
```

A release task intentionally fails if any signing variable is missing. Debug builds do not require release secrets.
