import java.util.Base64
import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Release signing is supplied only through environment variables / CI secrets.
// The decoded keystore lives under app/build (gitignored) and is never packaged in source.
val signingEnv = listOf(
    "ANDROID_KEYSTORE_BASE64",
    "ANDROID_KEYSTORE_PASSWORD",
    "ANDROID_KEY_ALIAS",
    "ANDROID_KEY_PASSWORD"
).associateWith { System.getenv(it)?.takeIf(String::isNotBlank) }
val releaseSigningReady = signingEnv.values.all { it != null }
val requestsReleaseTask = gradle.startParameter.taskNames.any {
    it.contains("release", ignoreCase = true)
}

val releaseKeystoreFile = layout.buildDirectory.file("signing/release-keystore.jks").get().asFile

if (requestsReleaseTask && !releaseSigningReady) {
    throw GradleException(
        "Release signing is not configured. Set ANDROID_KEYSTORE_BASE64, " +
            "ANDROID_KEYSTORE_PASSWORD, ANDROID_KEY_ALIAS, and ANDROID_KEY_PASSWORD."
    )
}

android {
    namespace = "com.example.agentpanel"
    compileSdk = 36

    if (releaseSigningReady) {
        signingConfigs {
            create("release") {
                releaseKeystoreFile.parentFile.mkdirs()
                try {
                    releaseKeystoreFile.writeBytes(
                        Base64.getDecoder().decode(
                            signingEnv.getValue("ANDROID_KEYSTORE_BASE64")!!.filterNot { it.isWhitespace() }
                        )
                    )
                } catch (error: IllegalArgumentException) {
                    throw GradleException("ANDROID_KEYSTORE_BASE64 is not valid Base64.", error)
                }
                storeFile = releaseKeystoreFile
                storePassword = signingEnv.getValue("ANDROID_KEYSTORE_PASSWORD")
                keyAlias = signingEnv.getValue("ANDROID_KEY_ALIAS")
                keyPassword = signingEnv.getValue("ANDROID_KEY_PASSWORD")
            }
        }
    }

    defaultConfig {
        applicationId = "com.example.agentpanel"
        minSdk = 26
        targetSdk = 35
        versionCode = 8
        versionName = "0.4.4"
    }

    buildTypes {
        getByName("release") {
            if (releaseSigningReady) {
                signingConfig = signingConfigs.getByName("release")
            }
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

dependencies {
    // Android framework APIs only. No analytics, ads, or third-party key managers.
}
