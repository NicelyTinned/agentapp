package com.example.agentpanel.accessibility

import android.accessibilityservice.AccessibilityService
import android.graphics.Rect
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityWindowInfo
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONArray
import org.json.JSONObject
import java.util.ArrayDeque
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

class AgentAccessibilityService : AccessibilityService() {
    private data class NodePath(
        val path: List<Int>,
        val label: String,
        val packageName: String,
        val className: String,
        val viewId: String,
        val createdAt: Long
    )

    private val elementIds = ConcurrentHashMap<String, NodePath>()
    private val idCounter = AtomicInteger(1)

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    /**
     * Adds Agently's full-screen task surface as an accessibility overlay.
     * Unlike TYPE_APPLICATION_OVERLAY, TYPE_ACCESSIBILITY_OVERLAY is designed
     * to leave the covered application windows introspectable by this service.
     */
    fun addAgentAccessibilityOverlay(view: View, params: WindowManager.LayoutParams): Boolean {
        return try {
            params.type = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
            (getSystemService(WINDOW_SERVICE) as WindowManager).addView(view, params)
            true
        } catch (_: Exception) {
            false
        }
    }

    fun removeAgentAccessibilityOverlay(view: View): Boolean {
        return try {
            (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(view)
            true
        } catch (_: Exception) {
            false
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Our own full-screen status/approval UI must not invalidate target-app element IDs.
        val eventPackage = event?.packageName?.toString().orEmpty()
        if (eventPackage.equals(packageName, ignoreCase = true)) return
        when (event?.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,
            AccessibilityEvent.TYPE_WINDOWS_CHANGED -> elementIds.clear()
            // Keep IDs across content/scroll events; resolveClickTarget re-identifies
            // them against the latest accessibility tree before every action.
        }
    }

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        if (instance === this) instance = null
        elementIds.clear()
        super.onDestroy()
    }

    fun searchElements(query: String): String {
        val root = targetAppRoot() ?: return "No active app window. Open the app you want to use and try again."
        elementIds.clear()
        val needle = query.trim().lowercase()
        val results = JSONArray()
        val queue = ArrayDeque<Pair<AccessibilityNodeInfo, List<Int>>>()
        queue.add(root to emptyList())
        var inspected = 0
        while (queue.isNotEmpty() && inspected < MAX_NODES && results.length() < MAX_RESULTS) {
            val (node, path) = queue.removeFirst()
            inspected++
            // Do not expose text or descriptions from editable/password fields to the model.
            val sensitive = node.isPassword || node.isEditable
            val text = if (sensitive) "" else node.text?.toString().orEmpty()
            val description = if (sensitive) "" else node.contentDescription?.toString().orEmpty()
            val viewId = node.viewIdResourceName.orEmpty()
            val label = listOf(text, description, viewId).filter { it.isNotBlank() }.joinToString(" | ")
            val matches = needle.isBlank() || text.contains(needle, true) || description.contains(needle, true) || viewId.contains(needle, true)
            if (matches && label.isNotBlank()) {
                val id = "el_${idCounter.getAndIncrement()}"
                val packageName = node.packageName?.toString().orEmpty()
                elementIds[id] = NodePath(
                    path, label, packageName, node.className?.toString().orEmpty(),
                    viewId, System.currentTimeMillis()
                )
                val bounds = Rect()
                node.getBoundsInScreen(bounds)
                results.put(JSONObject()
                    .put("id", id)
                    .put("text", text)
                    .put("contentDescription", description)
                    .put("viewId", viewId)
                    .put("className", node.className?.toString().orEmpty())
                    .put("clickable", node.isClickable)
                    .put("hasClickAction", node.actionList.any { it.id == AccessibilityNodeInfo.ACTION_CLICK })
                    .put("enabled", node.isEnabled)
                    .put("editable", node.isEditable)
                    .put("password", node.isPassword)
                    .put("scrollable", node.isScrollable)
                    .put("bounds", "${bounds.left},${bounds.top},${bounds.right},${bounds.bottom}"))
            }
            for (i in 0 until node.childCount) {
                val child = node.getChild(i) ?: continue
                queue.add(child to (path + i))
            }
        }
        return JSONObject()
            .put("packageName", root.packageName?.toString().orEmpty())
            .put("query", query)
            .put("elements", results)
            .put("truncated", inspected >= MAX_NODES || results.length() >= MAX_RESULTS)
            .toString()
    }

    /** Developer-only, read-only accessibility tree snapshot for diagnosing unusual controls. */
    fun inspectUiTree(): String {
        val root = targetAppRoot() ?: return JSONObject()
            .put("packageName", "")
            .put("message", "No other app window is available. Open the app you want to inspect and refresh.")
            .put("elements", JSONArray())
            .toString()

        elementIds.clear()
        val results = JSONArray()
        val queue = ArrayDeque<Pair<AccessibilityNodeInfo, List<Int>>>()
        queue.add(root to emptyList())
        var inspected = 0
        while (queue.isNotEmpty() && inspected < DEBUG_MAX_NODES && results.length() < DEBUG_MAX_RESULTS) {
            val (node, path) = queue.removeFirst()
            inspected++
            val sensitive = node.isPassword || node.isEditable
            val text = if (sensitive) "" else node.text?.toString().orEmpty()
            val description = if (sensitive) "" else node.contentDescription?.toString().orEmpty()
            val viewId = node.viewIdResourceName.orEmpty()
            val label = listOf(text, description, viewId).filter { it.isNotBlank() }.joinToString(" | ")
            val actions = node.actionList
            val interesting = label.isNotBlank() || node.isClickable || node.isCheckable || actions.isNotEmpty()
            if (interesting) {
                val id = "dbg_${idCounter.getAndIncrement()}"
                val nodePackage = node.packageName?.toString().orEmpty()
                val className = node.className?.toString().orEmpty()
                elementIds[id] = NodePath(path, label, nodePackage, className, viewId, System.currentTimeMillis())
                val bounds = Rect()
                node.getBoundsInScreen(bounds)
                var parent = node.parent
                var clickableAncestor = ""
                var parentDepth = 0
                while (parent != null && parentDepth++ < 8) {
                    val parentHasClickAction = parent.actionList.any { it.id == AccessibilityNodeInfo.ACTION_CLICK }
                    if ((parent.isClickable || parentHasClickAction) && parent.isEnabled && parent.isVisibleToUser) {
                        clickableAncestor = parent.labelForAgent() + if (parentHasClickAction) " [ACTION_CLICK]" else " [clickable]"
                        break
                    }
                    parent = parent.parent
                }
                val actionJson = JSONArray()
                actions.forEach { action ->
                    actionJson.put(JSONObject()
                        .put("id", action.id)
                        .put("label", action.label?.toString().orEmpty()))
                }
                results.put(JSONObject()
                    .put("id", id)
                    .put("label", label)
                    .put("text", text)
                    .put("contentDescription", description)
                    .put("viewId", viewId)
                    .put("className", className)
                    .put("packageName", nodePackage)
                    .put("clickable", node.isClickable)
                    .put("hasClickAction", actions.any { it.id == AccessibilityNodeInfo.ACTION_CLICK })
                    .put("enabled", node.isEnabled)
                    .put("visible", node.isVisibleToUser)
                    .put("focusable", node.isFocusable)
                    .put("focused", node.isFocused)
                    .put("checkable", node.isCheckable)
                    .put("checked", node.isChecked)
                    .put("longClickable", node.isLongClickable)
                    .put("scrollable", node.isScrollable)
                    .put("clickableAncestor", clickableAncestor)
                    .put("actions", actionJson.toString())
                    .put("bounds", "${bounds.left},${bounds.top},${bounds.right},${bounds.bottom}"))
            }
            for (i in 0 until node.childCount) {
                node.getChild(i)?.let { queue.add(it to (path + i)) }
            }
        }
        return JSONObject()
            .put("packageName", root.packageName?.toString().orEmpty())
            .put("elements", results)
            .put("inspectedNodes", inspected)
            .put("truncated", inspected >= DEBUG_MAX_NODES || results.length() >= DEBUG_MAX_RESULTS)
            .toString()
    }

    private data class ClickTarget(
        val actionNode: AccessibilityNodeInfo,
        val targetLabel: String,
        val combinedLabel: String
    )

    /** Returns the exact visible control and its action class without activating it. */
    fun previewClickElement(elementId: String): String {
        val (target, error) = resolveClickTarget(elementId)
        if (target == null) {
            return JSONObject().put("valid", false).put("message", error).toString()
        }
        return JSONObject()
            .put("valid", true)
            .put("label", target.combinedLabel.ifBlank { target.targetLabel })
            .put("category", actionCategory(target.combinedLabel))
            .toString()
    }

    /**
     * Activates an ordinary control, or a communication control only after the agent runner
     * has obtained explicit approval for this specific outbound action. Restricted account/payment/data actions
     * remain blocked regardless of consent.
     */
    fun clickElement(elementId: String, communicationActionApproved: Boolean = false): String {
        val firstResolution = resolveClickTarget(elementId)
        var resolved = firstResolution.first ?: return firstResolution.second

        // The clickable ancestor can be replaced independently of the matched child.
        // Do not ignore refresh() == false: Android defines it as a detached/stale node.
        var actionNodeFresh = try { resolved.actionNode.refresh() } catch (_: Exception) { false }
        if (!actionNodeFresh) {
            val retry = resolveClickTarget(elementId)
            resolved = retry.first ?: return retry.second
            actionNodeFresh = try { resolved.actionNode.refresh() } catch (_: Exception) { false }
            if (!actionNodeFresh) {
                return "The control was replaced while Agently was preparing the click. Search for it again."
            }
        }

        val category = actionCategory(resolved.combinedLabel)
        if (category == "restricted") {
            return "BLOCKED: '${resolved.combinedLabel}' can change payment, account, security, permissions, or stored data. Complete this action manually."
        }
        if (category == "communication" && !communicationActionApproved) {
            return "NEEDS_APPROVAL: '${resolved.combinedLabel}' can send or publish content. Obtain explicit approval for this specific outbound action before clicking."
        }
        if (!resolved.actionNode.isEnabled || !resolved.actionNode.isVisibleToUser) {
            return "Element is currently unavailable. Search again after the UI settles."
        }
        val clicked = try {
            resolved.actionNode.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        } catch (_: Exception) {
            false
        }
        if (clicked) {
            elementIds.clear()
            return "Clicked: ${resolved.targetLabel.ifBlank { resolved.combinedLabel }}"
        }
        return "Android rejected ACTION_CLICK for '${resolved.combinedLabel}'. The target is still visible, but this app did not expose an actionable accessibility control."
    }

    private fun resolveClickTarget(elementId: String): Pair<ClickTarget?, String> {
        val saved = elementIds[elementId]
            ?: return null to "Element ID not found or expired. Run search_elements again."
        if (System.currentTimeMillis() - saved.createdAt > ELEMENT_ID_TTL_MS) {
            elementIds.remove(elementId)
            return null to "Element ID expired. Run search_elements again."
        }

        var root = targetAppRoot() ?: return null to "No active app window."
        if (!root.packageName?.toString().orEmpty().equals(saved.packageName, true)) {
            elementIds.remove(elementId)
            return null to "The active app changed. Run search_elements again."
        }

        fun matches(candidate: AccessibilityNodeInfo): Boolean {
            val label = if (candidate.isPassword || candidate.isEditable)
                candidate.viewIdResourceName.orEmpty() else candidate.labelForAgent()
            return candidate.packageName?.toString().orEmpty().equals(saved.packageName, true) &&
                label == saved.label &&
                candidate.className?.toString().orEmpty() == saved.className &&
                candidate.viewIdResourceName.orEmpty() == saved.viewId
        }

        fun findFreshMatch(searchRoot: AccessibilityNodeInfo): AccessibilityNodeInfo? {
            val queue = ArrayDeque<AccessibilityNodeInfo>()
            queue.add(searchRoot)
            var visited = 0
            while (queue.isNotEmpty() && visited++ < MAX_NODES) {
                val candidate = queue.removeFirst()
                if (candidate.isVisibleToUser && matches(candidate)) return candidate
                for (i in 0 until candidate.childCount) candidate.getChild(i)?.let(queue::add)
            }
            return null
        }

        // A saved child-index path is only a hint: list/Compose UIs can replace nodes
        // between search and click. Validate the fingerprint and, crucially, honour
        // refresh() == false, which Android documents as a node no longer in the view tree.
        var node: AccessibilityNodeInfo? = root
        for (index in saved.path) {
            node = node?.getChild(index)
            if (node == null) break
        }
        var pathNodeIsFresh = false
        if (node != null && matches(node) && node.isVisibleToUser) {
            pathNodeIsFresh = try { node.refresh() } catch (_: Exception) { false }
        }
        if (!pathNodeIsFresh) {
            root = targetAppRoot() ?: return null to "No active app window."
            node = findFreshMatch(root)
            var treeNodeIsFresh = if (node == null) false else try { node.refresh() } catch (_: Exception) { false }
            if (!treeNodeIsFresh) {
                // One more fresh-root pass handles views replaced during the first lookup.
                root = targetAppRoot() ?: return null to "No active app window."
                node = findFreshMatch(root)
                treeNodeIsFresh = if (node == null) false else try { node.refresh() } catch (_: Exception) { false }
            }
            if (!treeNodeIsFresh) {
                return null to "Element changed or left the active view tree before it could be clicked. Search for it again."
            }
        }

        val currentNode = node ?: return null to "Element could not be re-identified in the current screen. Run search_elements again."
        if (!currentNode.isVisibleToUser || !currentNode.isEnabled) {
            return null to "Element is currently hidden or disabled. Wait for the screen to settle and search again."
        }

        val targetLabel = if (currentNode.isPassword || currentNode.isEditable)
            currentNode.viewIdResourceName.orEmpty() else currentNode.labelForAgent()
        fun exposesClickAction(node: AccessibilityNodeInfo): Boolean =
            node.isClickable || node.actionList.any { it.id == AccessibilityNodeInfo.ACTION_CLICK }

        var clickable: AccessibilityNodeInfo? = currentNode
        while (clickable != null && (!exposesClickAction(clickable) || !clickable.isVisibleToUser || !clickable.isEnabled)) {
            clickable = clickable.parent
        }
        val actionNode = clickable ?: currentNode
        val combinedLabel = listOf(targetLabel, actionNode.labelForAgent())
            .filter { it.isNotBlank() }.distinct().joinToString(" | ")
        return ClickTarget(actionNode, targetLabel, combinedLabel) to ""
    }

    private fun actionCategory(label: String): String {
        // Match complete words/phrases so "submit post" and "confirm send" are
        // treated as outbound communication, without confusing "payment" with "pay".
        val normalized = label.lowercase().replace(Regex("[^a-z0-9]+"), " ").trim()
        fun hasPhrase(phrase: String): Boolean =
            (" $normalized ").contains(" ${phrase.lowercase()} ")

        val communication = listOf(
            "send", "post", "share", "publish", "upload", "comment", "reply"
        )
        val isCommunication = communication.any(::hasPhrase)

        val restricted = listOf(
            "purchase", "buy", "pay", "payment", "money", "bank", "donate", "donation", "tip",
            "transfer", "withdraw", "cash out", "top up", "delete", "remove", "place order",
            "checkout", "accept", "agree", "allow", "permission", "subscribe", "unsubscribe",
            "follow", "unfollow", "block", "report", "install", "uninstall", "reset", "sign out",
            "log out", "change password", "security", "grant access"
        )
        if (restricted.any(::hasPhrase)) return "restricted"

        // Generic confirmation/submit controls are not safe to activate without context.
        // When the same control is clearly a send/post action, the explicit approval gate applies.
        if (hasPhrase("submit") || hasPhrase("confirm")) {
            return if (isCommunication) "communication" else "restricted"
        }
        return if (isCommunication) "communication" else "ordinary"
    }

    fun typeText(text: String): String {
        val root = targetAppRoot() ?: return "No active app window."
        val focused = findFocusedEditable(root) ?: return "No focused editable field. Tap the field first, then retry."
        if (focused.isPassword) return "BLOCKED: typing into password fields is not supported."
        if (!focused.isEditable) return "The focused element is not editable."
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        val success = focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        return if (success) "Text entered into the focused field (${text.length} characters)." else "Android rejected text entry. Check that the field is focused and editable."
    }

    fun scroll(direction: String): String {
        val forward = when (direction.trim().lowercase()) {
            "down" -> true
            "up" -> false
            else -> return "Invalid direction. Use up or down."
        }
        val root = targetAppRoot() ?: return "No active app window."
        val scrollable = findScrollable(root) ?: return "No scrollable element found on this screen."
        val action = if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        return if (scrollable.performAction(action)) "Scrolled ${direction.lowercase()}." else "The scroll action was not accepted."
    }

    fun pressBack(): String = if (performGlobalAction(GLOBAL_ACTION_BACK)) "Pressed Back." else "Android did not accept Back."

    fun screenInfo(): String {
        val root = targetAppRoot() ?: return "No active app window."
        val text = StringBuilder()
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var count = 0
        while (queue.isNotEmpty() && count < MAX_NODES && text.length < 5000) {
            val node = queue.removeFirst()
            count++
            // Screen summaries must not leak text from editable or password fields.
            val label = if (node.isPassword || node.isEditable) {
                node.viewIdResourceName.orEmpty()
            } else node.labelForAgent()
            if (label.isNotBlank()) text.append("• ").append(label).append(if (node.isClickable) " [clickable]" else "").append('\n')
            for (i in 0 until node.childCount) node.getChild(i)?.let(queue::add)
        }
        return JSONObject()
            .put("packageName", root.packageName?.toString().orEmpty())
            .put("windowClass", root.className?.toString().orEmpty())
            .put("accessibleText", text.toString())
            .put("truncated", count >= MAX_NODES || text.length >= 5000)
            .toString()
    }

    /**
     * The run-state overlay belongs to Agently and sits above the target app. Prefer the
     * topmost ordinary application window that is not ours so the agent never inspects
     * or clicks its own progress/history surface.
     */
    private fun targetAppRoot(): AccessibilityNodeInfo? {
        val ownPackage = applicationContext.packageName
        val appWindows: List<AccessibilityWindowInfo> = try {
            windows.filter { it.type == AccessibilityWindowInfo.TYPE_APPLICATION }
        } catch (_: Exception) {
            emptyList()
        }
        for (window in appWindows.sortedByDescending { it.isActive || it.isFocused }) {
            val root = try { window.root } catch (_: Exception) { null } ?: continue
            if (!root.packageName?.toString().orEmpty().equals(ownPackage, true)) return root
        }
        return rootInActiveWindow?.takeIf {
            !it.packageName?.toString().orEmpty().equals(ownPackage, true)
        }
    }

    private fun findFocusedEditable(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var count = 0
        while (queue.isNotEmpty() && count++ < MAX_NODES) {
            val node = queue.removeFirst()
            if (node.isFocused && node.isEditable) return node
            for (i in 0 until node.childCount) node.getChild(i)?.let(queue::add)
        }
        return null
    }

    private fun findScrollable(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var count = 0
        while (queue.isNotEmpty() && count++ < MAX_NODES) {
            val node = queue.removeFirst()
            if (node.isScrollable && node.isEnabled) return node
            for (i in 0 until node.childCount) node.getChild(i)?.let(queue::add)
        }
        return null
    }

    private fun AccessibilityNodeInfo.labelForAgent(): String = listOf(
        text?.toString().orEmpty(),
        contentDescription?.toString().orEmpty(),
        viewIdResourceName.orEmpty()
    ).filter { it.isNotBlank() }.joinToString(" | ")

    companion object {
        @Volatile var instance: AgentAccessibilityService? = null
            private set
        private const val MAX_NODES = 700
        private const val MAX_RESULTS = 35
        private const val DEBUG_MAX_NODES = 900
        private const val DEBUG_MAX_RESULTS = 140
        private const val ELEMENT_ID_TTL_MS = 45_000L
    }
}
