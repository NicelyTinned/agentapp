package com.example.agentpanel.agent

import android.content.Context
import android.os.Handler
import android.os.Looper
import com.example.agentpanel.accessibility.AccessibilityBridge
import com.example.agentpanel.gemini.GeminiClient
import com.example.agentpanel.security.KeyVault
import com.example.agentpanel.storage.ConversationStore
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors

class AgentRunner(context: Context) {
    private val appContext = context.applicationContext
    private val vault = KeyVault(appContext)
    private val store = ConversationStore(appContext)
    private val gemini = GeminiClient(appContext, vault)
    private val mainHandler = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()

    interface Listener {
        fun onStatus(status: String)
        fun onFinished(reply: String)
        fun onError(message: String)
    }

    fun run(prompt: String, listener: Listener) {
        executor.execute {
            var turnId = -1L
            try {
                val contextText = store.conversationContext()
                turnId = store.createTurn(prompt)
                val contents = JSONArray().put(
                    JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put(
                        "text", "Conversation history and tool audit:\n$contextText\n\nCurrent user request:\n$prompt"
                    )))
                )

                var steps = 0
                var noToolResponses = 0
                while (steps < MAX_AGENT_STEPS) {
                    steps++
                    status(listener, "Thinking · step $steps")
                    val response = gemini.generate(contents, forceToolCall = noToolResponses >= 2)
                    val candidate = response.optJSONArray("candidates")?.optJSONObject(0)
                        ?: throw IllegalStateException(response.optJSONObject("promptFeedback")?.toString() ?: "Gemini returned no candidate.")
                    val modelContent = candidate.optJSONObject("content")
                        ?: throw IllegalStateException("Gemini returned an empty message.")
                    val parts = modelContent.optJSONArray("parts") ?: JSONArray()
                    data class PendingCall(val name: String, val args: JSONObject, val id: String)
                    val calls = mutableListOf<PendingCall>()
                    var modelActionNote = ""
                    for (i in 0 until parts.length()) {
                        val part = parts.optJSONObject(i) ?: continue
                        if (modelActionNote.isBlank()) modelActionNote = part.optString("text").trim()
                        val call = part.optJSONObject("functionCall") ?: part.optJSONObject("function_call")
                        if (call != null) calls.add(PendingCall(
                            call.optString("name"),
                            call.optJSONObject("args") ?: JSONObject(),
                            call.optString("id")
                        ))
                    }
                    contents.put(modelContent)

                    if (calls.isEmpty()) {
                        noToolResponses++
                        contents.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put(
                            "text", "Do not return a plain-text final answer. Continue the agent loop and call finish(reply) when done. Use another tool if needed."
                        ))))
                        continue
                    }
                    noToolResponses = 0

                    for (pendingCall in calls) {
                        val name = pendingCall.name
                        val args = pendingCall.args
                        val decision = safeActionSummary(name, args)
                        status(listener, "Using $name")
                        if (name == "finish") {
                            val reply = args.optString("reply").ifBlank { "The task finished, but no reply text was provided." }
                            store.addToolEvent(turnId, name, args, "Agent loop completed through finish().", decision)
                            store.saveReply(turnId, reply)
                            mainHandler.post { listener.onFinished(reply) }
                            return@execute
                        }
                        val result = executeTool(name, args)
                        store.addToolEvent(turnId, name, args, result, decision)
                        val functionResponse = JSONObject()
                            .put("name", name)
                            .put("response", JSONObject().put("result", result))
                        if (pendingCall.id.isNotBlank()) functionResponse.put("id", pendingCall.id)
                        contents.put(
                            JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("functionResponse", functionResponse)))
                        )
                    }
                }
                throw IllegalStateException("Agent reached the $MAX_AGENT_STEPS-step safety limit without calling finish(). No normal final reply was produced.")
            } catch (e: Exception) {
                val message = e.message ?: e.javaClass.simpleName
                if (turnId > 0) store.addToolEvent(turnId, "agent_error", JSONObject(), message, "The agent could not complete the request.")
                mainHandler.post { listener.onError(message) }
            }
        }
    }

    private fun executeTool(name: String, args: JSONObject): String = try {
        when (name) {
            "search_internet" -> gemini.searchInternet(args.optString("query"))
            "search_elements" -> AccessibilityBridge.searchElements(args.optString("query"))
            "click_element" -> AccessibilityBridge.clickElement(args.optString("elementId"))
            "type_text" -> AccessibilityBridge.typeText(args.optString("text"))
            "scroll" -> AccessibilityBridge.scroll(args.optString("direction"))
            "press_back" -> AccessibilityBridge.pressBack()
            "get_screen_info" -> AccessibilityBridge.getScreenInfo()
            else -> "Unknown tool: $name"
        }
    } catch (e: Exception) {
        "Tool error: ${e.message ?: e.javaClass.simpleName}"
    }

    private fun safeActionSummary(tool: String, args: JSONObject): String = when (tool) {
        "search_internet" -> "Search the public web for: ${args.optString("query").take(90)}"
        "search_elements" -> "Find visible accessibility elements matching: ${args.optString("query").take(90)}"
        "click_element" -> "Activate temporary UI element ${args.optString("elementId")}; consequential labels are blocked."
        "type_text" -> "Enter user-provided text into the focused editable field; text contents are omitted from this summary."
        "scroll" -> "Scroll the current screen ${args.optString("direction")}."
        "press_back" -> "Navigate back one screen."
        "get_screen_info" -> "Inspect the active app's accessibility labels and window information."
        "finish" -> "Return the final reply and end the agent loop."
        else -> "Use $tool to continue the requested task."
    }

    private fun status(listener: Listener, value: String) = mainHandler.post { listener.onStatus(value) }

    companion object {
        private const val MAX_AGENT_STEPS = 36
    }
}
