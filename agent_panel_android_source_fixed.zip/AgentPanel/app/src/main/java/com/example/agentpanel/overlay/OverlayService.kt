package com.example.agentpanel.overlay

import android.app.Service
import android.content.pm.ServiceInfo
import android.os.Build
import com.example.agentpanel.util.Notifications
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.view.inputmethod.InputMethodManager
import android.content.Context.INPUT_METHOD_SERVICE
import android.view.WindowManager.LayoutParams
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.example.agentpanel.agent.AgentRunner
import com.example.agentpanel.security.KeyVault

class OverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private val mainHandler = Handler(Looper.getMainLooper())
    private var chipView: View? = null
    private var panelView: View? = null
    private var replyText: TextView? = null
    private var statusText: TextView? = null
    private var promptInput: EditText? = null
    private var sendButton: Button? = null
    private var isBusy = false
    private lateinit var agentRunner: AgentRunner

    override fun onCreate() {
        super.onCreate()
        Notifications.createChannel(this, Notifications.OVERLAY_CHANNEL, "Agent Panel", "Notification while the floating edge panel is active.")
        val notification = Notifications.build(this, Notifications.OVERLAY_CHANNEL, "Agent Panel is active", "Floating edge panel is available over your apps.")
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(4201, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(4201, notification)
        }
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        agentRunner = AgentRunner(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!android.provider.Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_OPEN_PANEL) showPanel() else if (panelView == null) showChip()
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun showChip() {
        removePanel()
        if (chipView != null) return
        val chip = TextView(this).apply {
            text = "✦"
            textSize = 27f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = roundBackground(Color.rgb(92, 111, 255), 32f)
            elevation = dp(10).toFloat()
            setOnClickListener { showPanel() }
            contentDescription = "Open Agent Panel"
        }
        val params = LayoutParams(dp(54), dp(82), LayoutParams.TYPE_APPLICATION_OVERLAY,
            LayoutParams.FLAG_NOT_FOCUSABLE or LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
        params.gravity = Gravity.END or Gravity.CENTER_VERTICAL
        params.x = dp(0)
        try {
            windowManager.addView(chip, params)
            chipView = chip
        } catch (_: Exception) {
            stopSelf()
        }
    }

    private fun showPanel() {
        removeChip()
        if (panelView != null) return
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = roundBackground(Color.rgb(19, 25, 38), 22f)
            elevation = dp(16).toFloat()
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "AGENT PANEL"
            textSize = 13f
            letterSpacing = 0.1f
            setTextColor(Color.rgb(197, 207, 233))
            typeface = Typeface.DEFAULT_BOLD
        }
        val close = TextView(this).apply {
            text = "×"
            textSize = 28f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(12), 0, dp(4), 0)
            setOnClickListener { showChip() }
            contentDescription = "Collapse Agent Panel"
        }
        header.addView(title, LinearLayout.LayoutParams(0, dp(40), 1f))
        header.addView(close, LinearLayout.LayoutParams(dp(40), dp(40)))
        root.addView(header)

        val status = TextView(this).apply {
            text = "ready · ${KeyVault(this@OverlayService).keyCount()} api key(s)"
            textSize = 12f
            setTextColor(Color.rgb(143, 158, 190))
            setPadding(0, dp(2), 0, dp(10))
        }
        statusText = status
        root.addView(status)

        val reply = TextView(this).apply {
            text = "what should i do?"
            textSize = 14f
            setTextColor(Color.rgb(236, 240, 249))
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = roundBackground(Color.rgb(30, 39, 57), 14f)
            setTextIsSelectable(true)
        }
        replyText = reply
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(reply, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT))
        }
        root.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f).apply {
            bottomMargin = dp(12)
        })

        val input = EditText(this).apply {
            hint = "tell me what to do…"
            setHintTextColor(Color.rgb(128, 142, 170))
            setTextColor(Color.WHITE)
            textSize = 15f
            minLines = 2
            maxLines = 4
            gravity = Gravity.TOP or Gravity.START
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = roundBackground(Color.rgb(34, 44, 64), 13f)
            imeOptions = EditorInfo.IME_ACTION_SEND or EditorInfo.IME_FLAG_NO_EXTRACT_UI
        }
        promptInput = input
        root.addView(input, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = dp(10)
        })

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
        }
        val history = Button(this).apply {
            text = "history"
            setTextColor(Color.rgb(202, 213, 238))
            setOnClickListener { showHistory() }
        }
        val send = Button(this).apply {
            text = "run agent"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(83, 105, 240))
            setOnClickListener { submitPrompt() }
        }
        sendButton = send
        actions.addView(history)
        actions.addView(send)
        root.addView(actions)
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) { submitPrompt(); true } else false
        }

        val screenWidth = resources.displayMetrics.widthPixels
        val panelWidth = minOf(dp(370), screenWidth - dp(28))
        val params = LayoutParams(panelWidth, dp(560), LayoutParams.TYPE_APPLICATION_OVERLAY,
            LayoutParams.FLAG_NOT_TOUCH_MODAL or LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT)
        params.gravity = Gravity.END or Gravity.CENTER_VERTICAL
        params.x = dp(12)
        params.softInputMode = LayoutParams.SOFT_INPUT_ADJUST_RESIZE or LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN
        try {
            windowManager.addView(root, params)
            panelView = root
        } catch (_: Exception) {
            showChip()
        }
    }

    private fun submitPrompt() {
        if (isBusy) return
        val prompt = promptInput?.text?.toString()?.trim().orEmpty()
        if (prompt.isBlank()) return
        if (KeyVault(this).keyCount() == 0) {
            updateReply("add a Gemini API key in Agent Panel settings first.")
            return
        }
        isBusy = true
        sendButton?.isEnabled = false
        promptInput?.setText("")
        updateReply("you: $prompt\n\nagent: working…")
        statusText?.text = "running"
        (getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager)?.hideSoftInputFromWindow(promptInput?.windowToken, 0)
        agentRunner.run(prompt, object : AgentRunner.Listener {
            override fun onStatus(status: String) {
                statusText?.text = status.lowercase()
            }

            override fun onFinished(reply: String) {
                isBusy = false
                sendButton?.isEnabled = true
                statusText?.text = "finished"
                updateReply("you: $prompt\n\nagent: $reply")
            }

            override fun onError(message: String) {
                isBusy = false
                sendButton?.isEnabled = true
                statusText?.text = "stopped"
                updateReply("you: $prompt\n\nagent error: $message")
            }
        })
    }

    private fun showHistory() {
        val history = com.example.agentpanel.storage.ConversationStore(this).historyText(12)
        updateReply(history)
        statusText?.text = "saved history · recent 12 turns"
    }

    private fun updateReply(value: String) {
        replyText?.text = value
    }

    private fun removeChip() {
        chipView?.let { try { windowManager.removeView(it) } catch (_: Exception) { } }
        chipView = null
    }

    private fun removePanel() {
        panelView?.let { try { windowManager.removeView(it) } catch (_: Exception) { } }
        panelView = null
        replyText = null
        promptInput = null
        statusText = null
        sendButton = null
    }

    private fun roundBackground(color: Int, radiusDp: Float): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp.toInt()).toFloat()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        removeChip()
        removePanel()
        mainHandler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    companion object {
        const val ACTION_OPEN_PANEL = "com.example.agentpanel.OPEN_PANEL"
        const val ACTION_START = "com.example.agentpanel.START_OVERLAY"

        fun openPanel(context: Context) {
            val intent = Intent(context, OverlayService::class.java).setAction(ACTION_OPEN_PANEL)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent) else context.startService(intent)
        }
    }
}
