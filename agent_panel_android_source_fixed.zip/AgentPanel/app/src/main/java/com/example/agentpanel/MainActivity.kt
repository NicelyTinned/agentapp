package com.example.agentpanel

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import com.example.agentpanel.gemini.GeminiClient
import com.example.agentpanel.overlay.OverlayService
import com.example.agentpanel.security.KeyVault
import com.example.agentpanel.storage.ConversationStore
import com.example.agentpanel.voice.WakeWordService

class MainActivity : Activity() {
    private lateinit var vault: KeyVault
    private lateinit var modelInput: EditText
    private lateinit var keysInput: EditText
    private lateinit var statusText: TextView
    private lateinit var voiceSwitch: Switch
    private var pendingVoiceEnable = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        vault = KeyVault(this)
        buildScreen()
        updateStatus()
        if (intent?.getBooleanExtra(EXTRA_STOP_VOICE, false) == true) stopVoice()
    }

    override fun onResume() {
        super.onResume()
        if (::statusText.isInitialized) updateStatus()
    }

    private fun buildScreen() {
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(22), dp(22), dp(30))
            setBackgroundColor(Color.rgb(17, 24, 39))
        }
        val scroll = ScrollView(this).apply { addView(content) }

        content.addView(text("AGENT PANEL", 12f, Color.rgb(144, 165, 255), true).apply { letterSpacing = 0.16f })
        content.addView(text("your phone, with an agent layer.", 25f, Color.WHITE, true).apply {
            setPadding(0, dp(6), 0, dp(8))
        })
        content.addView(text(
            "a small Android agent that uses Gemini function calls and the accessibility tree to navigate apps. it does not take screenshots.",
            14f, Color.rgb(184, 195, 218), false
        ).apply { setPadding(0, 0, 0, dp(18)) })

        content.addView(sectionTitle("1 · Gemini setup"))
        content.addView(label("Model ID"))
        modelInput = EditText(this).apply {
            setText(GeminiClient.DEFAULT_MODEL)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            textSize = 14f
            setSingleLine(true)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = rounded(Color.rgb(34, 45, 67), 12)
        }
        // Restore the last model name after creating the input.
        modelInput.setText(getSharedPreferences("agent_settings", MODE_PRIVATE).getString("gemini_model", GeminiClient.DEFAULT_MODEL))
        content.addView(modelInput, matchWrap().apply { bottomMargin = dp(12) })

        content.addView(label("Gemini API keys · one per line"))
        keysInput = EditText(this).apply {
            hint = "paste one or more keys here"
            setHintTextColor(Color.rgb(123, 138, 166))
            setTextColor(Color.WHITE)
            textSize = 14f
            minLines = 3
            maxLines = 6
            gravity = Gravity.TOP or Gravity.START
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = rounded(Color.rgb(34, 45, 67), 12)
        }
        content.addView(keysInput, matchWrap().apply { bottomMargin = dp(8) })

        val keyActions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        keyActions.addView(actionButton("save key pool") { saveKeys() }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { rightMargin = dp(8) })
        keyActions.addView(actionButton("clear keys") { clearKeys() }, LinearLayout.LayoutParams(0, dp(48), 1f))
        content.addView(keyActions)
        content.addView(text("keys saved: ${vault.keyCount()} · each Gemini API request advances to the next saved key.", 12f, Color.rgb(151, 166, 193), false)
            .apply { tag = "key_count"; setPadding(0, dp(8), 0, dp(10)) })
        content.addView(text("get a key from Google AI Studio. your keys are encrypted with Android Keystore on this device. never paste keys into screenshots or share them.",
            12f, Color.rgb(151, 166, 193), false).apply { setPadding(0, 0, 0, dp(20)) })

        content.addView(sectionTitle("2 · Android permissions"))
        statusText = text("checking permissions…", 13f, Color.rgb(188, 199, 221), false)
        content.addView(statusText.apply { setPadding(0, 0, 0, dp(10)) })
        content.addView(actionButton("grant display over other apps") { requestOverlayPermission() }.apply { setPadding(0, 0, 0, 0) }, matchWrap().apply { bottomMargin = dp(8) })
        content.addView(actionButton("enable accessibility service") { openAccessibilitySettings() }, matchWrap().apply { bottomMargin = dp(8) })

        content.addView(sectionTitle("3 · Edge panel"))
        content.addView(text("Start the edge tab. Tap its ✦ button to open the panel over other apps.", 13f, Color.rgb(184, 195, 218), false)
            .apply { setPadding(0, 0, 0, dp(10)) })
        val overlayActions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        overlayActions.addView(actionButton("start edge panel") { startOverlay() }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { rightMargin = dp(8) })
        overlayActions.addView(actionButton("stop panel") { stopOverlay() }, LinearLayout.LayoutParams(0, dp(48), 1f))
        content.addView(overlayActions)

        content.addView(sectionTitle("4 · Voice wake word"))
        voiceSwitch = Switch(this).apply {
            text = "listen for ‘agent’"
            textSize = 15f
            setTextColor(Color.WHITE)
            isChecked = getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean(VOICE_ENABLED, false)
            setOnCheckedChangeListener { _, checked ->
                if (checked) enableVoice() else stopVoice()
            }
        }
        content.addView(voiceSwitch, matchWrap().apply { bottomMargin = dp(4) })
        content.addView(text("When enabled, Android shows a persistent microphone notification. The system speech recognizer listens for the wake word and may process audio according to the recognizer provider's privacy terms. Saying ‘agent’ opens the panel; it does not submit a prompt by itself. Disable the toggle to stop listening.",
            12f, Color.rgb(151, 166, 193), false).apply { setPadding(0, 0, 0, dp(18)) })

        content.addView(sectionTitle("5 · History & safety"))
        content.addView(actionButton("view saved history and tool audit") { showHistory() })
        content.addView(text("History stores prompts, final replies, tool names, arguments, results, timestamps, and a short action summary. It does not store private chain-of-thought. Password entry is blocked, and consequential buttons require a manual tap.",
            12f, Color.rgb(151, 166, 193), false).apply { setPadding(0, dp(10), 0, dp(18)) })

        content.addView(text("source project · local-first settings · no analytics", 11f, Color.rgb(103, 119, 149), false)
            .apply { gravity = Gravity.CENTER; setPadding(0, dp(14), 0, 0) })
        setContentView(scroll)
    }

    private fun saveKeys() {
        try {
            val keys = keysInput.text.toString().split(Regex("[\\r\\n,]+"))
            vault.saveKeys(keys)
            keysInput.setText("")
            refreshKeyCount()
            toast("saved ${vault.keyCount()} encrypted API key(s)")
        } catch (e: Exception) {
            toast(e.message ?: "could not save keys")
        }
        saveModel()
    }

    private fun clearKeys() {
        AlertDialog.Builder(this)
            .setTitle("Clear API keys?")
            .setMessage("This removes the encrypted key pool from this device.")
            .setNegativeButton("cancel", null)
            .setPositiveButton("clear") { _, _ -> vault.clearKeys(); refreshKeyCount(); toast("key pool cleared") }
            .show()
    }

    private fun saveModel() {
        GeminiClient(this, vault).saveModelName(modelInput.text.toString())
    }

    private fun refreshKeyCount() {
        findViewWithTag("key_count")?.let { (it as TextView).text = "keys saved: ${vault.keyCount()} · each Gemini API request advances to the next saved key." }
    }

    private fun requestOverlayPermission() {
        if (Settings.canDrawOverlays(this)) { toast("overlay permission already enabled"); updateStatus(); return }
        val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        startActivityForResult(intent, REQUEST_OVERLAY)
    }

    private fun openAccessibilitySettings() {
        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    }

    private fun startOverlay() {
        saveModel()
        if (!Settings.canDrawOverlays(this)) {
            requestOverlayPermission()
            return
        }
        val intent = Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_START)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
        toast("edge panel started")
    }

    private fun stopOverlay() {
        stopService(Intent(this, OverlayService::class.java))
        toast("edge panel stopped")
    }

    private fun enableVoice() {
        if (!Settings.canDrawOverlays(this)) {
            pendingVoiceEnable = true
            voiceSwitch.isChecked = false
            requestOverlayPermission()
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            pendingVoiceEnable = true
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQUEST_MIC)
            return
        }
        startOverlay()
        val intent = Intent(this, WakeWordService::class.java).setAction(WakeWordService.ACTION_START)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(VOICE_ENABLED, true).apply()
        voiceSwitch.isChecked = true
        toast("wake word listener enabled · microphone notification is active")
    }

    private fun stopVoice() {
        stopService(Intent(this, WakeWordService::class.java).setAction(WakeWordService.ACTION_STOP))
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(VOICE_ENABLED, false).apply()
        if (::voiceSwitch.isInitialized && voiceSwitch.isChecked) voiceSwitch.isChecked = false
        toast("wake word listener stopped")
    }

    @Deprecated("Activity result compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_OVERLAY) {
            updateStatus()
            if (pendingVoiceEnable && Settings.canDrawOverlays(this)) {
                pendingVoiceEnable = false
                if (::voiceSwitch.isInitialized) voiceSwitch.isChecked = true else enableVoice()
            }
        }
    }

    @Deprecated("Permission callback compatibility")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_MIC) {
            if (grantResults.firstOrNull() == android.content.pm.PackageManager.PERMISSION_GRANTED) enableVoice()
            else {
                pendingVoiceEnable = false
                if (::voiceSwitch.isInitialized) voiceSwitch.isChecked = false
                toast("microphone permission was not granted")
            }
        }
    }

    private fun updateStatus() {
        if (!::statusText.isInitialized) return
        val overlay = Settings.canDrawOverlays(this)
        val accessibility = com.example.agentpanel.accessibility.AccessibilityBridge.isConnected()
        statusText.text = "overlay permission: ${if (overlay) "on" else "off"}\naccessibility service: ${if (accessibility) "connected" else "not connected (enable it below)"}\nAPI keys: ${vault.keyCount()}"
    }

    private fun showHistory() {
        val view = TextView(this).apply {
            text = ConversationStore(this@MainActivity).historyText(40)
            textSize = 12f
            setTextColor(Color.rgb(35, 45, 63))
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setTextIsSelectable(true)
        }
        val scroll = ScrollView(this).apply { addView(view) }
        AlertDialog.Builder(this).setTitle("Saved agent history").setView(scroll).setPositiveButton("close", null).show()
    }

    private fun findViewWithTag(tag: String): View? = window.decorView.findViewWithTag(tag)

    private fun sectionTitle(value: String) = text(value, 16f, Color.WHITE, true).apply { setPadding(0, dp(18), 0, dp(10)) }
    private fun label(value: String) = text(value, 12f, Color.rgb(165, 180, 207), true).apply { setPadding(0, 0, 0, dp(6)) }
    private fun text(value: String, size: Float, color: Int, bold: Boolean) = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun actionButton(value: String, action: () -> Unit) = Button(this).apply {
        text = value
        textSize = 12f
        isAllCaps = false
        setTextColor(Color.WHITE)
        setBackgroundColor(Color.rgb(67, 88, 179))
        setOnClickListener { action() }
    }

    private fun rounded(color: Int, radiusDp: Int) = android.graphics.drawable.GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

    private fun matchWrap() = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    companion object {
        private const val PREFS = "agent_settings"
        private const val VOICE_ENABLED = "voice_wake_enabled"
        private const val REQUEST_OVERLAY = 701
        private const val REQUEST_MIC = 702
        const val EXTRA_STOP_VOICE = "stop_voice"
    }
}
