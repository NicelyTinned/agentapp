package com.example.agentpanel.storage

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONObject

class ConversationStore(context: Context) : SQLiteOpenHelper(context.applicationContext, DB_NAME, null, DB_VERSION) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE turns (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            prompt TEXT NOT NULL,
            reply TEXT NOT NULL DEFAULT '',
            created_at INTEGER NOT NULL
        )""".trimIndent())
        db.execSQL("""CREATE TABLE tool_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            turn_id INTEGER NOT NULL,
            tool_name TEXT NOT NULL,
            arguments TEXT NOT NULL,
            result TEXT NOT NULL,
            decision_summary TEXT NOT NULL,
            created_at INTEGER NOT NULL,
            FOREIGN KEY(turn_id) REFERENCES turns(id) ON DELETE CASCADE
        )""".trimIndent())
        db.execSQL("CREATE INDEX idx_tool_events_turn_id ON tool_events(turn_id)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit

    @Synchronized
    fun createTurn(prompt: String): Long {
        val values = ContentValues().apply {
            put("prompt", prompt)
            put("reply", "")
            put("created_at", System.currentTimeMillis())
        }
        return writableDatabase.insertOrThrow("turns", null, values)
    }

    @Synchronized
    fun saveReply(turnId: Long, reply: String) {
        writableDatabase.update("turns", ContentValues().apply { put("reply", reply) }, "id=?", arrayOf(turnId.toString()))
    }

    @Synchronized
    fun addToolEvent(turnId: Long, toolName: String, arguments: JSONObject, result: String, decisionSummary: String) {
        val values = ContentValues().apply {
            put("turn_id", turnId)
            put("tool_name", toolName)
            put("arguments", arguments.toString())
            put("result", result)
            put("decision_summary", decisionSummary)
            put("created_at", System.currentTimeMillis())
        }
        writableDatabase.insert("tool_events", null, values)
    }

    @Synchronized
    fun conversationContext(maxTurns: Int = 8): String {
        val db = readableDatabase
        val turns = mutableListOf<Pair<Long, Pair<String, String>>>()
        db.rawQuery("SELECT id, prompt, reply FROM turns ORDER BY id DESC LIMIT ?", arrayOf(maxTurns.toString())).use { c ->
            while (c.moveToNext()) turns.add(c.getLong(0) to (c.getString(1) to c.getString(2)))
        }
        if (turns.isEmpty()) return "No previous conversation."
        val out = StringBuilder()
        turns.asReversed().forEach { (turnId, pair) ->
            out.append("User: ").append(pair.first).append('\n')
            if (pair.second.isNotBlank()) out.append("Assistant: ").append(pair.second).append('\n')
            db.rawQuery(
                "SELECT tool_name, arguments, result, decision_summary, created_at FROM tool_events WHERE turn_id=? ORDER BY id",
                arrayOf(turnId.toString())
            ).use { events ->
                while (events.moveToNext()) {
                    out.append("Tool audit: ").append(events.getString(0))
                        .append(" args=").append(events.getString(1))
                        .append(" result=").append(events.getString(2).take(700))
                        .append(" action_summary=").append(events.getString(3))
                        .append(" timestamp=").append(events.getLong(4)).append('\n')
                }
            }
        }
        return out.toString().takeLast(12000)
    }

    @Synchronized
    fun historyText(limit: Int = 30): String {
        val db = readableDatabase
        val out = StringBuilder()
        db.rawQuery("SELECT id, prompt, reply, created_at FROM turns ORDER BY id DESC LIMIT ?", arrayOf(limit.toString())).use { c ->
            while (c.moveToNext()) {
                out.append("#").append(c.getLong(0)).append("  ")
                    .append(java.text.DateFormat.getDateTimeInstance().format(java.util.Date(c.getLong(3))))
                    .append("\nYou: ").append(c.getString(1)).append("\nAgent: ")
                    .append(c.getString(2).ifBlank { "(not finished)" }).append("\n")
                db.rawQuery(
                    "SELECT tool_name, arguments, result, decision_summary, created_at FROM tool_events WHERE turn_id=? ORDER BY id",
                    arrayOf(c.getLong(0).toString())
                ).use { e ->
                    while (e.moveToNext()) {
                        out.append("  • ").append(java.text.DateFormat.getTimeInstance().format(java.util.Date(e.getLong(4))))
                            .append(" ").append(e.getString(0)).append("(").append(e.getString(1)).append(")")
                            .append(" → ").append(e.getString(2).take(300))
                            .append("\n    Action summary: ").append(e.getString(3)).append('\n')
                    }
                }
                out.append("\n")
            }
        }
        return out.toString().ifBlank { "No saved history yet." }
    }

    companion object {
        private const val DB_NAME = "agent_panel_history.db"
        private const val DB_VERSION = 1
    }
}
