# Agent Panel (Android)

A small Android AI-agent prototype. It provides a floating edge tab, a prompt/reply panel, Gemini function calling, accessibility-backed UI tools, an opt-in `agent` wake word, and a local tool audit/history.

## Model

Default model: `gemini-3.5-flash-lite` (stable Gemini API model ID). The model ID is editable in the app settings. It is not the preview-suffixed name `gemini-3.5-flash-lite-preview`.

## Build

1. Install Android Studio with Android SDK Platform 36 and JDK 17.
2. Open the `AgentPanel` folder in Android Studio.
3. Use Gradle 8.13 with JDK 17, let the Android Gradle Plugin sync, then build and install the `app` run configuration on an Android device (API 26+).
4. The project intentionally contains only app source/resources and Gradle project files. There is no APK, CI workflow, GitHub Actions configuration, or Gradle wrapper binary in this source-only archive.

## First-run setup

1. Open **Agent Panel**.
2. Create one or more Gemini API keys in Google AI Studio, then paste them into **Gemini API keys** with one key per line and tap **save key pool**. The app encrypts the key list with AES-GCM using an Android Keystore key. The raw keys are not written to logs or the database.
3. Leave the model as `gemini-3.5-flash-lite`, or enter another model ID enabled for your API project.
4. Tap **grant display over other apps** and approve the Android overlay permission.
5. Tap **enable accessibility service**. In Android Settings, enable **Agent Panel accessibility**. Android requires the user to enable an accessibility service manually.
6. Return to Agent Panel and tap **start edge panel**. A small ✦ tab appears at the right edge. Tap it to open the assistant panel.
7. Type a task and tap **run agent**.
8. To use the optional wake word, enable **listen for ‘agent’** and grant microphone permission. Android shows a persistent microphone notification while the listener runs. Say “agent” to open the panel; the word itself is not submitted as a prompt. Turn the switch off to stop listening.

## Tools exposed to Gemini

- `finish(reply: String)`
- `search_internet(query: String)`
- `search_elements(query: String)`
- `click_element(elementId: String)`
- `type_text(text: String)`
- `scroll(direction: String)`
- `press_back()`
- `get_screen_info()`

The agent loop returns a normal final answer only when Gemini calls `finish`. A 36-step guard and network/API errors abort the run rather than allowing an unbounded loop.

`search_internet` is implemented as a separate Gemini request with Google's hosted Search tool. It therefore consumes the next key in the configured key pool, like every other Gemini request.

## API-key rotation

The app advances a persisted round-robin index before each Gemini API request. For example, keys A, B, C are used A → B → C → A. Failed requests also consume their turn. Only add keys that you own or are authorized to use. Key rotation is not a way to bypass provider quotas, rate limits, billing, or project restrictions.

## Saved history

The local SQLite database stores each prompt and final reply plus tool events containing. This includes the exact arguments passed to tools, so text passed to `type_text` can be present in local history.

- tool name;
- exact JSON arguments passed to the tool;
- tool result;
- timestamp;
- a short `decision_summary` audit note.

Private chain-of-thought is not collected or stored. The `decision_summary` is a concise, user-safe description of the immediate action, not hidden reasoning.

## Safety and platform notes

- Accessibility is enabled only after the user turns the service on in Android Settings. The service inspects the active accessibility tree; it does not take screenshots.
- `click_element` refuses controls with consequential labels such as send, post, share, buy, purchase, pay, transfer, delete, remove, submit, checkout, or confirm. The user must perform those final actions manually. The model is also instructed not to enter passwords, authentication codes, payment details, or secrets.
- `type_text` refuses password fields. It works only with a currently focused editable control.
- Element IDs are temporary and expire. Search again if the screen changes or the click is rejected.
- The wake-word feature uses Android `SpeechRecognizer`. `EXTRA_PREFER_OFFLINE` is only a preference; whether audio is processed locally depends on the installed speech-recognition provider and device configuration. The user-visible microphone notification stays present while enabled. This prototype is not a guaranteed always-on hotword implementation across all Android manufacturers.
- The overlay and microphone services use foreground-service notifications. Android may restrict background execution, speech recognition, and overlay behavior depending on OS version, device settings, and manufacturer battery management.
- This is a personal prototype, not a Play-Store-ready accessibility product. Review Google's current Accessibility API and foreground-service policies before distributing it.

## Project layout

- `MainActivity.kt` — setup, permissions, model/key settings, wake-word toggle, and history view.
- `overlay/OverlayService.kt` — floating edge tab and interactive prompt panel.
- `voice/WakeWordService.kt` — explicit, foreground `agent` wake-word listener.
- `accessibility/` — Android AccessibilityService and temporary element-ID bridge.
- `gemini/GeminiClient.kt` — Gemini REST client, function declarations, Google Search grounding, and key rotation entry point.
- `agent/AgentRunner.kt` — multi-step tool loop; normal completion only through `finish`.
- `storage/ConversationStore.kt` — local SQLite conversation and tool audit.
- `security/KeyVault.kt` — AES-GCM encrypted API-key list using Android Keystore.
