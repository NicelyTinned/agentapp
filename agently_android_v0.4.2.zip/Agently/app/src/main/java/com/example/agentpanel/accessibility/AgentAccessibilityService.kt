package com.example.agentpanel.accessibility

import android.accessibilityservice.AccessibilityService
import android.graphics.Rect
import android.graphics.Path
import android.accessibilityservice.GestureDescription
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityWindowInfo
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONArray
import org.json.JSONObject
import java.util.ArrayDeque
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class AgentAccessibilityService : AccessibilityService() {
    private data class NodePath(
        val path: List<Int>,
        val label: String,
        val packageName: String,
        val className: String,
        val viewId: String,
        val createdAt: Long
    )

    private val elementIds = ConcurrentHashMap<String, NodePath>()
    private val idCounter = AtomicInteger(1)

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Our own full-screen status/approval UI must not invalidate target-app element IDs.
        val eventPackage = event?.packageName?.toString().orEmpty()
        if (eventPackage.equals(packageName, ignoreCase = true)) return
        when (event?.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,
            AccessibilityEvent.TYPE_WINDOWS_CHANGED -> elementIds.clear()
            // Keep IDs across content/scroll events; resolveClickTarget re-identifies
            // them against the latest accessibility tree before every action.
        }
    }

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        if (instance === this) instance = null
        elementIds.clear()
        super.onDestroy()
    }

    fun searchElements(query: String): String {
        val root = targetAppRoot() ?: return "No active app window. Open the app you want to use and try again."
        elementIds.clear()
        val needle = query.trim().lowercase()
        val results = JSONArray()
        val queue = ArrayDeque<Pair<AccessibilityNodeInfo, List<Int>>>()
        queue.add(root to emptyList())
        var inspected = 0
        while (queue.isNotEmpty() && inspected < MAX_NODES && results.length() < MAX_RESULTS) {
            val (node, path) = queue.removeFirst()
            inspected++
            // Do not expose text or descriptions from editable/password fields to the model.
            val sensitive = node.isPassword || node.isEditable
            val text = if (sensitive) "" else node.text?.toString().orEmpty()
            val description = if (sensitive) "" else node.contentDescription?.toString().orEmpty()
            val viewId = node.viewIdResourceName.orEmpty()
            val label = listOf(text, description, viewId).filter { it.isNotBlank() }.joinToString(" | ")
            val matches = needle.isBlank() || text.contains(needle, true) || description.contains(needle, true) || viewId.contains(needle, true)
            if (matches && label.isNotBlank()) {
                val id = "el_${idCounter.getAndIncrement()}"
                val packageName = node.packageName?.toString().orEmpty()
                elementIds[id] = NodePath(
                    path, label, packageName, node.className?.toString().orEmpty(),
                    viewId, System.currentTimeMillis()
                )
                val bounds = Rect()
                node.getBoundsInScreen(bounds)
                results.put(JSONObject()
                    .put("id", id)
                    .put("text", text)
                    .put("contentDescription", description)
                    .put("viewId", viewId)
                    .put("className", node.className?.toString().orEmpty())
                    .put("clickable", node.isClickable)
                    .put("enabled", node.isEnabled)
                    .put("editable", node.isEditable)
                    .put("password", node.isPassword)
                    .put("scrollable", node.isScrollable)
                    .put("bounds", "${bounds.left},${bounds.top},${bounds.right},${bounds.bottom}"))
            }
            for (i in 0 until node.childCount) {
                val child = node.getChild(i) ?: continue
                queue.add(child to (path + i))
            }
        }
        return JSONObject()
            .put("packageName", root.packageName?.toString().orEmpty())
            .put("query", query)
            .put("elements", results)
            .put("truncated", inspected >= MAX_NODES || results.length() >= MAX_RESULTS)
            .toString()
    }

    private data class ClickTarget(
        val actionNode: AccessibilityNodeInfo,
        val targetLabel: String,
        val combinedLabel: String
    )

    /** Returns the exact visible control and its action class without activating it. */
    fun previewClickElement(elementId: String): String {
        val (target, error) = resolveClickTarget(elementId)
        if (target == null) {
            return JSONObject().put("valid", false).put("message", error).toString()
        }
        return JSONObject()
            .put("valid", true)
            .put("label", target.combinedLabel.ifBlank { target.targetLabel })
            .put("category", actionCategory(target.combinedLabel))
            .toString()
    }

    /**
     * Activates an ordinary control, or a communication control only after the agent runner
     * has obtained explicit approval for this specific outbound action. Restricted account/payment/data actions
     * remain blocked regardless of consent.
     */
    fun clickElement(elementId: String, communicationActionApproved: Boolean = false): String {
        val (target, error) = resolveClickTarget(elementId)
        val resolved = target ?: return error
        val category = actionCategory(resolved.combinedLabel)
        if (category == "restricted") {
            return "BLOCKED: '${resolved.combinedLabel}' can change payment, account, security, permissions, or stored data. Complete this action manually."
        }
        if (category == "communication" && !communicationActionApproved) {
            return "NEEDS_APPROVAL: '${resolved.combinedLabel}' can send or publish content. Obtain explicit approval for this specific outbound action before clicking."
        }
        if (!resolved.actionNode.isEnabled || !resolved.actionNode.isVisibleToUser) return "Element is currently unavailable. Search again after the UI settles."
        try { resolved.actionNode.refresh() } catch (_: Exception) { }
        val clicked = resolved.actionNode.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        val gestureClicked = if (clicked) false else tapFreshBounds(resolved.actionNode)
        if (clicked || gestureClicked) {
            elementIds.clear()
            return "Clicked: ${resolved.targetLabel.ifBlank { resolved.combinedLabel }}${if (gestureClicked) " (gesture fallback)" else ""}"
        }
        return "Android rejected both the accessibility click and the verified-bounds gesture. Search again after the UI settles."
    }

    /** Last-resort tap using fresh, visible bounds after ACTION_CLICK is rejected. */
    private fun tapFreshBounds(node: AccessibilityNodeInfo): Boolean {
        val fresh = try { AccessibilityNodeInfo.obtain(node) } catch (_: Exception) { return false }
        try {
            try { fresh.refresh() } catch (_: Exception) { }
            if (!fresh.isVisibleToUser || !fresh.isEnabled) return false
            val bounds = Rect()
            fresh.getBoundsInScreen(bounds)
            if (bounds.isEmpty || bounds.width() <= 0 || bounds.height() <= 0) return false
            val x = bounds.exactCenterX()
            val y = bounds.exactCenterY()
            val path = Path().apply { moveTo(x, y) }
            val gesture = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 70))
                .build()
            val completed = CountDownLatch(1)
            val accepted = java.util.concurrent.atomic.AtomicBoolean(false)
            val dispatched = dispatchGesture(gesture, object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    accepted.set(true)
                    completed.countDown()
                }
                override fun onCancelled(gestureDescription: GestureDescription?) {
                    completed.countDown()
                }
            }, null)
            if (!dispatched) return false
            completed.await(900, TimeUnit.MILLISECONDS)
            return accepted.get()
        } catch (_: Exception) {
            return false
        } finally {
            fresh.recycle()
        }
    }

    private fun resolveClickTarget(elementId: String): Pair<ClickTarget?, String> {
        val saved = elementIds[elementId] ?: return null to "Element ID not found or expired. Run search_elements again."
        if (System.currentTimeMillis() - saved.createdAt > ELEMENT_ID_TTL_MS) {
            elementIds.remove(elementId)
            return null to "Element ID expired. Run search_elements again."
        }
        val root = targetAppRoot() ?: return null to "No active app window."
        if (!root.packageName?.toString().orEmpty().equals(saved.packageName, true)) {
            elementIds.remove(elementId)
            return null to "The active app changed. Run search_elements again."
        }
        // First try the saved path for speed. Accessibility child indexes are not stable
        // across RecyclerView updates, animations, and Compose recompositions, so validate
        // its identity and fall back to a fresh-tree fingerprint search when it drifted.
        var node: AccessibilityNodeInfo? = root
        for (index in saved.path) {
            node = node?.getChild(index)
            if (node == null) break
        }
        fun matches(candidate: AccessibilityNodeInfo): Boolean {
            val label = if (candidate.isPassword || candidate.isEditable)
                candidate.viewIdResourceName.orEmpty() else candidate.labelForAgent()
            return candidate.packageName?.toString().orEmpty().equals(saved.packageName, true) &&
                label == saved.label &&
                candidate.className?.toString().orEmpty() == saved.className &&
                candidate.viewIdResourceName.orEmpty() == saved.viewId
        }
        if (node == null || !matches(node) || !node.isVisibleToUser) {
            node = null
            val queue = ArrayDeque<AccessibilityNodeInfo>()
            queue.add(root)
            var visited = 0
            while (queue.isNotEmpty() && visited++ < MAX_NODES) {
                val candidate = queue.removeFirst()
                if (candidate.isVisibleToUser && matches(candidate)) {
                    node = candidate
                    break
                }
                for (i in 0 until candidate.childCount) candidate.getChild(i)?.let(queue::add)
            }
        }
        if (node == null) {
            return null to "Element could not be re-identified in the current screen. Run search_elements again."
        }
        try { node.refresh() } catch (_: Exception) { }
        if (!node.isVisibleToUser || !node.isEnabled) {
            return null to "Element is currently hidden or disabled. Wait for the screen to settle and search again."
        }
        val targetLabel = if (node.isPassword || node.isEditable) node.viewIdResourceName.orEmpty() else node.labelForAgent()
        var clickable: AccessibilityNodeInfo? = node
        while (clickable != null && (!clickable.isClickable || !clickable.isVisibleToUser || !clickable.isEnabled)) clickable = clickable.parent
        val actionNode = clickable ?: node
        val combinedLabel = listOf(targetLabel, actionNode.labelForAgent())
            .filter { it.isNotBlank() }.distinct().joinToString(" | ")
        return ClickTarget(actionNode, targetLabel, combinedLabel) to ""
    }

    private fun actionCategory(label: String): String {
        // Match complete words/phrases so "submit post" and "confirm send" are
        // treated as outbound communication, without confusing "payment" with "pay".
        val normalized = label.lowercase().replace(Regex("[^a-z0-9]+"), " ").trim()
        fun hasPhrase(phrase: String): Boolean =
            (" $normalized ").contains(" ${phrase.lowercase()} ")

        val communication = listOf(
            "send", "post", "share", "publish", "upload", "comment", "reply"
        )
        val isCommunication = communication.any(::hasPhrase)

        val restricted = listOf(
            "purchase", "buy", "pay", "payment", "money", "bank", "donate", "donation", "tip",
            "transfer", "withdraw", "cash out", "top up", "delete", "remove", "place order",
            "checkout", "accept", "agree", "allow", "permission", "subscribe", "unsubscribe",
            "follow", "unfollow", "block", "report", "install", "uninstall", "reset", "sign out",
            "log out", "change password", "security", "grant access"
        )
        if (restricted.any(::hasPhrase)) return "restricted"

        // Generic confirmation/submit controls are not safe to activate without context.
        // When the same control is clearly a send/post action, the explicit approval gate applies.
        if (hasPhrase("submit") || hasPhrase("confirm")) {
            return if (isCommunication) "communication" else "restricted"
        }
        return if (isCommunication) "communication" else "ordinary"
    }

    fun typeText(text: String): String {
        val root = targetAppRoot() ?: return "No active app window."
        val focused = findFocusedEditable(root) ?: return "No focused editable field. Tap the field first, then retry."
        if (focused.isPassword) return "BLOCKED: typing into password fields is not supported."
        if (!focused.isEditable) return "The focused element is not editable."
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        val success = focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        return if (success) "Text entered into the focused field (${text.length} characters)." else "Android rejected text entry. Check that the field is focused and editable."
    }

    fun scroll(direction: String): String {
        val forward = when (direction.trim().lowercase()) {
            "down" -> true
            "up" -> false
            else -> return "Invalid direction. Use up or down."
        }
        val root = targetAppRoot() ?: return "No active app window."
        val scrollable = findScrollable(root) ?: return "No scrollable element found on this screen."
        val action = if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        return if (scrollable.performAction(action)) "Scrolled ${direction.lowercase()}." else "The scroll action was not accepted."
    }

    fun pressBack(): String = if (performGlobalAction(GLOBAL_ACTION_BACK)) "Pressed Back." else "Android did not accept Back."

    fun screenInfo(): String {
        val root = targetAppRoot() ?: return "No active app window."
        val text = StringBuilder()
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var count = 0
        while (queue.isNotEmpty() && count < MAX_NODES && text.length < 5000) {
            val node = queue.removeFirst()
            count++
            // Screen summaries must not leak text from editable or password fields.
            val label = if (node.isPassword || node.isEditable) {
                node.viewIdResourceName.orEmpty()
            } else node.labelForAgent()
            if (label.isNotBlank()) text.append("• ").append(label).append(if (node.isClickable) " [clickable]" else "").append('\n')
            for (i in 0 until node.childCount) node.getChild(i)?.let(queue::add)
        }
        return JSONObject()
            .put("packageName", root.packageName?.toString().orEmpty())
            .put("windowClass", root.className?.toString().orEmpty())
            .put("accessibleText", text.toString())
            .put("truncated", count >= MAX_NODES || text.length >= 5000)
            .toString()
    }

    /**
     * The run-state overlay belongs to Agently and sits above the target app. Prefer the
     * topmost ordinary application window that is not ours so the agent never inspects
     * or clicks its own progress/history surface.
     */
    private fun targetAppRoot(): AccessibilityNodeInfo? {
        val ownPackage = applicationContext.packageName
        val appWindows: List<AccessibilityWindowInfo> = try {
            windows.filter { it.type == AccessibilityWindowInfo.TYPE_APPLICATION }
        } catch (_: Exception) {
            emptyList()
        }
        for (window in appWindows.sortedByDescending { it.isActive || it.isFocused }) {
            val root = try { window.root } catch (_: Exception) { null } ?: continue
            if (!root.packageName?.toString().orEmpty().equals(ownPackage, true)) return root
        }
        return rootInActiveWindow?.takeIf {
            !it.packageName?.toString().orEmpty().equals(ownPackage, true)
        }
    }

    private fun findFocusedEditable(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var count = 0
        while (queue.isNotEmpty() && count++ < MAX_NODES) {
            val node = queue.removeFirst()
            if (node.isFocused && node.isEditable) return node
            for (i in 0 until node.childCount) node.getChild(i)?.let(queue::add)
        }
        return null
    }

    private fun findScrollable(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var count = 0
        while (queue.isNotEmpty() && count++ < MAX_NODES) {
            val node = queue.removeFirst()
            if (node.isScrollable && node.isEnabled) return node
            for (i in 0 until node.childCount) node.getChild(i)?.let(queue::add)
        }
        return null
    }

    private fun AccessibilityNodeInfo.labelForAgent(): String = listOf(
        text?.toString().orEmpty(),
        contentDescription?.toString().orEmpty(),
        viewIdResourceName.orEmpty()
    ).filter { it.isNotBlank() }.joinToString(" | ")

    companion object {
        @Volatile var instance: AgentAccessibilityService? = null
            private set
        private const val MAX_NODES = 700
        private const val MAX_RESULTS = 35
        private const val ELEMENT_ID_TTL_MS = 45_000L
    }
}
